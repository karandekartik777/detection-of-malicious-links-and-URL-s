# Screenshots of the Apps in Action

## Web App

Homepage - Look and feel of a search engine!

<img src="./img/webapp/home.png" height="360"/>

Report

<img src="./img/webapp/org-report.png" height="360"/>

Dashboard

<img src="./img/webapp/dashboard-welcome.png" height="360"/>

Organization Dashboard

<img src="./img/webapp/dashboard-org.png" height="360"/>

Admin Dashboard

<img src="./img/webapp/dashboard-admin.png" height="360"/>

Reporting Screen

<img src="./img/webapp/report-user.gif" height="360"/>


Approving Report in Dashboard

<img src="./img/webapp/approve.gif" height="280"/>



API for organizations to access all reports

<img src="./img/webapp/reports-json.gif" height="360"/>