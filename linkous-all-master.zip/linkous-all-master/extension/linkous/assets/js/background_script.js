chrome.runtime.onStartup.addListener(function() {
	localStorage.setItem("proceed", "false");
	localStorage.setItem("url", " ");
})

function pristine_url2(url) {
	url = url.replace('http://', '');
	url = url.replace('https://', '');
	url = url.replace('www.', '');
	if (url[url.length - 1] == '/')
		url = url.slice(0, url.length - 1);
	return url;
}
var c = false;
var windowConfirmProceed = false;
var isUnsafePR = false;
var unsafeCount = 0;
window.browser = (function() {
	return window.msBrowser ||
		window.browser ||
		window.chrome;
})();



browser.tabs.query({ active: true, currentWindow: true }, function(tabs) {
	browser.webRequest.onBeforeRequest.addListener(function(details) {

		if (window.localStorage.getItem("pause_protection") == "true") {
			return;
		}
		if (details.type == "main_frame") {
			isUnsafePR = false;
			unsafeCount = 0;
			windowConfirmProceed = false;
			if (localStorage.getItem("proceed") == "true") {
				localStorage.setItem("proceed", "false");
				return;
			}
			if (/^(chrome-extension:\/\/)+[^\n ]*/.test(details.url) || /^(moz-extension:\/\/)+[^\n ]*/.test(details.url) || /^(extension:\/\/)+[^\n ]*/.test(details.url)) {
				return;
			}
			var res = {};
			var url = pristine_url2(details.url)
			$.ajax({
				type: 'POST',
				url: "https://linkous.herokuapp.com/api/search",
				data: {
					url: url
				},
				success: function(data, status) {
					if (status != 200) {
						c = false;
					}
					else {
						try {
							res = JSON.parse(data);

							if (res.count != 0) {
								localStorage.setItem("url", details.url);
								c = true;
							}
							else
								c = false;
						}
						catch (e) {
							c = false;
						}
					}
				},
				async: false
			});
			if (!c) {
				$.ajax({
					type: 'POST',
					url: "https://linkous.herokuapp.com/api/pagerank",

					data: {
						url: url
					},
					success: function(data, status) {
						if (status != 200) {
							c = false;
						}
						else {
							try {
								console.log(data);
								res = JSON.parse(data);
								if (res.result == 'risky') {
									localStorage.setItem("url", details.url);
									c = !window.confirm("Visiting this Link might be Risky!!\nDo you want to proceed?");
									if (c) {
										return { redirectUrl: browser.runtime.getURL("assets/html/index.html") };
									}
									windowConfirmProceed = !c;
									if (!c) {
										unsafeCount++;
									}
									isUnsafePR = true;
								}
								else
									c = false;
							}
							catch (e) {
								c = false;
							}
						}
					},
					async: false
				});
				console.log("\n\n\n" + c + "\n\n\n");
				console.log("\n\n\nw" + windowConfirmProceed + "\n\n\n");
				if (!c && isUnsafePR && !windowConfirmProceed) {
					$.ajax({
						type: 'POST',
						url: "https://linkous.herokuapp.com/api/lex-scan",

						data: {
							url: url
						},
						success: function(data, status) {
							if (status != 200) {
								c = false;
							}
							else {
								try {
									res = JSON.parse(data);
									if (Json.parse(res.result).result == 'unsafe') {
										localStorage.setItem("url", details.url);
										unsafeCount++;
										console.log("unsfe");
										if (unsafeCount > 1)
											c = true;
										else
											c = !window.confirm("Visiting this Link might be Risky!!\nDo you want to proceed?");
										if (c) {
											return { redirectUrl: browser.runtime.getURL("assets/html/index.html") };
										}
										windowConfirmProceed = !c;
									}
									else
										c = false;
								}
								catch (e) {
									c = false;
								}
							}
						},
						async: false
					});
					if (!c && isUnsafePR && !windowConfirmProceed) {
						$.ajax({
							type: 'POST',
							url: "https://linkous.herokuapp.com/api/spam-scan",

							data: {
								url: url
							},
							success: function(data, status) {
								if (status != 200) {
									c = false;
								}
								else {
									try {
										res = JSON.parse(data);
										if (res.result == 'unsafe') {
											localStorage.setItem("url", details.url);
											unsafeCount++;
											c = unsafeCount > 1 ? true : !window.confirm("This page may contain Spam/Unsafe Content!!\nDo you want to proceed?");
											//c = false;
											if (c) {
												return { redirectUrl: browser.runtime.getURL("assets/html/index.html") };
											}
											windowConfirmProceed = !c;
											console.log("unsafe");
										}
										else
											c = false;
									}
									catch (e) {
										c = false;
									}
								}
							},
							async: false
						});
						if (!c && isUnsafePR && !windowConfirmProceed) {
							$.ajax({
								type: 'POST',
								url: "https://linkous.herokuapp.com/api/content-scan",

								data: {
									url: url
								},
								success: function(data, status) {
									if (status != 200) {
										c = false;
									}
									else {
										try {
											var message;
											var isUnsafeCS = false;
											if (data.length == 0)
												c = false;
											else {
												for (i in data) {
													if (data[i].detection.payload) {
														isUnSafeCS = true;
														message = "a Payload";
														break;
													}
													else if (data[i].detection.state == "unsafe") {
														isUnsafeCS = true;
														message = "Unsafe Content/Scripts";
														break;
													}
												}
												if (isUnsafeCS) {
													localStorage.setItem("url", details.url);
													unsafeCount++;
													c = unsafeCount > 1 ? true : !window.confirm("This page may contain" + message + " !!\nDo you want to proceed?");
													//c = false;
													if (c) {
														return { redirectUrl: browser.runtime.getURL("assets/html/index.html") };
													}
													console.log("unsafe");
												}
												else
													c = false;
											}
										}
										catch (e) {
											c = false;
										}
									}
								},
								async: false
							});
						}
					}
				}
			}
		}
		console.log(c);
		if (c) {
			return { redirectUrl: browser.runtime.getURL("assets/html/index.html") };
		}
	}, { urls: ["http://*/*", "https://*/*"] }, ["blocking"])
})
