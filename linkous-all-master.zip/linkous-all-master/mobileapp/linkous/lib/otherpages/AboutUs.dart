import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:linkous/settings/settings.dart';
import 'package:linkous/settings/myThemes.dart';

class AboutUs extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Padding(
          padding: const EdgeInsets.only(left: 5,right: 5),
          child: Scaffold(
            backgroundColor: Color.fromRGBO(55, 71, 79, 100),
            extendBodyBehindAppBar: true,
            appBar: AppBar(
              backgroundColor: Colors.transparent,
              title: Text('Linkous'),
            ),
            endDrawer: AppDrawer(true,true),
            body: Container(
              decoration: myThemes.background,
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.only(left: 7,right: 7),
                  child: Container(
                    padding: EdgeInsets.only(left: 4,right: 4),
                    decoration: BoxDecoration(
                        color: Colors.black54,
                        borderRadius: BorderRadius.circular(25)),
                    child: Stack(
                      children: <Widget>[
                        Container(
                            child: Center(
                                heightFactor: 2,
                                child: Text(
                                  "Why Linkous?",
                                  style: TextStyle(
                                      fontSize: 22,
                                      fontWeight: FontWeight.bold,
                                      color: myThemes.primary
                                  ),
                                ))),
                        Padding(
                          padding:
                              const EdgeInsets.only(top: 50, bottom: 20, left: 5),
                          child: Text(
                            "The main usage of URL (Uniform Resource Locater) is to be used as a web-address. Some URL\’s can be used to host unwanted content that can result in cyber-attacks. These URL\’s are called malicious URL’s. The inability of the user to detect and remove such URL\’s may lead the user in to a critical position and may lead to illegal access of user data. The malicious URL\'s can cause unethical activities such as theft of private and confidential data, ransomware installation on the user devices that result in huge loss every year globally. With the advancement of social networking platforms, many allow its users to publish the unauthorized URLs. The naive users who use the malicious URLs, are going to face serious security threats initiated by the nemesis. The main motive of Linkous is to detect such malicious URL and provide security to the end user. Certain efforts have been made in the direction so as to come up with the more robust malicious URL detection techniques which can change with respect to the evolving changes. Malicious websites more often look like legitimate websites Linkous helps the user to differentiate between the two. Linkous helps in preventing data loss, data theft and hardware failure by detecting malicious or fake URL\'s.",
                            style: TextStyle(fontSize: 15),
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        )
      ;
  }
}
