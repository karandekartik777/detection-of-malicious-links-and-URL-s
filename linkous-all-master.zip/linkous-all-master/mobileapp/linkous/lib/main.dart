import 'dart:async';
import 'dart:io';
import 'package:flutter/services.dart' show PlatformException;
import 'package:linkous/search/searchResult.dart';
import 'package:uni_links/uni_links.dart';
import 'dart:convert';
import 'package:connectivity/connectivity.dart';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:linkous/otherpages/AboutUs.dart';
import 'package:linkous/report/Report.dart';
import 'package:linkous/home/myHome.dart';
import 'package:linkous/settings/myThemes.dart';
import 'package:linkous/settings/routes.dart';
import 'package:linkous/search/searchURLHome.dart';
import 'package:linkous/login_register/userLogin.dart';
import 'package:linkous/login_register/userRegistration.dart';
import 'package:http/http.dart' as http;
StreamSubscription sub;
Future<Null> initUniLinks() async {

  String _initialLink;
  try {
    _initialLink = await getInitialLink();
   // print("\n\n\nhello" + _initialLink.toString() + "\n\n\n");
    //print("\n\n\nhello" + _initialLink!=null.toString() + "\n\n\n");
    if (_initialLink != null) {
      myHome.initialLink=_initialLink;
      myHome.opl.value = true;
      myHome.opl.notifyListeners();
      //print("done"+myHome.initialLink+"\n\n\n");
    }
//    else
//      myHome.openedWithLink = false;
    sub = getLinksStream().listen((String link) {
   //   print("\n\n\nhii" + link + "\n\n\n");
      if (link != null) {
        myHome.initialLink=link;
        myHome.opl.value = true;
        print("done"+myHome.initialLink+"\n\n\n");
      }
//      else
////        myHome.openedWithLink = false;
//      return;
    }, onError: (err) {
      myHome.errorOpeningLink = true;
    //  print("\n\n\nhii\n\n\n");
      return;
    });
  } on PlatformException {
    myHome.errorOpeningLink = true;
 //   print("\n\n\nhii\n\n\n");
    return;
  }
}
@override
void dispose()
{
  sub.cancel();
}
void main() async {
  myHome.opl.value=false;

  WidgetsFlutterBinding.ensureInitialized();
  String username = "",role="";
  bool loggedIn = false;
  String cookie;
  final storage = new FlutterSecureStorage();
  try {
    myHome.connectivityResult = await Connectivity().checkConnectivity();
    cookie = await storage.read(key: "Cookie");
    if (cookie != "" &&
        cookie != null &&
        myHome.connectivityResult != ConnectivityResult.none) {
      final checkLogin = await http.get(
          "http://linkous.herokuapp.com/api/test-auth",
          headers: {'Cookie': cookie});
      myHome.cookie = cookie;
      print(checkLogin.body);
      if (checkLogin.body.toString() != "You are not logged in") {
        loggedIn = true;
        username = checkLogin.body
            .toString()
            .split(" ")[3];
        role = checkLogin.body.toString().split(" ")[6];
      } else {
        loggedIn = false;
      }
    } else {
      loggedIn = false;
    }
    await initUniLinks();
  } on Exception catch (_) {
    loggedIn = false;
    //await storage.write(key: "Cookie", value: "");
  }
  myHome.loggedIn = loggedIn;
  myHome.username = username;
  myHome.userRole=role;
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
        initialRoute: '/',
        routes: {
          Routes.report: (context) => Report(""),
          Routes.search: (context) => searchURLHome(),
          Routes.login: (context) => login(""),
          Routes.register: (context) => register(),
          Routes.aboutUs: (context) => AboutUs(),
        },
       // darkTheme: ThemeData.dark(),
        theme: ThemeData(
          backgroundColor: myThemes.tertiary,
          textTheme: Theme.of(context).textTheme.apply(
              fontFamily: 'Montserrat',
              displayColor: Colors.white,
              bodyColor: Colors.white),
          dialogBackgroundColor: myThemes.tertiary,
        ),
        home: Home());
  }
}
