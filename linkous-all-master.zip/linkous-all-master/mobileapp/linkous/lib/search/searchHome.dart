import 'package:barcode_scan/barcode_scan.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:linkous/settings/settings.dart';
import 'package:linkous/home/myHome.dart';
import 'package:linkous/settings/routes.dart';
import 'package:linkous/settings/myThemes.dart';
import 'package:linkous/search//searchResult.dart';
import 'package:linkous/search/searchURLHome.dart';

class searchHome extends StatelessWidget {
  static RegExp exp = new RegExp(r"[a-z]+[:.]");
  static RegExp upiDetect = new RegExp("upi://");
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return WillPopScope(
      onWillPop: () {
        Navigator.of(context).pushNamedAndRemoveUntil(
            Routes.home, (Route<dynamic> route) => false);
        return ;
      },
      child: Scaffold(
          extendBodyBehindAppBar: true,
          appBar: PreferredSize(
            preferredSize: Size(double.infinity,300),
            child: AppBar(
              automaticallyImplyLeading: false,
              leading: IconButton(
                enableFeedback: false,
                  icon: Icon(Icons.arrow_back,size: 30,),splashColor: Colors.transparent,focusColor: Colors.transparent,
                  onPressed: () {
                    Navigator.pushNamedAndRemoveUntil(
                        context, Routes.home, (Route<dynamic> route) => false);
                  }),
              actions: <Widget>[
                Padding(
                  padding: const EdgeInsets.only(right:10),
                  child: Builder(builder: (context)=>IconButton(icon: Icon(CupertinoIcons.gear,size: 30,),onPressed: ()=>{Scaffold.of(context).openEndDrawer()},enableFeedback: false,)),
                )
              ],
              backgroundColor: Colors.transparent,
              title: Text('Search'),
              elevation: 0,
            ),
          ),
          endDrawer: AppDrawer(true, false),
          body: Container(
            width: myHome.width,
            height: myHome.height,
            decoration: myThemes.background,
            child: Padding(
              padding: const EdgeInsets.only(left: 10, right: 10),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Container(
                    height: 60,
                    padding: EdgeInsets.only(top: 5, bottom: 10),
                    width: myHome.width,
                    child: RaisedButton(
                      color: myThemes.primary,
                      shape: myThemes.buttonShape,
                      child: Text(
                        "Search using URL",
                        style: TextStyle(
                            fontSize: 15,
                            color: Colors.white,
                            fontFamily: 'Montserrat',
                            fontWeight: FontWeight.w900),
                      ),
                      onPressed: () {
                        try {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => searchURLHome()));
                        } on Exception catch (_) {
                          showDialog(
                              context: context,
                              child: AlertDialog(
                                title: Text(
                                    "Something went wrong,Please try again!"),
                                actions: <Widget>[
                                  FlatButton(
                                      onPressed: () =>
                                          Navigator.of(context).pop(false),
                                      child: Text("OK"))
                                ],
                              ));
                        }
                      },
                    ),
                  ),
                  Container(
                    height: 60,
                    padding: EdgeInsets.only(top: 5, bottom: 10),
                    width: myHome.width,
                    child: RaisedButton(
                      color: myThemes.secondaryButtonColor,
                      shape: myThemes.buttonShape,
                      child: Text(
                        "Scan QR Code",
                        style: TextStyle(
                            fontSize: 15,
                            color: myThemes.tertiary,
                            fontFamily: 'Montserrat',
                            fontWeight: FontWeight.w900),
                      ),
                      onPressed: () async {
                        String result = "";
                          result = await BarcodeScanner.scan();
                          exp.hasMatch(result)
                              ? upiDetect.hasMatch(result)?showDialog(
                              context: context,
                              child: AlertDialog(
                                title: Text(
                                    "UPI links are not supported yet!"),
                                actions: <Widget>[
                                  FlatButton(
                                      onPressed: () =>
                                          Navigator.of(context).pop(false),
                                      child: Text("OK"))
                                ],
                                titleTextStyle: myThemes.myDialogText,
                                contentTextStyle: myThemes.myDialogText,
                                shape: myThemes.myDialogShape,
                              )):Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) =>
                                          searchResultState(context, result, true)))
                              : showDialog(
                                  context: context,
                                  child: AlertDialog(
                                    title: Text(
                                        "QR code does not have any URL embedded in it!"),
                                    actions: <Widget>[
                                      FlatButton(
                                          onPressed: () =>
                                              Navigator.of(context).pop(false),
                                          child: Text("OK"))
                                    ],
                                    titleTextStyle: myThemes.myDialogText,
                                    contentTextStyle: myThemes.myDialogText,
                                    shape: myThemes.myDialogShape,
                                  ));
                      },
                    ),
                  ),
                ],
              ),
            ),
          )),
    );
  }
}
