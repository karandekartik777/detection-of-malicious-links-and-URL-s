import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:latlong/latlong.dart';
import 'package:linkous/home/myHome.dart';
import 'dart:async';
import 'dart:convert';
import 'package:linkous/report/reportButton.dart';

// ignore: camel_case_types
class fetchResult {
  static var resultDB, resultPR;
  static bool errorOccurred = false;

  static Future<void> result(String search) async {
    try {
      resultDB = await http.post("https://linkous.herokuapp.com/api/search",
          body: {'url': search});
      resultPR = await http.post("https://linkous.herokuapp.com/api/pagerank",
          body: {'url': search});
      if (jsonDecode(resultDB.body)["count"] != 0) {
        searchPerformer.presentInDatabase = true;
      } else {
        searchPerformer.presentInDatabase = false;
      }
    } on Exception catch (e) {
      errorOccurred = true;
      searchPerformer.noInternetError = true;
    }
  }
} //to check if url is reported into our data base

class _areDetailsRequired {
  String details;
  bool isMalicious;

  _areDetailsRequired(this.details, this.isMalicious);
} //to check if extra details are required and if link is malicious

class searchPerformer extends StatelessWidget {
  static String _searchURL,
      _isLinkUnsafeDB,
      _isLinkUnsafeLS,
      _isLinkUnsafeSA,
      _isLinkUnsafeCS,
      _isLinkUnsafePR,
      _isLinkUnsafe; //strings for warning text and search url
  static Color _horizontalLineColor = Color.fromRGBO(53, 98, 149,
      1.0); //colour of horizontal line between details and warning text
  static SizedBox _distanceBetweenDetails = new SizedBox(
    height: 15,
  ); //to set distance between 2 details when required
  static TextStyle _detailsTitleStyle = new TextStyle(
    color: Color.fromRGBO(146, 179, 216, 1.0),
  );
  static TextStyle _detailsStyle = new TextStyle(
    color: Color.fromRGBO(218, 228, 240, 1.0),
  );
  static TextStyle _titleStyle = new TextStyle(
    color: Color.fromRGBO(50, 134, 230, 1.0),
    fontWeight: FontWeight.bold,
    fontSize: 15,
  ); //style of title in result
  static Color _isRiskyColor = Color.fromRGBO(
      217, 118, 13, 1.0); //green colour for safe link warning text
  static TextStyle _isRiskyStyle = TextStyle(
    fontSize: 23,
    color: _isRiskyColor,
    fontWeight: FontWeight.bold,
  );
  static Color _isSafeColor = Color.fromRGBO(
      15, 146, 26, 1.0); //green colour for safe link warning text
  static TextStyle _isSafeStyle = TextStyle(
    fontSize: 23,
    color: _isSafeColor,
    fontWeight: FontWeight.bold,
  ); //style of warning text if safe
  static Color _isUnsafeColor = Color.fromRGBO(
      188, 61, 64, 1.0); //red colour for unsafe link warning text
  static TextStyle _isUnsafeStyle = TextStyle(
    fontSize: 23,
    color: _isUnsafeColor,
    fontWeight: FontWeight.bold,
  ); //style of warning text if unsafe
  static Color _containerBackground = Color.fromRGBO(
      38, 52, 68, 1); //background colour for the result list tile/containers
  static const EdgeInsets _myListTileContentPadding = EdgeInsets.only(
      top: 8,
      left: 10,
      right: 10,
      bottom: 8); //padding on each side of the text inside result containers
  static BoxDecoration _myContainerDecoration = BoxDecoration(
      color: _containerBackground,
      borderRadius: BorderRadius.circular(
          15)); //Box decoration for the result list tile/containers
  static const EdgeInsets _myContainerMargin =
      EdgeInsets.only(bottom: 25); //space between containers
  static const EdgeInsets _myTitlePadding =
      EdgeInsets.only(bottom: 10, top: 15); //space between title and subtitle
  static const EdgeInsets _myTablePadding = EdgeInsets.only(top: 5);
  static bool noInternetError = false; //to indicate loss of internet connection
  static bool presentInDatabase =
      false; // to indicate presence of link in our database
  static bool _completedDB = false,
      _completedLS = false,
      _completedCS = false,
      _completedPR = false,
      _websiteInfoUnavailable = false,
      _completedSA = false;
  static const EdgeInsets _myWarningTextPadding =
      EdgeInsets.only(bottom: 30, top: 15);

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Container(
      height: 0,
      width: 0,
    );
  }

  static Widget myResultBuilder(String title, String search, int i) {
    _searchURL = search;
    if (i == 0) {
      _completedDB = false;
      _completedLS = false;
      _completedCS = false;
      _completedPR = false;
      _completedSA = false;
      noInternetError = false;
      presentInDatabase = false;
      _websiteInfoUnavailable = false;
      fetchResult.errorOccurred = false;
    }
    return FutureBuilder(
        future: getSearchResult(search, title, i),
        builder: (BuildContext context, AsyncSnapshot a) {
          return a.connectionState == ConnectionState.waiting
              ? i < 7
                  ? Container(
                      //height: 125,
                      //width: 405,
                      margin: _myContainerMargin,
                      decoration: _myContainerDecoration,
                      child: ListTile(
                        title: Center(
                          child: Padding(
                            padding: _myTitlePadding,
                            child: Text(title, style: _titleStyle),
                          ),
                        ),
                        subtitle: Container(
                            height: 45,
                            child: SpinKitThreeBounce(
                              color: Colors.white70,
                              size: 30,
                            )),
                        contentPadding: _myListTileContentPadding,
                      ),
                    )
                  : Container(
                      height: 0,
                      width: 0,
                    )
              : a.data != null
                  ? a.data
                  : i == 6
                      ? Container(
                          decoration: _myContainerDecoration,
                          margin: _myContainerMargin,
                          child: ListTile(
                            title: Center(
                              child: Padding(
                                padding: _myTitlePadding,
                                child: Text(title, style: _titleStyle),
                              ),
                            ),
                            subtitle: Column(
                              children: <Widget>[
//
//                    Container(
//                      height: 5,
//                      padding: _myWarningTextPadding,
//                      color: _horizontalLineColor,
//                    ),
                                Center(
                                  child: Padding(
                                    padding: _myWarningTextPadding,
                                    child: Text(
                                      "Extra Info is Unavailable for this Website",
                                      style: _detailsTitleStyle,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        )
                      : Container(
                          height: 0,
                          width: 0,
                        );
        });
  }

  static Future<Widget> getSearchResult(
      String search, String title, int i) async {
    var apiResponse;
    _areDetailsRequired response;
    await fetchResult.result(search);
    if (fetchResult.errorOccurred)
      response = new _areDetailsRequired(
          "Lost Connection to the internet,Please Check your Internet Connection and try again!! ",
          false);
    try {
      if (i == 6) {
        apiResponse = myHome.userRole == "org"
            ? await http.post("https://linkous.herokuapp.com/api/website_info",
                headers: {'Cookie': myHome.cookie}, body: {'url': search})
            : await http.post("https://linkous.herokuapp.com/api/website_info",
                body: {'url': search});
        if (jsonDecode(apiResponse.body)["message"] == "invalid query")
          _websiteInfoUnavailable = true;
      } else if (i == 0) {
        await awaitResultCompletion();
        if (presentInDatabase)
          _isLinkUnsafe = "UNSAFE";
        else if ((_isLinkUnsafePR == "UNSAFE" &&
            (_isLinkUnsafeLS == "UNSAFE" || _isLinkUnsafeSA == "UNSAFE"||_isLinkUnsafeCS=="UNSAFE")))
          _isLinkUnsafe = "UNSAFE";
        else if (_isLinkUnsafePR == "UNSAFE")
          _isLinkUnsafe = "RISKY";
        else
          _isLinkUnsafe = "SAFE";
        return result(_areDetailsRequired("", false), i, title);
      } else if (i == 1) {
        apiResponse = fetchResult.resultDB;
      } else if (i == 2 &&
          (jsonDecode(fetchResult.resultDB.body)["count"]) == 0)
        apiResponse = await http.post(
            "https://linkous.herokuapp.com/api/lex-scan",
            body: {'url': search});
      else if (i == 3 && (jsonDecode(fetchResult.resultDB.body)["count"]) == 0)
        apiResponse = await http.post(
            "https://linkous.herokuapp.com/api/spam-scan",
            body: {'url': search});
      else if (i == 4 && (jsonDecode(fetchResult.resultDB.body)["count"]) == 0)
        apiResponse = fetchResult.resultPR;
      else if (i == 5 &&
          (jsonDecode(fetchResult.resultDB.body)["count"]) == 0) {
        apiResponse = await http.post(
            "https://linkous.herokuapp.com/api/content-scan",
            body: {'url': search});
        return result(contentResult(apiResponse.body), i, title);
      } else
        return result(_areDetailsRequired("", false), i, title);
      Map<String, dynamic> parsedApiResponse = json.decode(apiResponse.body);
      if (i == 1) if (parsedApiResponse["count"] != 0) {
        presentInDatabase = true;
      } else {
        presentInDatabase = false;
      }
      response = buildSearchResult(i, parsedApiResponse);
    } on Exception catch (_) {
      response = new _areDetailsRequired(
          "Lost Connection to the internet,Please Check your Internet Connection and try again!! ",
          false);
      noInternetError = true;
    }
    return result(response, i, title);
  } //get results from apis

  static _areDetailsRequired contentResult(var apiResponse) {
    String _message = "";
    int count = 0;
    if (jsonDecode(apiResponse).length == 0) {
      _isLinkUnsafeCS = "SAFE";
      return _areDetailsRequired("All 0 Links were found to be safe", false);
    }
    int totalCount = jsonDecode(apiResponse).length;
    for (var i in jsonDecode(apiResponse)) {
      if (i["detection"]["payload"] == true) {
        _message = _message +
            "\n" +
            i["tag"]["src"].toString() +
            "  -  <" +
            i["tag"]["tag"].toString() +
            ">\n\n";
        count++;
      } else if (i["detection"]["state"] != "safe") {
        _message = _message +
            "\n" +
            i["tag"]["src"].toString() +
            "  -  <" +
            i["tag"]["tag"].toString() +
            ">\n\n";
        count++;
      }
    }
    if (_message == "") {
      _isLinkUnsafeCS = "SAFE";
      return _areDetailsRequired(
          "All " + totalCount.toString() + " links were found to be safe.",
          false);
    } else {
      _isLinkUnsafeCS = "UNSAFE";
      _message = count.toString() +
          "/" +
          totalCount.toString() +
          " links were found to be Malicious!!sp" +
          _message;
    }
    return _areDetailsRequired(_message, true);
  } //function to parse response of content-scan as it has different format

  static Future<void> awaitResultCompletion() async {
    do {
      await new Future.delayed(new Duration(milliseconds: 250));
    } while (!presentInDatabase &&
        (!_completedDB ||
            !_completedCS ||
            !_completedLS ||
            !_completedPR ||
            !_completedSA) &&
        !noInternetError);
  } //await completion of all requests

  static dynamic buildSearchResult(
      int filterNo, Map<String, dynamic> apiResponse) {
    int checker;
    //return null
    print("\n\n\n" +
        apiResponse.toString() +
        "    " +
        filterNo.toString() +
        "\n\n\n");
    if (filterNo == 6) {
      print("hello" + (apiResponse["message"] == "invalid query").toString());
      print("\n\n\n" + myHome.userRole == "org" &&
          apiResponse["status"] == "success");
      if (myHome.userRole == "org" && apiResponse["status"] == "success") {
        if (apiResponse["lat"] == "null" || apiResponse["lat"] == null)
          _websiteInfoUnavailable = true;
      } else if ((apiResponse["message"] == "invalid query")) {
        _websiteInfoUnavailable = true;
        return
            _areDetailsRequired(
                "Extra Info for this website is unavailable", false);
      }
      return (myHome.userRole == "org" && apiResponse["status"] == "success")
          ? _areDetailsRequired(
              apiResponse["lat"].toString() +
                  "," +
                  apiResponse["lon"].toString() +
                  "," +
                  apiResponse["regionName"].toString() +
                  " (" +
                  apiResponse["region"].toString() +
                  ")," +
                  apiResponse["country"].toString() +
                  " (" +
                  apiResponse["countryCode"].toString() +
                  ")," +
                  apiResponse["continent"].toString() +
                  " (" +
                  apiResponse["continentCode"].toString() +
                  ")," +
                  apiResponse["query"].toString() +
                  "," +
                  apiResponse["as"].toString() +
                  " (" +
                  apiResponse["asname"].toString() +
                  ")," +
                  apiResponse["org"].toString() +
                  "," +
                  apiResponse["isp"].toString() +
                  "," +
                  apiResponse["hosting"].toString() +
                  "," +
                  apiResponse["mobile"].toString() +
                  "," +
                  apiResponse["proxy"].toString(),
              false)
          : _areDetailsRequired(
              apiResponse["regionName"].toString() +
                  " (" +
                  apiResponse["region"].toString() +
                  ")," +
                  apiResponse["country"].toString() +
                  " (" +
                  apiResponse["countryCode"].toString() +
                  ")," +
                  apiResponse["continent"].toString() +
                  " (" +
                  apiResponse["continentCode"].toString() +
                  ")," +
                  apiResponse["query"].toString(),
              false);
    } else if (filterNo == 1) {
      checker = apiResponse["count"];
      if (checker == 0) {
        _isLinkUnsafeDB = "SAFE";
        presentInDatabase = false;
        return _areDetailsRequired("", false);
      } else {
        _isLinkUnsafeDB = "UNSAFE";
        presentInDatabase = true;
        return _areDetailsRequired(
            apiResponse["count"].toString() +
                "," +
                apiResponse["first_report"].toString() +
                "," +
                apiResponse["valid_count"].toString() +
                "," +
                apiResponse["report_date"].toString(),
            true);
      }
    } else if (filterNo == 2) {
      print(apiResponse["result"].toString().split(" ")[1].substring(
          0, apiResponse["result"].toString().split(" ")[1].length - 1));
      if (apiResponse["result"].toString().split(" ")[1].substring(
              0, apiResponse["result"].toString().split(" ")[1].length - 1) ==
          "unsafe") {
        _isLinkUnsafeLS = "UNSAFE";
        return _areDetailsRequired("", true);
      }
      _isLinkUnsafeLS = "SAFE";
      return _areDetailsRequired("", false);
    } else if (filterNo == 3) {
      if (apiResponse["result"] == "unsafe") {
        _isLinkUnsafeSA = "UNSAFE";
        return _areDetailsRequired("", true);
      }
      _isLinkUnsafeSA = "SAFE";
      return _areDetailsRequired("", false);
    } else if (filterNo == 4) {
      if (apiResponse["result"] == "risky") {
        _isLinkUnsafePR = "UNSAFE";
        return _areDetailsRequired("", true);
      }
      _isLinkUnsafePR = "SAFE";
      return _areDetailsRequired("", false);
    } else if (filterNo == 5) {
      if (apiResponse["result"] == "unsafe") {
        _isLinkUnsafeCS = "UNSAFE";
        return _areDetailsRequired("", true);
      }
      _isLinkUnsafeCS = "SAFE";
      return _areDetailsRequired("", false);
    }
  }

//check if table required
  static Widget result(_areDetailsRequired myResponse, int i, String title) {
    if (i == 7) {
      return (jsonDecode(fetchResult.resultDB.body)["count"]) == 0
          ? reportButton(_searchURL)
          : Container(
              height: 0,
              width: 0,
            );
    }
    print("\n\n\n" + i.toString() + " " + title);
//    if(title == "Data Unavailable")

    return finalResultDisplay(myResponse, i, title);
  }

  static Widget finalResultDisplay(
      _areDetailsRequired myResponse, int i, String title) {
    if (i == 1 && myResponse.isMalicious) {
      print(DateFormat("E dd MMM y")
          .format(DateTime.parse(myResponse.details.split(",")[3])));
      var _details = myResponse.details;
      _completedDB = true;
      return Container(
        margin: _myContainerMargin,
        decoration: _myContainerDecoration,
        child: ListTile(
          title: Center(
            child: Padding(
              padding: _myTitlePadding,
              child: Text(title, style: _titleStyle),
            ),
          ),
          subtitle: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Center(
                child: Padding(
                  padding: _myWarningTextPadding,
                  child: Text(
                    _isLinkUnsafeDB,
                    style: _isLinkUnsafeDB == "UNSAFE"
                        ? _isUnsafeStyle
                        : _isSafeStyle,
                  ),
                ),
              ),
              Container(
                height: 5,
                padding: _myWarningTextPadding,
                color: _horizontalLineColor,
              ),
              SizedBox(
                height: 30,
              ),
              Padding(
                padding: EdgeInsets.only(bottom: 5),
                child: Text(
                  "Total Reports",
                  style: _detailsTitleStyle,
                ),
              ),
              Padding(
                padding: EdgeInsets.only(bottom: 5),
                child: Text(
                  _details.split(",")[0],
                  style: _detailsStyle,
                ),
              ),
              _distanceBetweenDetails,
              Padding(
                padding: EdgeInsets.only(bottom: 5),
                child: Text(
                  "First Reporter",
                  style: _detailsTitleStyle,
                ),
              ),
              Padding(
                padding: EdgeInsets.only(bottom: 5),
                child: Text(
                  _details.split(",")[1],
                  style: _detailsStyle,
                ),
              ),
              _distanceBetweenDetails,
              Padding(
                padding: EdgeInsets.only(bottom: 5),
                child: Text(
                  "Validated Reports",
                  style: _detailsTitleStyle,
                ),
              ),
              Padding(
                padding: EdgeInsets.only(bottom: 5),
                child: Text(
                  _details.split(",")[2],
                  style: _detailsStyle,
                ),
              ),
              _distanceBetweenDetails,
              Padding(
                padding: EdgeInsets.only(bottom: 5),
                child: Text(
                  "First Reported",
                  style: _detailsTitleStyle,
                ),
              ),
              Padding(
                padding: EdgeInsets.only(bottom: 10),
                child: Text(
                  DateFormat("EEEE, dd MMM y")
                      .format(DateTime.parse(myResponse.details.split(",")[3])),
                  style: _detailsStyle,
                ),
              ),
            ],
          ),
          contentPadding: _myListTileContentPadding,
        ),
      );
    } else {
      if (i > 1 && (jsonDecode(fetchResult.resultDB.body)["count"]) != 0&&i!=6) {
        return Container(height: 0, width: 0);
      }
      switch (i) {
        case 0:
          return Container(
            margin: _myContainerMargin,
            decoration: _myContainerDecoration,
            child: ListTile(
              title: Center(
                child: Padding(
                  padding: _myTitlePadding,
                  child: Text(title, style: _titleStyle),
                ),
              ),
              subtitle: Center(
                child: Padding(
                  padding: _myWarningTextPadding,
                  child: Text(
                    _isLinkUnsafe,
                    style: _isLinkUnsafe == "UNSAFE"
                        ? _isUnsafeStyle
                        : _isLinkUnsafe == "SAFE"
                            ? _isSafeStyle
                            : _isRiskyStyle,
                  ),
                ),
              ),
              contentPadding: _myListTileContentPadding,
            ),
          );
          break;
        case 1:
          _completedDB = true;
          return Container(
            margin: _myContainerMargin,
            decoration: _myContainerDecoration,
            child: ListTile(
              title: Center(
                child: Padding(
                  padding: _myTitlePadding,
                  child: Text(title, style: _titleStyle),
                ),
              ),
              subtitle: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Padding(
                    padding: _myWarningTextPadding,
                    child: Text(
                      _isLinkUnsafeDB,
                      style: _isLinkUnsafeDB == "UNSAFE"
                          ? _isUnsafeStyle
                          : _isSafeStyle,
                    ),
                  ),
                ],
              ),
              contentPadding: _myListTileContentPadding,
            ),
          );
          break;
        case 2:
          _completedLS = true;
          return Container(
            margin: _myContainerMargin,
            decoration: _myContainerDecoration,
            child: ListTile(
              title: Center(
                child: Padding(
                  padding: _myTitlePadding,
                  child: Text(title, style: _titleStyle),
                ),
              ),
              subtitle: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Padding(
                    padding: _myWarningTextPadding,
                    child: Text(
                      _isLinkUnsafePR == "UNSAFE"
                          ? _isLinkUnsafeLS
                          : _isLinkUnsafePR,
                      style: _isLinkUnsafePR == "UNSAFE"
                          ? _isLinkUnsafeLS == "UNSAFE"
                              ? _isUnsafeStyle
                              : _isSafeStyle
                          : _isSafeStyle,
                    ),
                  ),
                ],
              ),
              contentPadding: _myListTileContentPadding,
            ),
          );
          break;
        case 3:
          _completedSA = true;
          return Container(
            margin: _myContainerMargin,
            decoration: _myContainerDecoration,
            child: ListTile(
              title: Center(
                child: Padding(
                  padding: _myTitlePadding,
                  child: Text(title, style: _titleStyle),
                ),
              ),
              subtitle: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Padding(
                    padding: _myWarningTextPadding,
                    child: Text(
                      _isLinkUnsafePR == "UNSAFE"
                          ? _isLinkUnsafeSA
                          : _isLinkUnsafePR,
                      style: _isLinkUnsafePR == "UNSAFE"
                          ? _isLinkUnsafeSA == "UNSAFE"
                              ? _isUnsafeStyle
                              : _isSafeStyle
                          : _isSafeStyle,
                    ),
                  ),
                ],
              ),
              contentPadding: _myListTileContentPadding,
            ),
          );
          break;
        case 4:
          _completedPR = true;
          return Container(
            margin: _myContainerMargin,
            decoration: _myContainerDecoration,
            child: ListTile(
              title: Center(
                child: Padding(
                  padding: _myTitlePadding,
                  child: Text(title, style: _titleStyle),
                ),
              ),
              subtitle: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Padding(
                    padding: _myWarningTextPadding,
                    child: Text(
                      _isLinkUnsafePR,
                      style: _isLinkUnsafePR == "UNSAFE"
                          ? _isUnsafeStyle
                          : _isSafeStyle,
                    ),
                  ),
                ],
              ),
              contentPadding: _myListTileContentPadding,
            ),
          );
          break;
        case 5:
          _completedCS = true;
          print(myResponse.details);
          return Container(
            margin: _myContainerMargin,
            decoration: _myContainerDecoration,
            child: ListTile(
              title: Center(
                child: Padding(
                  padding: _myTitlePadding,
                  child: Text(title, style: _titleStyle),
                ),
              ),
              subtitle: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Padding(
                    padding: _myWarningTextPadding,
                    child: Text(
                      _isLinkUnsafeCS,
                      style: _isLinkUnsafeCS == "UNSAFE"
                          ? _isUnsafeStyle
                          : _isSafeStyle,
                    ),
                  ),
                  _isLinkUnsafeCS == "UNSAFE"
                      ? Center(
                          child: Padding(
                            padding: _myWarningTextPadding,
                            child: Text(
                              myResponse.details.split("sp")[0],
                              style: _detailsTitleStyle,
                            ),
                          ),
                        )
                      : Center(
                    child: Padding(
                      padding: _myWarningTextPadding,
                      child: Text(
                        myResponse.details,
                        style: _detailsTitleStyle,
                      ),
                    ),
                  ),
                  _isLinkUnsafeCS == "UNSAFE"
                      ? Padding(
                          padding: _myWarningTextPadding,
                          child: Text(
                            myResponse.details.split("sp")[1],
                            style: _detailsStyle,
                          ),
                        )
                      : Container(
                          height: 0,
                          width: 0,
                        )
                ],
              ),
              contentPadding: _myListTileContentPadding,
            ),
          );
          break;
        case 6:
          print(_websiteInfoUnavailable);
          var _latitude, _longitude;
          if (_websiteInfoUnavailable)
            return Container(
              decoration: _myContainerDecoration,
              margin: _myContainerMargin,
              child: ListTile(
                title: Center(
                  child: Padding(
                    padding: _myTitlePadding,
                    child: Text(title, style: _titleStyle),
                  ),
                ),
                subtitle: Column(
                  children: <Widget>[
//
//                    Container(
//                      height: 5,
//                      padding: _myWarningTextPadding,
//                      color: _horizontalLineColor,
//                    ),
                    Center(
                      child: Padding(
                        padding: _myWarningTextPadding,
                        child: Text(
                          myResponse.details,
                          style: _detailsTitleStyle,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          //print(myResponse.details + "\n\n\n");
          else {
            if (myHome.userRole == "org" && !_websiteInfoUnavailable) {
              try {
                _latitude = double.parse(myResponse.details.split(",")[0]);
                _longitude = double.parse(myResponse.details.split(",")[1]);
              } on FormatException {
                print('Format error!');
                _longitude = 0.0;
                _latitude = 0.0;
              }
            }
            return Container(
              margin: _myContainerMargin,
              decoration: _myContainerDecoration,
              child: ListTile(
                title: Center(
                  child: Padding(
                    padding: _myTitlePadding,
                    child: Text(title, style: _titleStyle),
                  ),
                ),
                subtitle: Column(
                  children: <Widget>[
                    Padding(
                      padding: _myWarningTextPadding,
                      child: _isMapRequired(myHome.userRole == "org", _latitude,
                          _longitude, myResponse.details),
                    ),
                  ],
                ),
                contentPadding: _myListTileContentPadding,
              ),
            );
          }
          break;
      }
      return Container(
        height: 0,
        width: 0,
      );
    }
  }

  //function to return website info according to user's privilege
  static Widget _isMapRequired(
      bool _isUserORG, var _latitude, var _longitude, String _details) {
    return _isUserORG
        ? Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Padding(
                padding: _myWarningTextPadding,
                child: Container(
                  height: 5,
                  color: Color.fromRGBO(53, 98, 149, 1.0),
                ),
              ),
              !_websiteInfoUnavailable
                  ? Padding(
                      padding: _myWarningTextPadding,
                      child: Container(
                        height: myHome.blockSizeVertical * 25,
                        child: FlutterMap(
                          options: new MapOptions(
                            center: new LatLng(_latitude, _longitude),
                            zoom: 13.0,
                          ),
                          layers: [
                            new TileLayerOptions(
                              urlTemplate: "https://api.tiles.mapbox.com/v4/"
                                  "{id}/{z}/{x}/{y}@2x.png?access_token={accessToken}",
                              additionalOptions: {
                                'accessToken':
                                    'pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw',
                                'id': 'mapbox.streets',
                              },
                            ),
                            new MarkerLayerOptions(
                              markers: [
                                new Marker(
                                  width: 80.0,
                                  height: 80.0,
                                  point: new LatLng(_latitude, _longitude),
                                  builder: (ctx) => new Container(
                                    child: Icon(
                                      Icons.location_on,
                                      color: Colors.red,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    )
                  : Container(
                      height: 0,
                      width: 0,
                    ),
              Padding(
                padding: _myWarningTextPadding,
                child: Container(
                  height: 5,
                  color: Color.fromRGBO(53, 98, 149, 1.0),
                ),
              ),
              Padding(
                padding: EdgeInsets.only(bottom: 5),
                child: Text(
                  "Region",
                  style: _detailsTitleStyle,
                ),
              ),
              Padding(
                padding: EdgeInsets.only(bottom: 5),
                child: Text(
                  _details.split(",")[2],
                  style: _detailsStyle,
                ),
              ),
              _distanceBetweenDetails,
              Padding(
                padding: EdgeInsets.only(bottom: 5),
                child: Text(
                  "Country",
                  style: _detailsTitleStyle,
                ),
              ),
              Padding(
                padding: EdgeInsets.only(bottom: 5),
                child: Text(
                  _details.split(",")[3],
                  style: _detailsStyle,
                ),
              ),
              _distanceBetweenDetails,
              Padding(
                padding: EdgeInsets.only(bottom: 5),
                child: Text(
                  "Continent",
                  style: _detailsTitleStyle,
                ),
              ),
              Padding(
                padding: EdgeInsets.only(bottom: 5),
                child: Text(
                  _details.split(",")[4],
                  style: _detailsStyle,
                ),
              ),
              _distanceBetweenDetails,
              Padding(
                padding: EdgeInsets.only(bottom: 5),
                child: Text(
                  "IP",
                  style: _detailsTitleStyle,
                ),
              ),
              Padding(
                padding: EdgeInsets.only(bottom: 5),
                child: Text(
                  _details.split(",")[5],
                  style: _detailsStyle,
                ),
              ),
              _distanceBetweenDetails,
              Padding(
                padding: EdgeInsets.only(bottom: 5),
                child: Text(
                  "Latitude,Longitude",
                  style: _detailsTitleStyle,
                ),
              ),
              Padding(
                padding: EdgeInsets.only(bottom: 5),
                child: Text(
                  _latitude.toString() + "," + _longitude.toString(),
                  style: _detailsStyle,
                ),
              ),
              _distanceBetweenDetails,
              Padding(
                padding: EdgeInsets.only(bottom: 5),
                child: Text(
                  "ASN",
                  style: _detailsTitleStyle,
                ),
              ),
              Padding(
                padding: EdgeInsets.only(bottom: 5),
                child: Text(
                  _details.split(",")[6],
                  style: _detailsStyle,
                ),
              ),
              _distanceBetweenDetails,
              Padding(
                padding: EdgeInsets.only(bottom: 5),
                child: Text(
                  "Organization",
                  style: _detailsTitleStyle,
                ),
              ),
              Padding(
                padding: EdgeInsets.only(bottom: 5),
                child: Text(
                  _details.split(",")[7],
                  style: _detailsStyle,
                ),
              ),
              _distanceBetweenDetails,
              Padding(
                padding: EdgeInsets.only(bottom: 5),
                child: Text(
                  "ISP",
                  style: _detailsTitleStyle,
                ),
              ),
              Padding(
                padding: EdgeInsets.only(bottom: 5),
                child: Text(
                  _details.split(",")[8],
                  style: _detailsStyle,
                ),
              ),
              _distanceBetweenDetails,
              Padding(
                padding: EdgeInsets.only(bottom: 5),
                child: Text(
                  "Hosting",
                  style: _detailsTitleStyle,
                ),
              ),
              Padding(
                padding: EdgeInsets.only(bottom: 5),
                child: Text(
                  _details.split(",")[9] == "true" ? "Yes" : "No",
                  style: _detailsStyle,
                ),
              ),
              _distanceBetweenDetails,
              Padding(
                padding: EdgeInsets.only(bottom: 5),
                child: Text(
                  "Mobile",
                  style: _detailsTitleStyle,
                ),
              ),
              Padding(
                padding: EdgeInsets.only(bottom: 5),
                child: Text(
                  _details.split(",")[10] == "true" ? "Yes" : "No",
                  style: _detailsStyle,
                ),
              ),
              _distanceBetweenDetails,
              Padding(
                padding: EdgeInsets.only(bottom: 5),
                child: Text(
                  "Proxy",
                  style: _detailsTitleStyle,
                ),
              ),
              Padding(
                padding: EdgeInsets.only(bottom: 5),
                child: Text(
                  _details.split(",")[11] == "true" ? "Yes" : "No",
                  style: _detailsStyle,
                ),
              ),
            ],
          )
        : Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Padding(
                padding: _myWarningTextPadding,
                child: Container(
                  height: 5,
                  color: Color.fromRGBO(53, 98, 149, 1.0),
                ),
              ),
//              SizedBox(
//                height: 10,
//              ),
              Padding(
                padding: EdgeInsets.only(bottom: 5),
                child: Text(
                  "Region",
                  style: _detailsTitleStyle,
                ),
              ),
              Padding(
                padding: EdgeInsets.only(bottom: 5),
                child: Text(
                  _details.split(",")[0],
                  style: _detailsStyle,
                ),
              ),
              _distanceBetweenDetails,
              Padding(
                padding: EdgeInsets.only(bottom: 5),
                child: Text(
                  "Country",
                  style: _detailsTitleStyle,
                ),
              ),
              Padding(
                padding: EdgeInsets.only(bottom: 5),
                child: Text(
                  _details.split(",")[1],
                  style: _detailsStyle,
                ),
              ),
              _distanceBetweenDetails,
              Padding(
                padding: EdgeInsets.only(bottom: 5),
                child: Text(
                  "Continent",
                  style: _detailsTitleStyle,
                ),
              ),
              Padding(
                padding: EdgeInsets.only(bottom: 5),
                child: Text(
                  _details.split(",")[2],
                  style: _detailsStyle,
                ),
              ),
              _distanceBetweenDetails,
              Padding(
                padding: EdgeInsets.only(bottom: 5),
                child: Text(
                  "IP",
                  style: _detailsTitleStyle,
                ),
              ),
              Padding(
                padding: EdgeInsets.only(bottom: 5),
                child: Text(
                  _details.split(",")[3],
                  style: _detailsStyle,
                ),
              ),
            ],
          );
  }
}
