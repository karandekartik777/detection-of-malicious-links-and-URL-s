import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:linkous/settings/settings.dart';
import 'package:linkous/home/myHome.dart';
import 'package:linkous/settings/routes.dart';
import 'package:linkous/search/searchBar.dart';
import 'package:linkous/settings/myThemes.dart';

class searchURLHome extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return WillPopScope(
      onWillPop: (){
//        myHome.openedWithLink=false;
        print("\n\n\n\n\n");
        Navigator.of(context).pushNamedAndRemoveUntil(Routes.home, (Route<dynamic> route) => false);
        return null;
      },
      child: Scaffold(
          extendBodyBehindAppBar: true,
          appBar: AppBar(
            automaticallyImplyLeading: false,
            leading: IconButton(
                icon: Icon(Icons.arrow_back),
                onPressed: () {
//                  myHome.openedWithLink=false;
                  Navigator.pushNamedAndRemoveUntil(
                      context, Routes.home, (Route<dynamic> route) => false);
                }),
            backgroundColor: Colors.transparent,
            title: Text('Search using URL'),
            elevation: 0,
          ),
          endDrawer: AppDrawer(true,false),
          body: Container(
            width: myHome.width,
            height: myHome.height,
            decoration: myThemes.background,
            child: Align(
              alignment: Alignment.center,
              child: Padding(
                padding: const EdgeInsets.only(left: 10, right: 10),
                child: searchBar(null),
              ),
            ),
          )),
    );
  }
}
