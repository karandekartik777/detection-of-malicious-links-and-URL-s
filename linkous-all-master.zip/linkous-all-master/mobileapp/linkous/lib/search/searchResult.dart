
import 'dart:ui';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:linkous/home/myHome.dart';
import 'package:linkous/search/Search.dart';
import 'package:linkous/settings/myThemes.dart';
import 'package:linkous/search/searchBar.dart';
import 'package:linkous/search/searchHome.dart';

// ignore: must_be_immutable, camel_case_types
class searchResultState extends StatefulWidget {
  BuildContext context;
  String _url;
  bool _qrScanner;

  searchResultState(this.context, this._url, this._qrScanner){
   myHome.opl.value=false;
//   _url=myHome.initialLink;
//   myHome.initialLink="";
  }

  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return searchResult(context, _url, _qrScanner);
  }
}

class searchResult extends State<searchResultState> {
  List list;
  String _url;
  static String urls;
  static bool qrScanned,
      _isPresentInDatabase = false;

  searchResult(BuildContext context, String url, bool qrScanner) {
    this._url = url;
    qrScanned = qrScanner;
    urls = url;
    //build(context);
  }
static Color searchBarBackground = Color.fromRGBO(42, 40, 75, 1.0);
  @override
  Widget build(BuildContext context) {
    TextEditingController _myController = TextEditingController(text: urls);
    myHome.myContext=context;
    //myHome.initialLink="";

    // TODO: implement build
    return  Scaffold(
      //backgroundColor: myThemes.tertiary,
      //backgroundColor: Color.fromRGBO(55, 71, 79, 100),
        //extendBodyBehindAppBar: true,
        //resizeToAvoidBottomPadding: false,
      backgroundColor: searchBarBackground,
        appBar: PreferredSize(
          preferredSize: Size(myHome.width, 80),
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.only(top: 8, right: 10, left: 10),
              child: AppBar(
                automaticallyImplyLeading: false,
                backgroundColor: searchBarBackground,
                elevation: 0,
                title: searchBar(urls),
                titleSpacing: 0,
              ),
            ),
          ),
        ),
        //drawer: AppDrawer(),
        body: Container(
          padding: EdgeInsets.only(top: myHome.blockSizeVertical * 1.5),
          //width: myHome.width,
          //height: myHome.height,
          decoration: myThemes.background,
          child: Center(
              child: ListView.builder(
                padding: EdgeInsets.only(top: 8, left: 10, right: 10),
                itemBuilder: get,
                itemCount: 8,
              )),
        ) //Container(height:600,padding: EdgeInsets.only(left: 7,right: 7), child: searchBar())),
    );
  }

  Widget get(BuildContext context, int i) {
    if (!searchPerformer.noInternetError) {
      if (i == 6 && !searchPerformer.noInternetError)
        return searchPerformer.myResultBuilder(
            "WEBSITE INFO", _url, i);
      if (i == 0 && !searchPerformer.noInternetError)
        return searchPerformer.myResultBuilder(
            "OVERALL", _url, i);
      if (i == 1 && !searchPerformer.noInternetError)
        return searchPerformer.myResultBuilder(
            "DATABASE", _url, i);
      else if (i == 2 &&
          !searchPerformer.noInternetError )
        return !_isPresentInDatabase
            ? searchPerformer.myResultBuilder(
            "LEXICAL ANALYSIS", _url, i)
            : Container(
          height: 0,
          width: 0,
        );
      else if (i == 3 &&
          !searchPerformer.noInternetError )
        return !_isPresentInDatabase
            ? searchPerformer.myResultBuilder(
            "SPAM ANALYSIS", _url, i)
            : Container(
          height: 0,
          width: 0,
        );
      else if (i == 4 &&
          !searchPerformer.noInternetError )
        return !_isPresentInDatabase
            ? searchPerformer.myResultBuilder(
            "PAGERANK", _url, i)
            : Container(
          height: 0,
          width: 0,
        );
      else if ( i == 5 && !searchPerformer.noInternetError)
        return searchPerformer.myResultBuilder(
            "CONTENT SCAN", _url, i);
      else if ( i == 7 && !searchPerformer.noInternetError)
        return searchPerformer.myResultBuilder(
            "Report Button", _url, i);
    } else if (searchPerformer.noInternetError) {
      showDialog(
          context: context,
          builder: (context) =>
              AlertDialog(
                title: Text(
                    "Lost Internet Connection,Please Check your Internet Connection and try again!! "),
                actions: <Widget>[
                  new FlatButton(
                    onPressed: () =>
                        Navigator.pushAndRemoveUntil(
                            context,
                            MaterialPageRoute(
                                builder: (context) => searchHome()),
                                (Route<dynamic> route) => false),
                    child: new Text('OK'),
                  ),
                ],
                titleTextStyle: myThemes.myDialogText,
                contentTextStyle: myThemes.myDialogText,
                shape: myThemes.myDialogShape,
              ));
    } else {
      Container(
        height: 0,
        width: 0,
      );
    }
    return Container(
      height: myHome.blockSizeVertical*15,
      width: myHome.width,
      child: Text(
          "Lost Internet Connection,Please Check your Internet Connection and try again!! "),
    );
  }
}