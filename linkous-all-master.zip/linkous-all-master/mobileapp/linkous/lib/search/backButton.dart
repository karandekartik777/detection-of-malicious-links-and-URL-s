import 'package:flutter/material.dart';
import 'package:linkous/settings/routes.dart';
import 'package:linkous/settings/myThemes.dart';

class backButton extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return RaisedButton(
      shape: RoundedRectangleBorder(
        borderRadius: new BorderRadius.circular(9),
      ),
      onPressed: () {
        Navigator.popUntil(context, (r) => r.settings.name == Routes.search);
      },
      child: const Text('Back', style: TextStyle(fontSize: 20)),
      color: myThemes.secondary,
      textColor: Colors.white,
      elevation: 5,
    );
  }
}
