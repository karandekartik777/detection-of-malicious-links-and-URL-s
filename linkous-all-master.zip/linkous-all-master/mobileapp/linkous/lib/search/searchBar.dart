import 'package:connectivity/connectivity.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:linkous/home/myHome.dart';
import 'package:linkous/settings/myThemes.dart';
import 'package:linkous/search/searchHome.dart';
import 'package:linkous/search/searchResult.dart';

class searchBar extends StatelessWidget {
  String _url;

  searchBar(String url) {
    _urls = url;
    this._url = url;
  }

  static String _urls;
  TextEditingController _myController = TextEditingController(text: _urls);

  @override
  Widget build(BuildContext context) {
    _myController.text = _urls;
    // TODO: implement build
    return TextField(
      onChanged: (String url) {
        _url = url;
      },
      style: TextStyle(color: Colors.white),
      textAlign: TextAlign.center,
      textAlignVertical: TextAlignVertical.center,
      cursorColor: Colors.indigo,
      decoration: InputDecoration(
          contentPadding: _urls != null
              ? EdgeInsets.only(left: myHome.blockSize * 10)
              : EdgeInsets.zero,
          //alignLabelWithHint: true,

          prefixIcon: _urls != null
              ? IconButton(
                  icon: Icon(
                    Icons.arrow_back,
                    color: Colors.white,
                  ),
                  onPressed: () {
                    _urls = null;
                    _url = null;
//                    myHome.openedWithLink=false;
                    Navigator.pushAndRemoveUntil(
                        context,
                        MaterialPageRoute(builder: (context) => searchHome()),
                        (Route<dynamic> route) => false);
                    //Navigator.pushNamed(context, Routes.search);
                  })
              : null,
          hintText: "Search for malicious link",
          hintStyle: myThemes.textFieldHintColor,
          filled: true,
          fillColor: myThemes.textFieldColor,
          border: new OutlineInputBorder(
            borderSide: BorderSide(
              width: 0,
              style: BorderStyle.none,
            ),
            borderRadius: const BorderRadius.all(
              const Radius.circular(5),
            ),
          )),
      controller: _myController,
      onSubmitted: (String Search) async {
        _url == null
            ? _urls == null ? this._url = Search : _url = _urls
            : _url = _url;
        if (await Connectivity().checkConnectivity() != ConnectivityResult.none) {
          Navigator.pop(context);
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => searchResultState(context, _url, false)));
        }
        else
          showDialog(
              context: context,
              builder: (context) => AlertDialog(
                title: Text("No Internet Connection,Please check your Internet Connection and try again!!! "),
                actions: <Widget>[
                  new FlatButton(
                    onPressed: () =>
                        Navigator.of(context).pop(false),
                    child: new Text('OK'),
                  ),
                ],
                titleTextStyle: myThemes.myDialogText,
                contentTextStyle: myThemes.myDialogText,
                shape: myThemes.myDialogShape,
              ));
      },
    );
  }
}
