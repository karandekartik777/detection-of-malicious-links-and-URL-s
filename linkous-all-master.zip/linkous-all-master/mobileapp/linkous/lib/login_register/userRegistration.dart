import 'dart:convert';
import 'dart:io';

import 'package:connectivity/connectivity.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:linkous/login_register/userLogin.dart';
import 'package:linkous/settings/routes.dart';
import 'package:linkous/settings/myThemes.dart';
import 'package:email_validator/email_validator.dart';
import 'package:http/http.dart' as http;

// ignore: camel_case_types
class register extends StatefulWidget {
  @override
  userRegistration createState() {
    // TODO: implement createState
    return userRegistration();
  }
}

// ignore: camel_case_types
class userRegistration extends State<register> {
  static Color _containerBackground = Color.fromRGBO(
      38, 52, 68, 1); //background colour for the result list tile/containers
//padding on each side of the text inside result containers
  static BoxDecoration _myContainerDecoration = BoxDecoration(
      color: _containerBackground, borderRadius: BorderRadius.circular(15));
  String _userName;
  String _password;
  String _email;
  String _eMessage = "Please enter Valid EmailId";
  String _uMessage = "Please enter Username";
  String _pMessage = "Please enter Password";
  final _emailController = TextEditingController();
  final _userNameController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _validateEmail = false;
  bool _validateUsername = false;
  bool _validatePassword = false;
  TextStyle _titleStyle =
      TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w600);
  bool _checked = false;

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Container(
      decoration: myThemes.background,
      child: Scaffold(
        backgroundColor: Colors.transparent,
        resizeToAvoidBottomInset: true,
        //resizeToAvoidBottomInset: true,
        //extendBodyBehindAppBar: true,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          title: Text('Registration'),
          elevation: 0,
        ),
        // drawer: AppDrawer(),
        body: Padding(
          padding: EdgeInsets.only(left: 15, right: 15),
          child: Column(
            //mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.start,
            //crossAxisAlignment: CrossAxisAlignment.start,
            //shrinkWrap: true,
            //physics: NeverScrollableScrollPhysics(),

            children: <Widget>[
              SizedBox(height: 15,),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Padding(
                    padding: EdgeInsets.only(bottom: 5),
                    child: Text(
                      "Name",
                      style: _titleStyle,
                    ),
                  ),
                  Container(
                    padding: EdgeInsets.all(0),
                    margin: EdgeInsets.all(0),
                    height: 55,
                    child: TextField(
                      onChanged: (username) {
                        this._userName = username;
                      },
                      textAlignVertical: TextAlignVertical.center,
                      style: TextStyle(color: Colors.white),
                      cursorColor: Colors.indigo,
                      decoration: InputDecoration(
                          errorText: _validateUsername ? _uMessage : null,
                          //hintText: "UserName",
                          //hintStyle: TextStyle(color: Color.fromRGBO(0, 0, 0, 0.5)),
                          filled: true,
                          fillColor: !_checked
                              ? myThemes.textFieldColor
                              : Color.fromRGBO(0, 0, 0, 0.20),
                          border: new OutlineInputBorder(
                            borderSide: BorderSide(
                              width: 0,
                              style: BorderStyle.none,
                            ),
                            borderRadius: const BorderRadius.all(
                              const Radius.circular(9),
                            ),
                          )),
                      controller: _userNameController,
                      onSubmitted: (username) {
                        setState(() {
                          (username = null)
                              ? _validateUsername = true
                              : _validateUsername = false;
                        });
                        _userName = username;
                      },
                    ),
                  ),
                ],
              ),
              SizedBox(height: 12,),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    "Email",
                    style: _titleStyle,
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 5),
                    child: Container(
                      height: 55,
                      padding: EdgeInsets.all(0),
                      margin: EdgeInsets.all(0),
                      child: TextField(
                        textAlignVertical: TextAlignVertical.center,
                        onChanged: (email) {
                          this._email = email;
                          if (_checked) {
                            setState(() {
                              _userNameController.text = this._email;
                              this._userName = this._email;
                              //_checked = true;
                            });
                          }
                        },
                        style: TextStyle(color: Colors.white),
                        cursorColor: Colors.indigo,
                        decoration: InputDecoration(
                            errorText: _validateEmail ? _eMessage : null,
                            //hintText: "UserName",
                            //hintStyle: TextStyle(color: Color.fromRGBO(0, 0, 0, 0.5)),
                            filled: true,
                            fillColor: myThemes.textFieldColor,
                            border: new OutlineInputBorder(
                              borderSide: BorderSide(
                                width: 0,
                                style: BorderStyle.none,
                              ),
                              borderRadius: const BorderRadius.all(
                                const Radius.circular(9),
                              ),
                            )),
                        controller: _emailController,
                        onSubmitted: (email) {
                          setState(() {
                            (email = null)
                                ? _validateEmail = true
                                : _validateEmail = false;
                          });
                          _email = email;
                        },
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 12,),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Padding(
                    padding: EdgeInsets.only(bottom: 0),
                    child: Text(
                      "Password",
                      style: _titleStyle,
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top:5,bottom: 8),
                    child: Container(
                      margin: EdgeInsets.all(0),
                      padding: EdgeInsets.all(0),
                      height: 55,
                      child: TextField(
                        textAlignVertical: TextAlignVertical.center,
                        obscureText: true,
                        onChanged: (password) {
                          this._password = password;
                        },
                        style: TextStyle(color: Colors.white),
                        cursorColor: Colors.indigo,
                        decoration: InputDecoration(
                            errorText: _validatePassword ? _pMessage : null,
                            //hintText: "Password",
                            //hintStyle: TextStyle(color: Color.fromRGBO(0, 0, 0, 0.5)),
                            filled: true,
                            fillColor: myThemes.textFieldColor,
                            border: new OutlineInputBorder(
                              borderSide: BorderSide(
                                width: 0,
                                style: BorderStyle.none,
                              ),
                              borderRadius: const BorderRadius.all(
                                const Radius.circular(9),
                              ),
                            )),
                        controller: _passwordController,
                        onSubmitted: (password) {
                          this._password = password;
                        },
                      ),
                    ),
                  ),
                ],
              ),
              Align(
                alignment: Alignment.centerRight,
                //padding: const EdgeInsets.only(left: 120, right: 120),
                child: RaisedButton(
                  onPressed: () async {
                    setState(() {
                      _userNameController.text.isEmpty
                          ? _validateUsername = true
                          : _validateUsername = false;
                      _passwordController.text.isEmpty
                          ? _validatePassword = true
                          : _validatePassword = false;
                      _emailController.text.isEmpty
                          ? _validateEmail = true
                          : _validateEmail = false;
                      EmailValidator.validate(_email)
                          ? _validateEmail = false
                          : _validateEmail = true;
                    });
                    if (_userNameController.text.isNotEmpty && EmailValidator.validate(_email)&&
                        _passwordController.text.isNotEmpty &&
                        _emailController.text.isNotEmpty &&
                        await Connectivity().checkConnectivity() !=
                            ConnectivityResult.none) {
                      print("hello");
                      try {
                        final response = await http.post(
                            "http://linkous.herokuapp.com/api/register",
                            body: {
                              'name': _userName,
                              'email': _email,
                              'password': _password
                            });
                        print(jsonDecode(response.body));
                        if (jsonDecode(response.body)["status"] ==
                            "success") {
                          showDialog(
                              context: context,
                              builder: (context) => AlertDialog(
                                    title: Text(jsonDecode(
                                                response.body)["status"] ==
                                            "success"
                                        ? "User Registered Successfully"
                                        :jsonDecode(
                                        response.body)["status"] ==
                                        "success"&& jsonDecode(
                                        response.body)["message"] ==
                                        "email-exists"?"User is already registered with that EmailId!":"Something went wrong please try again"),
                                    actions: <Widget>[
                                      new FlatButton(
                                        onPressed: () =>
                                            Navigator.of(context).pop(false),
                                        child: new Text('Ok'),
                                      ),
                                      jsonDecode(response.body)["status"] ==
                                              "successful"
                                          ? new FlatButton(
                                              onPressed: () {
                                                Navigator.pop(context);
                                                Navigator.popUntil(
                                                    context,
                                                    ModalRoute.withName(
                                                        Routes.report));
                                                Navigator.pushNamed(
                                                    context, Routes.login);
                                              },
                                              child:
                                                  new Text('Continue to login'),
                                            )
                                          : Container(
                                              height: 0,
                                              width: 0,
                                            ),
                                    ],
                                  ));
                          print(jsonDecode(response.body));
                        }
                        else
                        {
                          showDialog(
                              context: context,
                              builder: (context) => AlertDialog(
                                title: Text(jsonDecode(
                                    response.body)["status"] ==
                                    "success"
                                    ? "User Registered Successfully"
                                    :jsonDecode(
                                    response.body)["status"] ==
                                    "fail"&& jsonDecode(
                                    response.body)["message"] ==
                                    "email-exists"?"User is already registered with that EmailId!":"Something went wrong please try again"),
                                actions: <Widget>[
                                  new FlatButton(
                                    onPressed: () =>
                                        Navigator.of(context).pop(false),
                                    child: new Text('Ok'),
                                  ),
                                  jsonDecode(response.body)["status"] ==
                                      "successful"
                                      ? new FlatButton(
                                    onPressed: () {
                                      Navigator.pop(context);
                                      Navigator.popUntil(
                                          context,
                                          ModalRoute.withName(
                                              Routes.report));
                                      Navigator.pushNamed(
                                          context, Routes.login);
                                    },
                                    child:
                                    new Text('Continue to login'),
                                  )
                                      : Container(
                                    height: 0,
                                    width: 0,
                                  ),
                                ],
                              ));
                          print(jsonDecode(response.body));
                        }
                      } on Exception catch (e) {
                        print(e);
                        showDialog(
                            context: context,
                            builder: (context) => AlertDialog(
                                  title: Text(
                                      "Unable to Connect to Server,Please try again!! "),
                                  actions: <Widget>[
                                    new FlatButton(
                                      onPressed: () =>
                                          Navigator.of(context).pop(false),
                                      child: new Text('OK'),
                                    ),
                                  ],
                                  titleTextStyle: myThemes.myDialogText,
                                  contentTextStyle: myThemes.myDialogText,
                                  shape: myThemes.myDialogShape,
                                ));
                      }
                    } else if(await Connectivity().checkConnectivity() ==
                        ConnectivityResult.none)
                      showDialog(
                          context: context,
                          builder: (context) => AlertDialog(
                                title: Text(
                                    "No Internet Connection,Please check your Internet Connection and try again!! "),
                                actions: <Widget>[
                                  new FlatButton(
                                    onPressed: () =>
                                        Navigator.of(context).pop(false),
                                    child: new Text('OK'),
                                  ),
                                ],
                                titleTextStyle: myThemes.myDialogText,
                                contentTextStyle: myThemes.myDialogText,
                                shape: myThemes.myDialogShape,
                              ));
                  },
                  shape: RoundedRectangleBorder(
                    borderRadius: new BorderRadius.circular(25),
                  ),
                  color: myThemes.primary,
                  child: Padding(
                    padding: EdgeInsets.only(
                        top: 15, bottom: 15, right: 25, left: 25),
                    child: Text(
                      "REGISTER",
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontFamily: 'Montserrat',
                          fontWeight: FontWeight.w800),
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: 70,
              )
            ],
          ),
        ),
      ),
    );
  }
}
