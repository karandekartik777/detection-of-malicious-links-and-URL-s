import 'dart:convert';

import 'package:connectivity/connectivity.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import 'package:linkous/home/myHome.dart';
import 'package:linkous/settings/myScrollBehaviour.dart';
import 'package:linkous/settings/myThemes.dart';
import 'package:linkous/report/userLoggedIn.dart';
import 'package:email_validator/email_validator.dart';

final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

// ignore: camel_case_types
class login extends StatefulWidget {
  String url;

  login(this.url);

  @override
  userLogin createState() {
    // TODO: implement createState
    return userLogin(url);
  }
}

// ignore: camel_case_types
class userLogin extends State<login> {
  String _userName;
  String _password;
  String url;

  userLogin(this.url); //print(Report);
  String _uMessage = "Please enter User Name";
  String _pMessage = "Please enter Password";
  final _userNameController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _validateUsername = false;
  bool _validatePassword = false;
  TextStyle _titleStyle =
      TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w600);
  bool _show = true;
  bool loggedIn = false;
  final storage = new FlutterSecureStorage();

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    //print(url);
    return Scaffold(
      key: _scaffoldKey,
      //resizeToAvoidBottomInset: false,
      //extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: Text("Login"),
        backgroundColor: myThemes.tertiary,
        elevation: 0,
      ),
      body: Container(
        //width: double.infinity,
        //height: double.infinity,
        padding: const EdgeInsets.only(left: 15, right: 15),
        decoration: myThemes.background,
        child: ScrollConfiguration(
          behavior: MyBehavior(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              SizedBox(
                height: 15,
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Padding(
                    padding: EdgeInsets.only(bottom: 5),
                    child: Text(
                      "Email",
                      style: _titleStyle,
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 15),
                    child: Container(
                      height: 55,
                      margin: EdgeInsets.all(0),
                      padding: EdgeInsets.all(0),
                      child: TextField(
                        onChanged: (username) {
                          this._userName = username;
                        },
                        style: TextStyle(color: Colors.white),
                        cursorColor: Colors.indigo,
                        decoration: InputDecoration(

                            //prefixIcon: Icon(Icons.remove_red_eye),
                            errorText: _validateUsername ? _uMessage : null,
                            filled: true,
                            fillColor: myThemes.textFieldColor,
                            border: new OutlineInputBorder(
                              borderSide: BorderSide(
                                width: 0,
                                style: BorderStyle.none,
                              ),
                              borderRadius: const BorderRadius.all(
                                const Radius.circular(9),
                              ),
                            )),
                        controller: _userNameController,
                        onSubmitted: (username) {
                          setState(() {
                            (username == null ||
                                    username.isEmpty ||
                                    username.startsWith(" ") ||
                                    !EmailValidator.validate(username))
                                ? _validateUsername = true
                                : _validateUsername = false;
                          });
                          _userName = username;
                        },
                      ),
                    ),
                  ),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Padding(
                    padding: EdgeInsets.only(bottom: 5),
                    child: Text(
                      "Password",
                      style: _titleStyle,
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 15),
                    child: Container(
                      height: 55,
                      margin: EdgeInsets.all(0),
                      padding: EdgeInsets.all(0),
                      child: TextFormField(
                        textAlignVertical: TextAlignVertical.center,
                        obscureText: _show,
                        onChanged: (password) {
                          this._password = password;
                        },
                        style: TextStyle(color: Colors.white),
                        cursorColor: Colors.indigo,
                        decoration: InputDecoration(
                            suffixIcon: GestureDetector(
                                onTap: () {
                                  setState(() {
                                    _show = !_show;
                                  });
                                },
                                child: _show
                                    ? Icon(
                                        Icons.visibility_off,
                                        color:
                                            Color.fromRGBO(255, 255, 255, 0.50),
                                      )
                                    : Icon(
                                        Icons.visibility,
                                        color:
                                            Color.fromRGBO(255, 255, 255, 0.50),
                                      )),
                            errorText: _validatePassword ? _pMessage : null,
                            filled: true,
                            fillColor: myThemes.textFieldColor,
                            border: new OutlineInputBorder(
                              borderSide: BorderSide(
                                width: 0,
                                style: BorderStyle.none,
                              ),
                              borderRadius: const BorderRadius.all(
                                const Radius.circular(9),
                              ),
                            )),
                        controller: _passwordController,
                        onFieldSubmitted: (password) {
                          this._password = password;
                        },
                      ),
                    ),
                  ),
                ],
              ),
              Container(
                width: 150,
                //padding: const EdgeInsets.only(left: 110, right: 110),
                child: RaisedButton(
                  onPressed: () async {
                    setState(() {
                      (_userNameController.text.isEmpty ||
                              _userNameController.text.startsWith(" ") ||
                              _userNameController.text == null ||
                              !EmailValidator.validate(_userName))
                          ? _validateUsername = true
                          : _validateUsername = false;
                      _passwordController.text.isEmpty ||
                              _passwordController.text == null
                          ? _validatePassword = true
                          : _validatePassword = false;
                    });
                    if (!_validateUsername &&
                        !_validatePassword &&
                        await Connectivity().checkConnectivity() !=
                            ConnectivityResult.none) {
                      var response;
                      showDialog(
                        context: context,
                        barrierDismissible: false,
                        builder: (BuildContext context) {
                          return Center(
                              child: Container(
                                  height: 50,
                                  width: 50,
                                  child: CircularProgressIndicator()));
                        },
                      );
                      try {
                        response = await http.post(
                            "http://linkous.herokuapp.com/api/sign-in",
                            body: {'email': _userName, 'password': _password});
                        if (jsonDecode(response.body)["state"] == "valid") {
                          myHome.cookie =
                              response.headers["set-cookie"].split(";")[0];
                          myHome.userRole =
                              jsonDecode(response.body)["role"].toString();
                          await storage.write(
                              key: "Cookie", value: myHome.cookie);
                        } else {
                          setState(() {
                            _userNameController.clear();
                            _passwordController.clear();
                            _pMessage = "Invalid Email or Password";
                            _validatePassword = true;
                          });
                        }
                      } on Exception catch (_) {
                        Navigator.pop(context);
                        _scaffoldKey.currentState.showSnackBar(SnackBar(
                          content: Text(
                            "Something went wrong, Please try again!",
                            style: TextStyle(color: Colors.white),
                          ),
                          backgroundColor: Colors.transparent,
                        ));
                        _userNameController.clear();
                        _passwordController.clear();
                      }
                      Navigator.pop(context);
                      if (jsonDecode(response.body)["state"] == 'valid') {
                        //Navigator.pop(context);
                        myHome.loggedIn = true;
                        myHome.username = _userName;
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    loggedInState(_userName, url)));
                      } else {
                        setState(() {
                          _userNameController.clear();
                          _passwordController.clear();
                          _pMessage = "Invalid Email or Password";
                          _validatePassword = true;
                        });
                      }
                    } else
                      showDialog(
                          context: context,
                          builder: (context) => AlertDialog(
                                title: Text(
                                    "No Internet Connection,Please check your Internet Connection and try again!! "),
                                actions: <Widget>[
                                  new FlatButton(
                                    onPressed: () =>
                                        Navigator.of(context).pop(false),
                                    child: new Text('OK'),
                                  ),
                                ],
                                titleTextStyle: myThemes.myDialogText,
                                contentTextStyle: myThemes.myDialogText,
                                shape: myThemes.myDialogShape,
                              ));
                  },
                  shape: RoundedRectangleBorder(
                    borderRadius: new BorderRadius.circular(25),
                  ),
                  color: myThemes.primary,
                  child: Padding(
                    padding: EdgeInsets.only(top: 15, bottom: 15),
                    child: Text(
                      "LOG IN",
                      style: TextStyle(
                          color: Colors.white,
                          fontFamily: 'Montserrat',
                          fontWeight: FontWeight.w800),
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: myHome.blockSizeVertical * 25,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
