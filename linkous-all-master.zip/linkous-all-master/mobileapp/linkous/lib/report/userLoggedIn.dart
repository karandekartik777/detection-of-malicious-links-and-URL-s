import 'dart:convert';

import 'package:connectivity/connectivity.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:linkous/home/myHome.dart';
import 'package:http/http.dart' as http;
import 'package:linkous/settings/myThemes.dart';
import 'package:linkous/settings/routes.dart';

class loggedInState extends StatefulWidget {
  String _userName = "";
  String _url = "";

  loggedInState(this._userName, this._url);

  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return userLoggedIn(_userName, _url);
  }
}

class userLoggedIn extends State<loggedInState> {
  String _userName = "";
  String _url = "";
  String _reportComment = "";
  bool error = false;
  TextEditingController _myURLController = TextEditingController();
  TextEditingController _myCommentController = TextEditingController();

//  errState Errorstate = errState();

  userLoggedIn(String userName, String url) {
    this._userName = userName;
    this._url = url==null?"":url;
    if (_url != null) _myURLController.text = _url;
  }

  TextStyle _buttonTextStyle =
      TextStyle(color: Colors.white, fontFamily: 'Montserrat',fontWeight: FontWeight.w800);
  TextStyle _style =
      TextStyle(fontSize: 25, fontFamily: 'Montserrat', color: Colors.white);
  RoundedRectangleBorder buttonShape = RoundedRectangleBorder(
    borderRadius: new BorderRadius.circular(25),
  );

  //_myController.text = _url;

  @override
  Widget build(BuildContext context) {
    //if(_url!=null)
    //print(_url);
    //print(_userName);
    // TODO: implement build
    return WillPopScope(
      onWillPop: () {
        Navigator.of(context).pushNamedAndRemoveUntil(
            Routes.home, (Route<dynamic> route) => false);
        return null;
      },
      child: Scaffold(
        //resizeToAvoidBottomInset: false,
        //extendBodyBehindAppBar: true,
        //drawer: AppDrawer(),
        backgroundColor: myThemes.tertiary,
        body: SafeArea(
          child: Container(
            //alignment: Alignment.topCenter,
            //height: myHome.height,
            //width: myHome.width,
            decoration: myThemes.background,
            padding: EdgeInsets.only(left: 15, right: 15),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: <Widget>[
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      "Welcome",
                      style: TextStyle(
                          fontSize: 15,
                          fontFamily: 'Montserrat',
                          color: Colors.grey),
                    ),
                    Text(
                     _userName,
                      style: _style,
                    ),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.only(bottom: 10, top: 10),
                      child: TextField(
                        style: _buttonTextStyle,
                        cursorColor: Colors.indigo,
                        onChanged: (url) {
                          _url = url;
                        },
                        decoration: InputDecoration(
                            errorText: error ? "Please enter a URL" : null,
                            hintText: "Report Link",
                            hintStyle: myThemes.textFieldHintColor,
                            filled: true,
                            fillColor: myThemes.textFieldColor,
                            border: new OutlineInputBorder(
                              borderSide: BorderSide(
                                width: 0,
                                style: BorderStyle.none,
                              ),
                              borderRadius: const BorderRadius.all(
                                const Radius.circular(9),
                              ),
                            )),
                        controller: _myURLController,
                        onSubmitted: (url) {
                          _url = url;
                        },
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: TextField(
                        onChanged: (_message){
                          setState(() {
                            _reportComment=_message;
                          });
                        },
                        onSubmitted: (_message){
                          setState(() {
                            _reportComment=_message;
                          });
                        },
                          controller: _myCommentController,
                        style: _buttonTextStyle,
                          maxLines: 3,
                          textAlign: TextAlign.left,
                          decoration: InputDecoration(
                              counterText: '',
                              filled: true,
                              fillColor: myThemes.textFieldColor,
                              hintText: "Mention Why It Is Not Safe Link",
                              border: new OutlineInputBorder(
                                borderSide: BorderSide(
                                  width: 0,
                                  style: BorderStyle.none,
                                ),
                                borderRadius: const BorderRadius.all(
                                  const Radius.circular(9),
                                ),
                              ),
                              hintStyle: myThemes.textFieldHintColor)),
                    ),
                    RaisedButton(
                        onPressed: () async {
                          if (_url != null &&
                              _url.isNotEmpty &&
                              !_url.startsWith(" ") &&
                              await Connectivity().checkConnectivity() !=
                                  ConnectivityResult.none) {
                            final response = await http.post(
                                "http://linkous.herokuapp.com/api/report",
                                body: {'url': _url,'brief':_reportComment},
                                headers: {'Cookie': myHome.cookie});
                            if (jsonDecode(response.body)["status"] !=
                                "success") {_myURLController.clear();_myCommentController.clear();}
                            showDialog(
                                context: context,
                                builder: (context) => AlertDialog(
                                      title: Text(jsonDecode(
                                                  response.body)["status"] ==
                                              "success"&&jsonDecode(response.body)["message"]=="report-created"
                                          ? "Link Successfully Reported"
                                          :jsonDecode(
                                          response.body)["status"] ==
                                          "fail"&&jsonDecode(response.body)["message"]=="report-exists"? "You Have Already Reported that Link!" :"Something went wrong please try again"),
                                      actions: <Widget>[
                                        new FlatButton(
                                          onPressed: () =>
                                              Navigator.of(context).pop(false),
                                          child: new Text('OK'),
                                        ),
                                      ],
                                      titleTextStyle: myThemes.myDialogText,
                                      contentTextStyle: myThemes.myDialogText,
                                      shape: myThemes.myDialogShape,
                                    ));
                          } else if (_url == null ||
                              _url.isEmpty ||
                              _url.startsWith(" ")) {
                            showDialog(
                                context: context,
                                builder: (context) => AlertDialog(
                                  title: Text(
                                      "You cannot report Empty URL,please type/paste an URl in the specified field and Try Again!! "),
                                  actions: <Widget>[
                                    new FlatButton(
                                      onPressed: () =>
                                          Navigator.of(context).pop(false),
                                      child: new Text('OK'),
                                    ),
                                  ],
                                  titleTextStyle: myThemes.myDialogText,
                                  contentTextStyle: myThemes.myDialogText,
                                  shape: myThemes.myDialogShape,
                                ));
                          } else
                            showDialog(
                                context: context,
                                builder: (context) => AlertDialog(
                                      title: Text(
                                          "No Internet Connection,Please check your Internet Connection and try again!! "),
                                      actions: <Widget>[
                                        new FlatButton(
                                          onPressed: () =>
                                              Navigator.of(context).pop(false),
                                          child: new Text('OK'),
                                        ),
                                      ],
                                      titleTextStyle: myThemes.myDialogText,
                                      contentTextStyle: myThemes.myDialogText,
                                      shape: myThemes.myDialogShape,
                                    ));
                        },
                        shape: buttonShape,
                        color: myThemes.primary,
                        child: Padding(
                          padding: const EdgeInsets.all(10),
                          child: Padding(
                            padding: const EdgeInsets.only(top: 3, bottom: 3),
                            child: Text(
                              "REPORT",
                              style: TextStyle(color: Colors.white),
                            ),
                          ),
                        )),
                    SizedBox(
                      height: 50,
                    )
                  ],
                ),
                IntrinsicWidth(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: <Widget>[
                      Container(
                        //alignment: Alignment.center,
                        child: RaisedButton(
                            onPressed: () async {
                              Navigator.pushNamedAndRemoveUntil(
                                  context,
                                  Routes.search,
                                  (Route<dynamic> route) => false);
                            },
                            shape: buttonShape,
                            color: myThemes.secondaryButtonColor,
                            child: Padding(
                              padding: const EdgeInsets.only(
                                  top: 10, bottom: 10, right: 15, left: 15),
                              child: Padding(
                                padding:
                                    const EdgeInsets.only(top: 3, bottom: 3),
                                child: Text(
                                  "SEARCH",
                                  style: TextStyle(color: myThemes.tertiary,fontFamily: 'Montserrat',fontWeight: FontWeight.w900),
                                ),
                              ),
                            )),
                      ),
                      SizedBox(
                        height: 10,
                        width: myHome.width,
                      ),
                      Container(
                        //alignment: Alignment.center,
                        child: RaisedButton(
                            elevation: 5,
                            onPressed: () async {
                              try {
                                final response = await http.get(
                                    "http://linkous.herokuapp.com/api/logout",
                                    headers: {'Cookie': myHome.cookie});
                                showDialog(
                                    context: context,
                                    builder: (context) => AlertDialog(
                                          title: Text(jsonDecode(response.body)[
                                                      "status"] ==
                                                  "invalid"
                                              ? "Logged Out Successfully"
                                              : "Something went wrong please try again"),
                                          actions: <Widget>[
                                            new FlatButton(
                                              onPressed: () {
                                                Navigator.of(context).pop(true);
                                              },
                                              child: new Text('OK'),
                                            ),
                                          ],
                                          titleTextStyle: myThemes.myDialogText,
                                          contentTextStyle:
                                              myThemes.myDialogText,
                                          shape: myThemes.myDialogShape,
                                        ));
                                if (jsonDecode(response.body)["status"] ==
                                    "invalid") {
                                  myHome.cookie = "";
                                  await FlutterSecureStorage()
                                      .write(key: "Cookie", value: "");
                                  myHome.loggedIn = false;
                                  myHome.userRole = "";
                                  Navigator.pushNamedAndRemoveUntil(
                                      context,
                                      Routes.home,
                                      (Route<dynamic> route) => false);
                                }
                              } on Exception {
                                myHome.cookie = "";
                                await FlutterSecureStorage()
                                    .write(key: "Cookie", value: "");
                                myHome.loggedIn = false;
                                myHome.userRole = "";
                                showDialog(
                                    context: context,
                                    builder: (context) => AlertDialog(
                                          title: Text(
                                              "Internet Connection Lost,Please Reconnect!!"),
                                          actions: <Widget>[
                                            new FlatButton(
                                              onPressed: () {
                                                Navigator.of(context).pop(true);
                                              },
                                              child: new Text('OK'),
                                            ),
                                          ],
                                          titleTextStyle: myThemes.myDialogText,
                                          contentTextStyle:
                                              myThemes.myDialogText,
                                          shape: myThemes.myDialogShape,
                                        ));
                              }
                            },
                            shape: buttonShape,
                            color: myThemes.secondary,
                            child: Padding(
                              padding: const EdgeInsets.all(10),
                              child: Padding(
                                padding:
                                    const EdgeInsets.only(top: 3, bottom: 3),
                                child: Text(
                                  "LOG OUT",
                                  style: TextStyle(color: Colors.white),
                                ),
                              ),
                            )),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 50,
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
