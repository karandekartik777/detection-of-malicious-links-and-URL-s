import 'package:flutter/material.dart';
import 'package:linkous/report/Report.dart';
import 'package:linkous/home/myHome.dart';
import 'package:linkous/report/userLoggedIn.dart';

class reportButton extends StatelessWidget {
  String _url;

  reportButton(this._url);

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return RaisedButton(
      shape: RoundedRectangleBorder(
        borderRadius: new BorderRadius.circular(9),
      ),
      onPressed: () {
        myHome.loggedIn?Navigator.push(context,MaterialPageRoute(builder: (context) => loggedInState(myHome.username,_url))):Navigator.push(context,MaterialPageRoute(builder: (context) => Report(_url)));
      },
      child: const Text('Report URL?', style: TextStyle(fontSize: 20)),
      color: Colors.transparent,
      textColor: Colors.white,
      elevation: 0,
    );
  }
}
