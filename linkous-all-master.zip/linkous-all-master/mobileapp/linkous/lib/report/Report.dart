import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:linkous/home/myHome.dart';
import 'package:linkous/settings/myThemes.dart';
import 'package:linkous/settings/routes.dart';
import 'package:linkous/login_register/userLogin.dart';

class Report extends StatelessWidget {
  String url;

  Report(this.url);

  final EdgeInsets _lbuttonTextPadding = EdgeInsets.only(
      left: myHome.blockSize * 35,
      right: myHome.blockSize * 35,
      top: 15,
      bottom: 15);
  final EdgeInsets _rbuttonTextPadding = //padding for register button
      EdgeInsets.only(
          left: myHome.blockSize * 31.5,
          right: myHome.blockSize * 31.5,
          top: 15,
          bottom: 15);
  final RoundedRectangleBorder _buttonShape = RoundedRectangleBorder(
    borderRadius: new BorderRadius.circular(25),
  );

  @override
  Widget build(BuildContext context) {
    print(url);
    // TODO: implement build
    return Scaffold(
        backgroundColor: Colors.transparent,
        extendBodyBehindAppBar: true,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          title: Text('Panel'),
          elevation: 0,
        ),
        //drawer: AppDrawer(),
        body: Container(
          alignment: Alignment.center,
          decoration: myThemes.background,
          child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.only(bottom: 15),
                  child: RaisedButton(
                    onPressed: () {
                      Navigator.push(context,MaterialPageRoute(builder: (context) => login(url)));
                    },
                    shape: _buttonShape,
                    color: myThemes.primary,
                    child: Padding(
                      padding: _lbuttonTextPadding,
                      child: Text(
                        "LOGIN",
                        style: TextStyle(color: Colors.white,fontFamily: 'Montserrat',fontWeight: FontWeight.w900),
                      ),
                    ),
                  ),
                ),
                RaisedButton(
                    onPressed: () {
                      Navigator.of(context).pushNamed(Routes.register);
                    },
                    color: myThemes.secondaryButtonColor,
                    shape: _buttonShape,
                    child: Padding(
                      padding: _rbuttonTextPadding,
                      child:
                          Text("REGISTER", style: TextStyle(color: myThemes.tertiary,fontFamily: 'Montserrat',fontWeight: FontWeight.w900)),
                    )),
              ],
            ),
        ));
  }
}
