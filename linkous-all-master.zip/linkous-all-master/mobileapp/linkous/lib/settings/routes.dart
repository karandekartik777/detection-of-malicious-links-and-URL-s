class Routes {
  static const String home = '/';
  static const String search = '/search';
  static const String report = '/report';
  static const String login = '/login';
  static const String register = '/register';
  static const String aboutUs = '/aboutUs';
}