import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:linkous/report/Report.dart';
import 'package:linkous/home/myHome.dart';
import 'package:linkous/settings/routes.dart';
import 'package:linkous/settings/myThemes.dart';
import 'package:linkous/search/searchResult.dart';
import 'package:linkous/report/userLoggedIn.dart';
import 'package:http/http.dart' as http;

class AppDrawer extends StatelessWidget {
  bool search = true;
  bool aboutUS = true;

  AppDrawer(this.search, this.aboutUS);

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Drawer(
      child: Container(
        decoration: BoxDecoration(color: myThemes.tertiary),
        child: ListView(
          children: <Widget>[
            Container(
              decoration: BoxDecoration(color: Color.fromRGBO(42, 40, 75, 1.0)),
              child: ListTile(
                  title: Text(
                'Menu',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
              )),
            ),
            //Divider(),
            ListTile(
                title: Text('Home'),
                onTap: () {
                  //Navigator.pop(context);
                  Navigator.pushNamedAndRemoveUntil(
                      context, Routes.home, (Route<dynamic> route) => false);
                  //Navigator.pop(context);
                }),
            !aboutUS
                ? ListTile(
                    title: Text('Why Linkous?'),
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.pushNamed(context, Routes.aboutUs);
                      //Navigator.pop(context);
                    },
                  )
                : ListTile(
                    title: Text('Search'),
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.pushNamed(context, Routes.search);
                      //Navigator.pop(context);
                    },
                  ),
            search
                ? ListTile(
                    title: Text('Report a Link'),
                    onTap: () {
                      Navigator.pop(context);
                      myHome.loggedIn
                          ? Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => loggedInState(
                                      myHome.username, searchResult.urls)))
                          : Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                      Report(searchResult.urls)));
                      //Navigator.pop(context);
                    },
                  )
                : ListTile(
                    title: Text('Search'),
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.pushNamed(context, Routes.search);
                      // Navigator.pop(context);
                    }),
            myHome.loggedIn
                ? ListTile(
                    title: Text('Log Out'),
                    onTap: () async {
                      try {
                        final response = await http.get(
                            "http://linkous.herokuapp.com/api/logout",
                            headers: {'Cookie': myHome.cookie});
                        showDialog(
                            context: context,
                            builder: (context) => AlertDialog(
                                  title: Text(jsonDecode(
                                              response.body)["status"] ==
                                          "invalid"
                                      ? "Logged Out Successfully"
                                      : "Something went wrong please try again"),
                                  actions: <Widget>[
                                    new FlatButton(
                                      onPressed: () {
                                        Navigator.of(context).pop(true);
                                      },
                                      child: new Text('OK'),
                                    ),
                                  ],
                                  titleTextStyle: myThemes.myDialogText,
                                  contentTextStyle: myThemes.myDialogText,
                                  shape: myThemes.myDialogShape,
                                ));
                        if (jsonDecode(response.body)["status"] == "invalid") {
                          myHome.cookie = "";
                          await FlutterSecureStorage()
                              .write(key: "Cookie", value: "");
                          myHome.loggedIn = false;
                          myHome.userRole = "";
                          Navigator.pushNamedAndRemoveUntil(context,
                              Routes.home, (Route<dynamic> route) => false);
                        }
                      } on Exception {
                        myHome.cookie = "";
                        await FlutterSecureStorage()
                            .write(key: "Cookie", value: "");
                        myHome.loggedIn = false;
                        myHome.userRole = "";
                        showDialog(
                            context: context,
                            builder: (context) => AlertDialog(
                                  title: Text(
                                      "Internet Connection Lost,Please Reconnect!!"),
                                  actions: <Widget>[
                                    new FlatButton(
                                      onPressed: () {
                                        Navigator.of(context).pop(true);
                                      },
                                      child: new Text('OK'),
                                    ),
                                  ],
                                  titleTextStyle: myThemes.myDialogText,
                                  contentTextStyle: myThemes.myDialogText,
                                  shape: myThemes.myDialogShape,
                                ));
                      }
                    },
                  )
                : Container(
                    height: 0,
                    width: 0,
                  ),
          ],
        ),
      ),
    );
  }
}
