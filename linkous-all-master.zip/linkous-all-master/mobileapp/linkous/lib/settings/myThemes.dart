import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

// ignore: camel_case_types
class myThemes {
  static RoundedRectangleBorder buttonShape = RoundedRectangleBorder(
    borderRadius: new BorderRadius.circular(25),
  );//shape of buttons
  static TextStyle myDialogText = TextStyle(fontFamily: 'Montserrat',fontSize: 18);//style of text shown in error/alert dialogs
  static RoundedRectangleBorder myDialogShape= RoundedRectangleBorder(
      borderRadius: new BorderRadius.circular(10));//shape of alert/error dialogs
  static Color textFieldColor = Color.fromRGBO(0, 0, 0, 0.4);//text field background
  static TextStyle textFieldHintColor=TextStyle(color: Color.fromRGBO(255, 255, 255, 0.4));//color for text(hint) in text field
  static Color primary = Color.fromRGBO(80, 120, 252, 1); //colour for emphasised object on screen
  static Color secondary = Color.fromRGBO(34, 34, 34, 1); //background color 1
  static Color tertiary = Color.fromRGBO(24, 24, 24, 1); //background color 2
  static Color secondaryButtonColor = Color.fromRGBO(255, 255, 255, 0.9); //background color 2

  static BoxDecoration background = BoxDecoration(
    gradient: LinearGradient(
        begin: Alignment.bottomCenter,
        end: Alignment.topCenter,
        colors: [
          secondary,
          tertiary,
        ]), //background gradient using bg color1 & bg color2
  );
}