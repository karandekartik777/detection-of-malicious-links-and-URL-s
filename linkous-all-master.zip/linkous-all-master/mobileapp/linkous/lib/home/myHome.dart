import 'package:connectivity/connectivity.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:linkous/main.dart';
import 'package:linkous/search/searchResult.dart';
import 'package:linkous/search/searchURLHome.dart';
import 'package:linkous/settings/routes.dart';
import 'package:linkous/settings/myThemes.dart';
import 'package:linkous/search/searchHome.dart';
import 'package:linkous/report/userLoggedIn.dart';

class Home extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return myHome();
  }
}

class myHome extends State<Home> {

  final GlobalKey<NavigatorState> navigatorKey =
  new GlobalKey<NavigatorState>();
  static BuildContext myContext;
  static var connectivityResult;
  static double width;
  static bool loggedIn = false;
  static double height;
  static double blockSize;
  static double blockSizeVertical;
  static String username="";
  static String cookie="";
  static bool errorOpeningLink = false;
//  static bool openedWithLink = false;
  static String initialLink;
  static String userRole="";
  static ValueNotifier<bool> opl= new ValueNotifier(false) ;


  @override
  Widget build(BuildContext context) {
    myHome.opl.addListener(() {
      if(myHome.opl.value)
      Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => searchResultState(context, myHome.initialLink, false)));
    });
//      push(context, MaterialPageRoute(
//          builder: (context) => searchHome()),
//      );
    setState(() {
      width = MediaQuery
          .of(context)
          .size
          .width;
      height = MediaQuery
          .of(context)
          .size
          .height;
      blockSize = width / 100;
      blockSizeVertical = height / 100;
    });
    TextStyle titles = TextStyle(
      fontFamily: 'Montserrat',
      color: Colors.white,
      fontSize: 40,
      fontWeight: FontWeight.bold,
      decoration: TextDecoration.none,
    );
    if(opl.value)
    {
    return searchResultState(context,initialLink,false);
    }
//    if (openedWithLink && errorOpeningLink)
//  {
//    print("\n\n\nError\n\n\n");
//    showDialog(
//          context: context,
//          builder: (context) => AlertDialog(
//            title: Text(
//                "No Internet Connection,Please check your Internet Connection and try again!! "),
//            actions: <Widget>[
//              new FlatButton(
//                onPressed: () =>
//                    Navigator.of(context).pop(false),
//                child: new Text('OK'),
//              ),
//            ],
//            titleTextStyle: myThemes.myDialogText,
//            contentTextStyle: myThemes.myDialogText,
//            shape: myThemes.myDialogShape,
//          ));}
//    else if(openedWithLink)
//      Navigator.push(context, MaterialPageRoute(
//          builder: (context) => searchHome()),
//      );
    RoundedRectangleBorder buttonShape = RoundedRectangleBorder(
      borderRadius: new BorderRadius.circular(25),
    );
    // TODO: implement build;
    SystemChrome.setEnabledSystemUIOverlays([SystemUiOverlay.top]);
//    SystemChrome.restoreSystemUIOverlays();
    return Scaffold(
      backgroundColor: myThemes.tertiary,
//      context: context,
//      removeRight: false,
//      removeTop: true,
//      removeLeft: false,
//      removeBottom: false,
      body: Container(
        decoration: myThemes.background,
        width: double.infinity,
        height: double.infinity,
        padding: const EdgeInsets.only(left: 15, right: 15, top: 25),
        child: SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Row(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.start,
                //crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Image.asset(
                    "images/Icon.png",
                    height: blockSizeVertical * 7,
                    width: blockSize * 10,
                  ),
                  //widthFactor: 2,
                  //alignment: Alignment.topCenter,
                  Padding(
                    padding: const EdgeInsets.only(left: 5),
                    child: Image.asset(
                      "images/LinkousText.png",
                      height: blockSizeVertical * 7,
                      width: blockSize * 30,
                    ),
                  ),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  SizedBox(
                      //height: blockSizeVertical*20,
                      ),
                  Text(
                    "Online Security.",
                    style: titles,
                  ),
                  Text(
                    "Redefined.",
                    style: titles,
                  ),
                ],
              ),
              IntrinsicWidth(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  mainAxisSize: MainAxisSize.max,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Container(
                      width:width,
                      padding: EdgeInsets.only(bottom: 20),
                      child: Text(
                        "Continue With",
                        style: TextStyle(
                            decoration: TextDecoration.none,
                            color: Colors.white,
                            fontSize: 17,
                            fontWeight: FontWeight.w400,
                            fontFamily: 'Montserrat'),
                      ),
                    ),
                    Padding(
                      //width: width,
                      //height: 60,
                      padding: EdgeInsets.only(top: 5, bottom: 10),
                      child: RaisedButton(
                        onPressed: () async {
                          //Navigator.of(context).pushNamed(Routes.search);
                          if (await Connectivity().checkConnectivity() !=
                              ConnectivityResult.none)
                            Navigator.of(context).push(MaterialPageRoute(
                                builder: (context) => searchHome()));
                          else
                            showDialog(
                                context: context,
                                builder: (context) => AlertDialog(
                                      title: Text(
                                          "No Internet Connection,Please check your Internet Connection and try again!! "),
                                      actions: <Widget>[
                                        new FlatButton(
                                          onPressed: () =>
                                              Navigator.of(context).pop(false),
                                          child: new Text('OK'),
                                        ),
                                      ],
                                      titleTextStyle: myThemes.myDialogText,
                                      contentTextStyle: myThemes.myDialogText,
                                      shape: myThemes.myDialogShape,
                                    ));
                        },
                        shape: buttonShape,
                        color: myThemes.primary,
                        child: Padding(
                          padding: const EdgeInsets.only(top: 15,bottom: 15),
                          child: Text(
                            "SEARCH",
                            style: TextStyle(
                                color: Colors.white,
                                fontFamily: 'Montserrat',
                                fontWeight: FontWeight.w900),
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 5),
                      child: RaisedButton(
                        onPressed: () async {
                          if (await Connectivity().checkConnectivity() !=
                              ConnectivityResult.none)
                            loggedIn
                                ? Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) =>
                                            userLoggedIn(username, "")
                                                .build(context)))
                                : Navigator.of(context)
                                    .pushNamed(Routes.report);
                          else
                            showDialog(
                                context: context,
                                builder: (context) => AlertDialog(
                                  title: Text(
                                      "No Internet Connection,Please check your Internet Connection and try again!! "),
                                  actions: <Widget>[
                                    new FlatButton(
                                      onPressed: () =>
                                          Navigator.of(context).pop(false),
                                      child: new Text('OK'),
                                    ),
                                  ],
                                  titleTextStyle: myThemes.myDialogText,
                                  contentTextStyle: myThemes.myDialogText,
                                  shape: myThemes.myDialogShape,
                                ));
                        },
                        shape: buttonShape,
                        color: myThemes.secondaryButtonColor,
                        child: Padding(
                          padding: const EdgeInsets.only(top: 15,bottom: 15),
                          child: Text(
                            "REPORT",
                            style: TextStyle(
                                color: myThemes.tertiary,
                                fontFamily: 'Montserrat',
                                fontWeight: FontWeight.w900),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 140,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
