# MiddleOutTech (RK305)

<br><br>

<p align="center"><img src="./docs/img/linkous.png" height="50"></p>

<br><br>

Linkous is an advanced malicious link detection tool which leverage multiple ML classifiers and one which just not use a database!


You can access Linkous at [https://linkous.herokuapp.com](https://linkous.herokuapp.com)

<br>

Here are some user accounts to get the most out of Linkous!

| User Role     | Email                      | Password  |
| ------------- |:--------------------------:|:---------:|
| User          | jayadeep@xyz.com           | root      |
| Org           | police@xyz.com             | root      |
| Admin         | vaibhavkshinde20@gmail.com | root      |

<br>

## Technology Stack


### Backend


<p align="center">
  Heroku (Cloud Hosting)
  <br>
  <img src="./docs/img/stack/heroku.png" height="60">
</p>

<p align="center">
  Flask (Server Framework)
  <br><br>
  <img src="./docs/img/stack/flask.png" height="60">
</p>

<p align="center">
  MongoDB (NoSQL Database)
  <br><br>
  <img src="./docs/img/stack/mongodb.svg" height="60">
</p>

<p align="center">
  MLab (Cloud - Database as a Service)
  <br><br>
  <img src="./docs/img/stack/mlab.png" height="60">
</p>


### Frontend 

<p align="center">
  Vue.js
  <br><br>
  <img src="./docs/img/stack/vuejs.png" height="60">
</p>
  
<p align="center">
  Chart.js
  <br><br>
  <img src="./docs/img/stack/chartjs.svg" height="60">
</p>


### Mobile App

<p align="center">
  Flutter
  <br><br>
  <img src="./docs/img/stack/flutter.png" height="60">
</p>

### Browser Extensions (Works on all major browsers)

<p align="center">
<img src="./docs/img/stack/chrome.png" height="60">
</p>

<br>

Here is an example of a report from Linkous which is visible when logged in as an admin.

<p align="center">
<img src="./docs/img/webapp/org-report.png" height="768">
</p>

### Website Info

Shows organizations useful data of the website

<p align="center">
<img src="./docs/img/webapp/website-info.png" height="768">
</p>

Linkous has the following tiers of protection:

1. Database
2. PageRank `(Returns a rank between 0 to 10, we've set a threshold of less than 2 for unsafe websites)`
3. Lexical + Host Based Analysis
4. Spam Analysis
5. Content Analysis

### Special Features

- Our own database which has three roles: User, Organization, Admin)
- Can detect short urls like bit.ly, goo.gl etc
- Efficient ML analysis of 4 classifiers
- Checks for spam content so you don't loose money or any sensitive info

### Search Pipeline

<p align="center">
<img src="./docs/img/webapp/pipeline.png" height="260">
</p>

#### Explanation of the Pipeline

- First, when a user searches for a URL, Linkous will first hit the three APIs:
  - Database
  - Pagerank
  - Content Analyzer
  
  If the database has a report with the URL, Linkous will stop right there and display the database report.
  
  If pagerank shows the page is safe, then the url would mostly be safe since top website are the ones with a pagerank higher than 5.

  If pagerank returns unsafe, i.e; low page rank, then, we'll run the next two classifiers:

  - Lexical + Host based Analysis
  - Spam Analysis

  Content analysis scrapes the website and runs all the four functions above to determine if the links are unsafe.


## Screenshots

- [All Screenshots](./docs/screenshots.md)
