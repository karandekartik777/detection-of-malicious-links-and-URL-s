# Before you push to master...

1. Change getURL() in main.js
2. Change connect() in db.__init__
3. Disable CORS in linkous.__init__