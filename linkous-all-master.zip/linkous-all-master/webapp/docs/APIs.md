# API Documentation

## User APIs

### Register

```http
POST /api/register
name=name&email=email&password=password
```

### Sign In

```http
POST /api/sign-in
email=email&password=password
```

### Log Out

```http
GET /api/logout
```

### Test Sign-In

```http
GET /api/test-auth
```


## Data fetch APIs

All you need to do is pass the following form data to one of the following APIs
```
url=yoururl.com
```

### Search API

```http
POST /api/search
```

### Page Rank API

We have integrated Open PageRank API here.

```http
POST /api/pagerank
```

### Lexical Scan API

```http
POST /api/lex-scan
```

### Content Scan API

```http
POST /api/content-scan
```