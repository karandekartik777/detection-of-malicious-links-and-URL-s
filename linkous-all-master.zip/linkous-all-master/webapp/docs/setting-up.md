# Dev Env SetUp

## Install MongoDB locally

```bash
sudo apt install -y mongodb
# check status
sudo systemctl status mongodb
# to start it
sudo systemctl start mongodb
# to disable automatic startup on boot
sudo systemctl disable mongodb
```

### Create an admin user

Source: https://www.digitalocean.com/community/tutorials/how-to-install-and-secure-mongodb-on-ubuntu-16-04#part-two-securing-mongodb

```bash
# open mongodb shell
mongo
# in mongo shell
use admin
db.createUser({
  user: 'username',
  pwd: 'password',
  roles: [{role: 'userAdminAnyDatabase', db: 'admin'}]
})
```