from flask import Flask, session
import os

# from .core.db import populate
# populate()

PRODUCTION = True if ('NODE_ENV' in os.environ and os.environ['NODE_ENV'] == 'production') else False

def linkous():
  app = Flask(__name__, template_folder="templates")
  app.secret_key = os.environ["SECRET_KEY"]

  if not PRODUCTION:
    print('[ i ] Flask mode: dev')
    from flask_cors import CORS
    CORS(app)
    CORS(app, supports_credentials=True)

  with app.app_context():
      from . import routes
      from . import routes_api
      return app


