from flask import current_app as app
from flask import render_template
from flask import request, jsonify, session

from .core.xpagerank import getPageRank, pagerankClassifier, getDomain
from .core.xspam import spamScan
from .core.xcontent import contentClassifier
from .core.xlex import predictLex

from .core.stub import getStub

from .core.db import registerUser, reportLink, search

from .core.web import websiteInfo

import json

@app.route('/api/search', methods=["POST"])
def searchDB():
    try:
        if request.method == "POST":
            url = request.form['url']
            return json.dumps(search(url))
        else:
            return render_template('status/400.html'), 400
    except Exception as e:
        print(e)
        return render_template('status/error.html', error=e), 500

@app.route('/api/website_info', methods=["POST"])
def websiteInfoRoute():
    try:
        role = 'user'
        if 'user' in session:
            role = session['user']['role']
        if request.method == "POST":
            url = request.form['url']
            return websiteInfo(url, role)
        else:
            return render_template('status/400.html'), 400
    except Exception as e:
        print(e)
        return render_template('status/error.html', error=e), 500

@app.route('/api/pagerank', methods=["POST"])
def pagerank():
    try:
        if request.method == "POST":

            url = request.form['url']
            try:
                url = getDomain(url)

                rank = getPageRank(url)
                rank = json.loads(rank)
                rank = rank['response'][0]

                return json.dumps(pagerankClassifier(rank))

            except Exception as e:
                    print(e)
                    return render_template('status/error.html', error=e), 500
        else:
            return render_template('status/400.html'), 400
    except Exception as e:
        print(e)
        return render_template('status/error.html', error=e), 500

@app.route('/api/content-scan', methods=["POST"])
def contentScan():
    try:
        if request.method == "POST":
            url = request.form['url']
            # return getStub(url)
            return json.dumps(contentClassifier(url))
        else:
            return render_template('status/400.html'), 400
    except Exception as e:
        print(e)
        return render_template('status/error.html', error=e), 500

@app.route('/api/spam-scan', methods=["POST"])
def spamScanner():
    try:
        if request.method == "POST":
            url = request.form['url']
            return spamScan(url)
        else:
            return render_template('status/400.html'), 400
    except Exception as e:
        print(e)
        return render_template('status/error.html', error=e), 500


@app.route('/api/lex-scan', methods=["POST"])
def lexicalScan():
    try:
        if request.method == "POST":
            url = request.form['url']
            
            return json.dumps({
                'result': predictLex(url)
            })
        else:
            return render_template('status/400.html'), 400
    except Exception as e:
        print(e)
        return render_template('status/error.html', error=e), 500

