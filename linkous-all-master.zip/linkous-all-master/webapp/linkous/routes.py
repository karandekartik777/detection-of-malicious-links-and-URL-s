from flask import current_app as app
from flask import render_template
from flask import session, url_for, request, redirect, render_template
from markupsafe import escape
import json

from .core.auth import signIn
from .core.db import reportLink, registerUser
from .core.db import fetchReports, approveReport, rejectReport, getAllReports

from functools import wraps



# print("Creating an admin user:")
# print("\tRole: Admin")
# print("\tEmail: vaibhavkshinde20@gmail.com")

# print(registerUser({
#     'name': 'Vaibhav',
#     'email': 'vaibhavkshinde20@gmail.com',
#     'password': 'root',
#     'role': 'admin'
# }))

# print("Creating an admin user:")
# print("\tRole: Admin")
# print("\tEmail: linkous-bot")

# print(registerUser({
#     'name': 'Linkous Bot',
#     'email': 'linkous-bot',
#     'password': 'root',
#     'role': 'admin'
# }))



def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not 'user' in session:
            return json.dumps({
                "status": "fail",
                "message": "sign-in to report"
            })
        return f(*args, **kwargs)
    return decorated_function

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/test-auth')
def test():
    if 'user' in session:
        return 'Logged in as {} with role {}'.format(session['user']['email'], session['user']['role'])
    return 'You are not logged in'

@app.route('/api/sign-in', methods = ['POST'])
def signInAPI():
    if request.method == 'POST':
        
        email = request.form['email']
        password = request.form['password']

        res = signIn(email, password)

        if not res:
            return json.dumps({
                "state": "invalid"
            })
        res['state'] = 'valid'
        return json.dumps(res)

    else:
        return render_template('status/400.html'), 400

@app.route('/api/logout', methods=['GET', 'POST'])
def logout():
    session.pop('user', None)
    return json.dumps({'status': 'invalid'})

@app.route('/api/report', methods = ['POST'])
@login_required
def reportAPI():
    if request.method == 'POST':

        link = {
            "url": request.form['url'],
            "brief": request.form['brief']
        }
        
        return json.dumps(reportLink(link))

    else:
        return render_template('status/400.html'), 400

@app.route('/api/register', methods = ['POST'])
def registerAPI():
    if request.method == 'POST':

        user = {
            "name": request.form['name'],
            "email": request.form['email'],
            "password": request.form['password']
        }
        
        return json.dumps(registerUser(user))

    else:
        return render_template('status/400.html'), 400

@app.route('/api/user-auth', methods = ['GET'])
def userAuth():
    if 'user' in session:
        res = session['user']
        res['state'] = 'valid'
        return json.dumps(res)
    else:
        return json.dumps({
            'state': 'invalid'
        })

@app.route('/api/fetch_reports', methods = ['GET'])
def getReports():
    if 'user' in session and session['user']['role'] == 'admin':
        return json.dumps(fetchReports())
    else:
        return json.dumps({
            'status': 'invalid user'
        })

@app.route('/api/report/approve', methods=['POST'])
def reportApprover():
    # return json.dumps({
    #     'status': 'approved'
    # })
    if 'user' in session and session['user']['role'] == 'admin':
        url = request.form['url']
        email = request.form['email']
        return json.dumps(approveReport(url, email))
    return json.dumps({
        'status': '403'
    })

@app.route('/api/report/reject', methods=['POST'])
def reportRejector():
    # return json.dumps({
    #     'status': 'rejected'
    # })
    if 'user' in session and session['user']['role'] == 'admin':
        url = request.form['url']
        email = request.form['email']
        return json.dumps(rejectReport(url, email))
    return json.dumps({
        'status': '403'
    })

@app.route('/api/create_user', methods=['POST'])
def userCreator():
    # return json.dumps({
    #     'status': 'rejected'
    # })
    if 'user' in session and session['user']['role'] == 'admin':
        name = request.form['name']
        password = request.form['password']
        email = request.form['email']
        role = request.form['role']
        return json.dumps(registerUser({
            'name': name,
            'password': password,
            'email': email,
            'role': role
        }))
    return json.dumps({
        'status': '403'
    })

@app.route('/api/reports.json', methods=['GET'])
def reportsJSON():
    if 'user' in session and session['user']['role'] == 'org':
        return json.dumps(getAllReports())
    return json.dumps({
        'status': '403'
    })

