import requests, json
from urllib.parse import urlparse
import os

from ..functions import validURL

PAGERANK_URL = 'https://openpagerank.com/api/v1.0/getPageRank'
PAGERANK_KEY = os.environ["PAGERANK_KEY"]
SAFE_RANK = 2

def getPageRank(url):
    """
    Sample response: 
    {
        "status_code": 200,
        "response": [{
            "status_code": 200,
            "error": "",
            "page_rank_integer": 4,
            "page_rank_decimal": 4.13,
            "rank": "1274206",
            "domain": "files.com"
        }],
        "last_updated": "29th Nov 2019"
    }
    """
    params = {
        'domains[]': url
    }
    headers = {
        'Content-Type': 'application/json',
        'Accept-Charset': 'UTF-8',
        'API-OPR': PAGERANK_KEY,
    }
    res = requests.get(PAGERANK_URL, params=params, headers=headers)
    return res.text

def pagerankClassifier(res):
    newRes = {
        'domain': res['domain']
    }
    if not res['page_rank_integer']:
        res['page_rank_integer'] = 0
    newRes['result'] = 'safe' if (int(res['page_rank_integer']) > SAFE_RANK) else 'risky'
    newRes['rank'] = res['page_rank_decimal']
        
    return newRes

def getDomain(url):
    if url.startswith('http://') or url.startswith('https://'):
        newURL = urlparse(url)
    else:
        newURL = urlparse('http://' + url)
    return newURL.netloc