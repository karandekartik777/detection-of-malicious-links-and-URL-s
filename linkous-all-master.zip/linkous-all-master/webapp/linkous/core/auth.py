from flask import session

from .functions import hasher
from .db.models import User

def signIn(email: str, password: str) -> bool:

    user = User.objects(email = email)

    if user.count() == 0:
        return False
    
    user = user[0]

    if hasher(password) == user['password']:
        # sign in success
        session['user'] = {
            "email": user['email'],
            "role": user['role']
        }
        return session['user']
    else:
        # sign in fail
        return False

def getUser():

    if not 'user' in session:
        return False
    
    user = User.objects.get(email=session['user']['email'])
    return user