# Random Forest Classification

# Importing the libraries
import numpy as np
import pandas as pd
from .vectorizer import vectorizer

from ..functions import validURL

from func_timeout import func_timeout

path = 'linkous/core/xlex/'

# Importing the dataset
dataset = pd.read_csv(path + 'Final_Training_Data.csv')
independent_vars = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26]
X = dataset.iloc[:, independent_vars].values
y = dataset.iloc[:,27 ].values

# Splitting the dataset into the Training set and Test set
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.25, random_state = 0, )

# Feature Scaling
from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
X_train = sc.fit_transform(X_train)
X_test = sc.transform(X_test)

# Fitting Random Forest Classification to the Training set
from sklearn.ensemble import RandomForestClassifier
classifier = RandomForestClassifier(n_estimators = 10, criterion = 'entropy', random_state = 0, class_weight='balanced')
classifier.fit(X_train, y_train)

# Predicting the Test set results
y_pred = classifier.predict(X_test)


# Confusion Matrix for calculating accuracy
from sklearn.metrics import confusion_matrix
cm = confusion_matrix(y_test, y_pred)
accuracy= (cm[0][0]+cm[1][1])/cm.sum()*100

print("[ + ] Loaded Lexical Analyzer with accuracy {}%!".format(accuracy))

def predictLex(url):
  url = validURL(url)
  try:
    vec = func_timeout(5, vectorizer, args=tuple([url]), kwargs=None)
    vec = np.array(vec)
    vec=vec.reshape(1,-1)
    predicted= classifier.predict(vec)
    probability = classifier.predict_proba(vec)[0]
    unsafe_prob = probability[1]
    if predicted:
      # unsafe
      return {
        'result': 'unsafe',
        'probability': unsafe_prob
      }
    else:
      # safe
      return {
        'result': 'safe',
        'probability': unsafe_prob
      }
  except:
    return {
        'result': 'risky',
        'probability': 0.6
      }