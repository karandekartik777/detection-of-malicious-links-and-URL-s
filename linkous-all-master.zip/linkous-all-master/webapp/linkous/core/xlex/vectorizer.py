"""
This Module is the actual Code to extract Relevant Information from a URL on features like length,domain tokens,path tokens etc.
It receives a URL and them Processing is done on it.
"""
import re
import whois
import datetime


def has_ip(lis):
	for i in lis:
		if i.isdigit() == False:
			return 0
	else:
		return 1


def no_of_hyphens_in_domain(link):
	hyphen = '-'
	count = 0
	for i in link:
		if i == hyphen:
			count += 1
	return count


def dots_in_total(link):
	dot = '.'
	count = 0
	for i in link:
		if i == dot:
			count += 1
	return count


def delimiters_total(str):
	delim = ['-', '_', '?', '=', '&']
	count = 0
	for i in str:
		for j in delim:
			if i == j:
				count += 1
	return count

Words=['secure','account','update','banking','login','click','confirm','password','verify','signin','ebayisapi','lucky','bonus']

TLDs=['zip','cricket','link','work','party','gq','kim','country','science','tk']

def vectorizer(str):
	vec=[]	

	###1
	rem_protocol=re.sub(r'^http(s*)://','',str)	
	vec.append(len(rem_protocol))	 					
	vec.append(dots_in_total(rem_protocol)) 	  			
	for i in Words:
		if re.search(i,rem_protocol,re.IGNORECASE):
			vec.append(1)								
			break
	else:
		vec.append(0)									

	###2
	patt=r'^[^/]*'										
	patt_path=r'/[^/]*'									
	dom=re.match(patt,rem_protocol).group(0)
	info=re.findall(patt_path,rem_protocol)
	
	dom_hyph_count=no_of_hyphens_in_domain(dom)
	vec.append(int(dom_hyph_count))					
	token_dom=(dom).split('.')
	token_dom=[x for x in token_dom if x!='']	
	
	tokens_path=[re.sub('/','',x) for x in info]
	if tokens_path!=[]:
		file_n_args=tokens_path[-1]
	else:
		file_n_args=''
	tokens_path=tokens_path[:-1]
	info=[x for x in info if x!='']
	slashes=len(info)
	
	dir_len=0
	for i in (tokens_path):
		dir_len+=len(i)
	dir_len+=slashes
	vec.append(int(dir_len))								
	

	###3
	num_subdir=len(tokens_path)
	vec.append(num_subdir)
	###4									
	TLD=token_dom[-1]	
	###5
	vec.append(len(dom))
	###6 									
	vec.append(len(token_dom))		
	###7			
	vec.append(len(tokens_path)) 					
	###8
	is_ip=has_ip(token_dom)
	vec.append(is_ip) 								
	###9
	domain_tok_lengths=[]
	for i in token_dom:
		domain_tok_lengths.append(len(i))
	largest_dom_token_len=max(domain_tok_lengths)
	vec.append(largest_dom_token_len)  				
	###10
	avg_dom_Tok_len=float(sum(domain_tok_lengths))/len(domain_tok_lengths)

	vec.append(avg_dom_Tok_len)     				

	path_tok_lengts=[]
	path_tok_dots=0
	path_tok_delims=0
	avg_path_Tok_len=0
	largest_path_token_len=0
	### 11 and 12
	if len(tokens_path):
		for i in tokens_path:
			path_tok_lengts.append(len(i))
			path_tok_dots=dots_in_total(i)
			path_tok_delims=delimiters_total(i)
		avg_path_Tok_len=float(sum(path_tok_lengts))/len(path_tok_lengts)
		largest_path_token_len=max(path_tok_lengts)
		vec.append(largest_path_token_len) 				
		vec.append(avg_path_Tok_len)					
	else:
		vec.append(largest_path_token_len)				
		vec.append(avg_path_Tok_len)					
	#13
	if is_ip:
		vec.append(0)									
	else:
		for i in TLDs:
			if re.search(i,TLD,re.IGNORECASE):
				vec.append(1)							
				break
		else:
			vec.append(0)	
			
	##14 , 15 and 16									
	if file_n_args!='':		
		tmp=file_n_args.split('?')
		file=tmp[0]
		if len(tmp)>1:
			args=tmp[1]
		else:
			args=''
		vec.append(len(file))							
		vec.append(dots_in_total(file))					
		vec.append(delimiters_total(file))					
		if args=='':
			vec.append(0)									
			vec.append(0)									
			vec.append(0)									
			vec.append(0)									
		else:
			vec.append(len(args)+1)							
			arb=args.split('&')
			vec.append(len(arb))							
			len_var=[]
			max_delim=[]
			for i in arb:
				tmp=i.split('=')
				if len(tmp)>1:
					len_var.append(len(tmp[1]))
					max_delim.append(delimiters_total(tmp[0]))
					max_delim.append(delimiters_total(tmp[1]))
				else:
					len_var.append(0)
					max_delim.append(0)
			vec.append(max(len_var))						
			
			max_delim=max(max_delim)
			vec.append(max_delim)							

	else:
		vec.append(0)									
		vec.append(0)									
		vec.append(0)									
		vec.append(0)									
		vec.append(0)								
		vec.append(0)									
		vec.append(0)									
	
	#Host Based Features
	avg_month_time=365.2425/12.0
	while(True):
		if(not dom[-1].isalnum()):
			dom=dom[:-1]
		else:
			break
	try:
		who_info=whois.query(dom)
		if who_info is None:
			raise Exception("no data found")
	except Exception:
		vec.append(-1)									
		vec.append(-1)									
		vec.append(-1)									
		vec.append(-1)								
		return vec

	if(who_info.creation_date == None and who_info.expiration_date == None and who_info.last_updated == None):
		vec.append(-1)									
		vec.append(-1)									
		vec.append(-1)									
		vec.append(-1)									
		return vec

	if(who_info.creation_date==None or type(who_info.creation_date) is str):
		vec.append(-1)
	else:
		if(type(who_info.creation_date) is list): 
			create_date=who_info.creation_date[-1]
		else:
			create_date=who_info.creation_date
		if(type(create_date) is datetime.datetime):
			today_date=datetime.datetime.now()
			create_age_in_mon=((today_date - create_date).days)/avg_month_time
			create_age_in_mon=round(create_age_in_mon)
			vec.append(create_age_in_mon)					
		else:
			vec.append(-1)									

	if(who_info.expiration_date==None or type(who_info.expiration_date) is str):
		vec.append(-1)
	else:
		if(type(who_info.expiration_date) is list):
			expiry_date=who_info.expiration_date[-1]
		else:
			expiry_date=who_info.expiration_date
		if(type(expiry_date) is datetime.datetime):
			today_date=datetime.datetime.now()
			expiry_age_in_mon=((expiry_date - today_date).days)/avg_month_time
			expiry_age_in_mon=round(expiry_age_in_mon)
			vec.append(expiry_age_in_mon)					
		else:
			vec.append(-1)									

	if(who_info.last_updated==None or type(who_info.last_updated) is str):
		vec.append(-1)		
	else:
		if(type(who_info.last_updated) is list):
			update_date=who_info.last_updated[-1]
		else:
			update_date=who_info.last_updated
		if(type(update_date) is datetime.datetime):
			today_date=datetime.datetime.now()
			update_age_in_days=((today_date - update_date).days)
			vec.append(update_age_in_days)					
		else:
			vec.append(-1)

	vec.append(-1)
	return vec

