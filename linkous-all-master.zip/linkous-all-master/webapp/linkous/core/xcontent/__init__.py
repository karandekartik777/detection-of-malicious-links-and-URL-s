from bs4 import BeautifulSoup
import re
import requests
import json

from ..functions import validURL

from ..xpagerank import getPageRank, pagerankClassifier, getDomain
from ..xspam import spamScan
from ..xlex import predictLex

from ..db import search

from func_timeout import func_timeout

def getTags (url, tags = ['script', 'iframe']):
  try:
    url = validURL(url)
    content = requests.get(url, timeout=1).text
    soup = BeautifulSoup(content, "html.parser")
    return soup.findAll(tags)
  except:
    return []

def get_tag_data(tags):
  results = []
  for tag in tags:
    data = {
      'tag': tag.name,
      'text': tag.text,
      'src': None
    }

    if tag.has_attr('src'):
      data['src'] = tag['src']

    results.append(data)
  
  return results

def classifier (tag):
    
  results = {
      'database': True,
      'pagerank': True,
      'lex': True,
      'spam': True
  }

  url = tag['src']

  # pagerank 

  domain = getDomain(tag['src'])


  rank = getPageRank(domain)
  rank = json.loads(rank)

  if len(rank['response']) == 0:
    results['pagerank'] = False
  else:
    rank = rank['response'][0]
    rank = pagerankClassifier(rank)
    if rank["rank"] < 3:
      results['pagerank'] = False
  
  # database search
  
  db = search(url)

  if db['count'] > 0:
    results['database'] = False
  
  # spam classifier

  spam = spamScan(url)
  if spam['result'] == 'unsafe' or spam['result'] == 'risky':
    results['spam'] = False

  # lex

  lex = predictLex(url)

  if lex == 'unsafe':
    results['lex'] = False

  return results
    
def tagDetect(tagData):
  data = []
  for tag in tagData:
    detection = {
        'payload': False,
        'external': False,
        'state': 'safe'
    }

    if 'src' in tag:
      if tag['src'] is not None:
        if re.search("&#[0-9]{3};", tag['src']):
            detection['payload'] = True
            detection['state'] = 'risky'
        if re.search("(http\:\/\/|https\:\/\/|\/\/)([^\s]+)", tag['src']):
          # is a valid link, not local file
          detection['external'] = True
          detection['ml'] = classifier(tag)
          count = 0
          for _, (analyzer, result) in enumerate(detection['ml'].items()):
            if result == False:
                count += 1
          if count == 1:
            detection['state'] = 'risky'
          elif count > 1:
            detection['state'] = 'unsafe'

    
    
    data.append({'tag': tag, 'detection': detection})
  return data

def contentClassifier(url):
  try:
    # tags = func_timeout(5, getTags, args=tuple([url]), kwargs=None)
    tags = getTags(url)
    # tags = get_tag_data(tags)
    tags = func_timeout(5, get_tag_data, args=tuple([tags]), kwargs=None)
    return tagDetect(tags)
  except:
    return {}