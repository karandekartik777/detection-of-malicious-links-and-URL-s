import re
import hashlib
import os

SALT = os.environ['SALT']

def hasher(s: str) -> str:
    return hashlib.sha256(str(s+SALT).encode()).hexdigest()

def processURL(url):
    if url.startswith('http'):
        url = re.sub(r'https?://', '', url)
    if url.startswith('www.'):
        url = re.sub(r'www.', '', url)
    return url.lower()

def validURL(url):
    if url.startswith('//'):
        url = 'http:' + url
        return url
    if not url.startswith('http'):
        url = 'http://' + url
    return url

if __name__ == '__main__':
    print(validURL('http://www.google.com/?q=abcdef'))
    print(validURL('https://www.google.com/?q=abcdef'))
    print(validURL('www.google.com/?q=abcdef'))
    print(validURL('http://google.com/?q=abcdef'))
    print(validURL('https://google.com/?q=abcdef'))