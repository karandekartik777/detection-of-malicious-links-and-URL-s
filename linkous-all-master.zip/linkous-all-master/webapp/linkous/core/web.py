import requests

from .functions import processURL

BASE_URL = "http://ip-api.com/json/"

ORG_FIELDS = "?fields=status,message,continent,continentCode,country,countryCode,region,regionName,city,district,zip,lat,lon,timezone,currency,isp,org,as,asname,mobile,proxy,hosting,query"
USER_FIELDS = "?fields=status,message,continent,continentCode,country,countryCode,query,region,regionName"


def websiteInfo(url, role = 'user'):
  url = processURL(url)
  url = BASE_URL + url
  if role == 'user':
    url += USER_FIELDS
  else:
    url += ORG_FIELDS
  info = requests.get(url).text
  return info

if __name__ == '__main__':
  while True:
    url = input("Enter url: ")
    role = input("Enter role: ")
    info = getInfo(url, role)
    print(info)