import requests
from bs4 import BeautifulSoup

from ..functions import validURL
import random

import joblib
import os

BASE_PATH = os.path.dirname(os.path.realpath(__file__))

CV = joblib.load(os.path.join(BASE_PATH, 'assets/CountVectorizer.pkl'))  # CountVectorizer
SC = joblib.load(os.path.join(BASE_PATH, 'assets/SpamClassifier.pkl'))  # SpamClassifier

print('[ + ] Loaded Spam Analyzer!')

def getContent(url):
    url = validURL(url)
    content = requests.get(url).text
    soup = BeautifulSoup(content, "html.parser")
    for script in soup(["script", "style"]):
        script.extract()
    text = soup.findAll(text=True)
    text = [item.strip() for item in text if str(item)]
    return ''.join(text)

def spamScan(url):
    try:
        text = getContent(url)
        msgInput = CV.transform([text])
        predict = SC.predict(msgInput)
        probability = SC.predict_proba(msgInput)[0]
        return {
            'result': 'unsafe' if predict[0] == 0 else 'safe',
            'probability': probability[0]
        }
    except Exception:
        return {
            "result": "risky",
            "status": "invalid-url"
        }


if __name__ == '__main__':
    while True:
        print(getContent(str(input("Enter URL: "))))