import random
import json

def getStub(url):
    # res = {
    #     'result': random.choice(['safe', 'unsafe'])
    # }
    return json.dumps({
        'result': 'safe'
    })