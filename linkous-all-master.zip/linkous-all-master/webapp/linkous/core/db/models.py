import datetime

from mongoengine import Document, EmbeddedDocument
from mongoengine import StringField, DateTimeField, ReferenceField, BooleanField
from mongoengine import ListField, EmbeddedDocumentListField, Q

class User(Document):
    meta = {'collection': 'users'}
    name = StringField()
    email = StringField()
    password = StringField()
    role = StringField(default="user")
    joined_date = DateTimeField(default=datetime.datetime.utcnow)

class API(Document):
    meta = {'collection': 'api'}
    user = ReferenceField(User)
    api_key = StringField()

class Report(EmbeddedDocument):
    user = ReferenceField(User)
    report_date = DateTimeField(default=datetime.datetime.utcnow)
    brief = StringField()
    valid = BooleanField(default=False)
    validated_by = ReferenceField(User)

class Reports(Document):
    meta = {'collection': 'reports'}
    url = StringField()
    reports = EmbeddedDocumentListField(Report)
    # or ListField(EmbeddedDocument(Report))