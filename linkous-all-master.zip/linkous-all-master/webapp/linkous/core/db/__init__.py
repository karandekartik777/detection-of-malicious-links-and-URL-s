import os
import datetime
import time

import requests

from flask import session
from mongoengine import connect, Q

from typing import Dict, List

from .models import User, Reports, Report, API
from ..functions import hasher, processURL

# local testing
# connect('linkous-db')

# mlab server
MONGO_USER = os.environ['MONGO_USER']
MONGO_KEY = os.environ['MONGO_KEY']

MONGO_URI = "mongodb://{}:{}@ds043398.mlab.com:43398/linkous-db?retryWrites=false".format(MONGO_USER, MONGO_KEY)

if 'NODE_ENV' in os.environ and os.environ['NODE_ENV'] == 'development':
    print("[ + ] Connected to local MongoDB server.")
    connect('linkous-db')
else:
    print("[ + ] Connected to cloud MongoDB server.")
    connect('linkous-db', host=MONGO_URI)

def registerUser(user):
    """
    Accepts:
        user: {
            name,
            email,
            password,
            role
        }
    Returns:
        std-res
    """

    user_count = User.objects(email=user['email']).count()

    if user_count > 0:
        # User exists
        return {
            "status": "fail",
            "message": "email-exists"
        }

    if 'role' in user:
        # if user role is provided, set it
        user = User(
            name = user['name'],
            email = user['email'],
            password = hasher(user['password']),
            role = user['role']
        )

        if user['role'] == 'org':
            print('Creating API key for org: {}'. format(user['name']))
            api_key = hasher(user['email'] + str(time.time()))       

    else:
        # else, leave it default, which is 'user'
        user = User(
            name = user['name'],
            email = user['email'],
            password = hasher(user['password']),
        )
    
    # save into db
    process = user.save()

    # session['user'] = {
    #     'email': user['email'],
    #     'role': user['role']
    # }
    
    res = {
        "status": "success",
        "message": "user-registered-with-id:{}".format(process.id)
        # "message": "user-registered-with-id:{}".format(1)
    }

    if user['role'] == 'org':
        API(
            user = user,
            api_key = api_key
        ).save()
        res['apiKey'] = api_key

    return res

def reportLink(link):
    """
    Accepts:
        link: {
            url,
            brief
        }
    Returns:
        std-res
    """

    link['url'] = processURL(link['url'])

    reports = Reports.objects(url = link['url'])

    user = User.objects.get(email = session['user']['email'])

    if reports.count() == 0:

        # a report doc with the url doesn't exist
        # so create one and insert first report into reports[]

        saved_report = Reports(url = link['url'])
        saved_report.save()
        
        if user['role'] == 'admin':
            # validate the report if it is posted by an admin
            print('admin')
            report = Report(
                user = user,
                brief = link['brief'],
                valid = True,
                validated_by = user
            )
            saved_report.reports.append(report)
            saved_report.save()
        else:
            # add a non-validated report if it is posted by a user
            print('user')
            report = Report(
                user = user,
                brief = link['brief']
            )
            saved_report.reports.append(report)
            saved_report.save()    
    else:
        # report with url exists
        try:
            user_reports = Reports.objects.get(url = link['url'], reports__user = user)
            if user_reports.reports.count() > 0:
                return {
                    "status": "fail",
                    "message": "report-exists"
                }
        except:
            print('exception')
        
        saved_report = reports[0]

        if user['role'] == 'admin':
            print('admin')
            report = Report(
                user = user,
                brief = link['brief'],
                valid = True,
                validated_by = user
            )
            saved_report.reports.append(report)
            saved_report.save()
        else:
            print('user')
            report = Report(
                user = user,
                brief = link['brief']
            )
            saved_report.reports.append(report)
            saved_report.save()
    
    return {
        "status": "success",
        "message": "report-created"
    }

def search(url: str):

    url = processURL(url)
    
    report_doc = Reports.objects(url = url)

    if report_doc.count() == 0:
        return {
            "count": 0
        }
    
    report_doc = report_doc[0]

    if report_doc.reports.count() == 0:
        return {
            "count": 0
        }
    
    res = {
        "count": report_doc.reports.count(),
        "first_report": report_doc.reports[0].user.email,
    }

    res["valid_count"] = report_doc.reports.filter(valid=True).count()
    report_date = report_doc.reports[0].report_date
    res["report_date"] = report_date.strftime("%Y-%m-%dT%H:%M:%SZ")
    
    return res

def fetchReports():
    # fetch = Reports.objects(reports__match = {'valid': False}).limit(10)
    fetch = Reports.objects.filter(reports__valid = False).fields(url=1, reports={'$elemMatch': {'valid': False}})
    count = fetch.count()
    fetch = fetch.limit(10)
    # users = User.objects.filter(schools__name=name).fields(schools={'$elemMatch': {'name': name}})
    print(fetch)
    res = []
    for _, reports in enumerate(fetch):
        for _, report in enumerate(reports.reports):
            print(report.user.id)
            res.append({
                'url': reports.url,
                'user': {
                    # 'id': str(report.user.id),
                    'name': report.user.name,
                    'email': report.user.email
                },
                'date': report.report_date.strftime("%Y-%m-%dT%H:%M:%SZ"),
                'brief': report.brief
            })
    return {
        'report_count': count,
        'reports': res
    }

def approveReport(url, email):
    print("{}, {}".format(email, url))
    reports = Reports.objects.get(url = url)
    for _, report in enumerate(reports.reports):
        print(report.user.email)
        if report.user.email == email:
            report.valid = True
            report.validated_by = User.objects.get(email = session['user']['email'])
            reports.save()
            return {
                "status": "approved"
            }
    return {
        "status": 403
    }

def rejectReport(url, email):
    print("{}, {}".format(email, url))
    reports = Reports.objects.get(url = url)

    for _, report in enumerate(reports.reports):
        print(report.user.email)
        if report.user.email == email:
            reports.update(pull__reports = report)
            reports.save()
            return {
                "status": "rejected"
            }
    return {
        "status": 403
    }

def getAllReports():

    fetch = Reports.objects()
    res = []

    for _, reports in enumerate(fetch):
        row = {
            'url': reports.url,
            'reports': []
        }
        for _, report in enumerate(reports.reports):
            data = {
                'user': {
                    'name': report.user.name,
                    'email': report.user.email
                },
                'brief': report.brief,
                'date': report.report_date.strftime("%Y-%m-%dT%H:%M:%SZ"),
                'valid': report.valid
            }
            if report.valid:
                data['validated_by'] = {
                    'name': report.validated_by.name,
                    'email': report.validated_by.email
                }
            row['reports'].append(data)
        res.append(row)

    return res

# def populate ():
#     url = 'https://vaibhavshinde.com'
#     data = requests.get(url).text()
#     print(data)
    # u = User.objects.get(email='linkous-bot')


# Usage examples

# print(registerUser({
#     'name': 'Vaibhav',
#     'email': 'vaibhavkshinde20@gmail.com',
#     'password': 'root',
#     'role': 'admin'
# }))

# print(reportLink({
#     "url": "user.xyz",
#     "brief": "brief about abc.xyz"
# }))
