#!/bin/bash

echo "MODE: ${NODE_ENV}"

cd frontend
vue-cli-service build
cd ..

# cat dist/index.html | sed -E "s/(href|src)=\/([^ >]*)/\1=\"{{ url_for('static', filename='\2') }}\"/g" - > $SERVER/templates/index.html

cp frontend/dist/index.html linkous/templates/index.html

echo '[i] Removing old build files'
rm -rf linkous/static
echo '[+] Done'

echo '[i] Copying new build into server'

mkdir -p linkous/static/css linkous/static/js
cp frontend/dist/favicon.ico linkous/static/
cp frontend/dist/css/* linkous/static/css
cp frontend/dist/js/* linkous/static/js

echo '[+] Done'