#/bin/bash

export NODE_ENV=development

echo "MODE: ${NODE_ENV}"

. tools/set-env.sh

# ./tools/load-frontend.sh

# local system only

sudo systemctl start mongodb

python app.py