#/bin/bash

echo "MODE: ${NODE_ENV}"

cd frontend
vue-cli-service serve

# Move index.html to templates/index.html

# Move css, js, favicon to static folder

# To Format to:
# {{ url_for('static', filename='style.css') }}

# Works totally
#   -E "s/(href|src)=\/([^ >]*)/\1=\"{{ url_for('static', filename='\2') }}\"/g"
# SED doesnt support \s, just added literal space in [^ >]*