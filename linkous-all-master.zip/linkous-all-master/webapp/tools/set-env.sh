export SALT="bW9uZ28taXMtZ3JlYXQK"

export SECRET_KEY="dkAhYiNhdgo="
export PAGERANK_KEY="cw08c400go0wwwwgoccsok0cgk4kw8oo0sc8c00k"

# Database configs

export MONGO_USER="dbman"
export MONGO_KEY="root123$"

# export DB_URI="mongodb://${MONGO_USER}:${MONGO_KEY}@ds043398.mlab.com:43398/linkous-db?retryWrites=false"

# export USER="5edcf764d203cc3e7c4b8dd9"