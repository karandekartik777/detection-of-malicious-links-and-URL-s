<template>
  <div id="app">
    <!-- v-if="['Search', 'Dashboard'].includes($route.name)" -->
    <header v-if="['Search', 'Dashboard'].includes($route.name)">
      <div>
        <h1 class="logo">
          <router-link to="/">Linkous</router-link>
        </h1>
        <nav>
          <router-link to="/dashboard">
            <i class="fa fa-desktop"></i> 
            Dashboard
          </router-link>
        </nav>
      </div>
    </header>

    <div class="content">
      <transition name="fade" mode="out-in">
        <router-view></router-view>
      </transition>
    </div>
  </div>
</template>

<script>
export default {
  
};
</script>

<style lang="scss">
  @import '@/assets/scss/global.scss';
</style>