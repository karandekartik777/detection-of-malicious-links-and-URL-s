import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'

Vue.config.productionTip = false

Vue.mixin({
  methods: {
    getURL: (path) => {
      // development
      if (process.env.NODE_ENV == 'development') {
        const port = '5000';
        return window.location.protocol + '//' + window.location.hostname + ':' + port + path;
      }

      // production
      return window.location.protocol + '//' + window.location.host + path;
    }
  }
})

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
