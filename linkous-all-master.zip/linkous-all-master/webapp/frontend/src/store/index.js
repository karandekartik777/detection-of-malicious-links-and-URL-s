import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    url: 'google.com',
    user: {
      state: 'invalid',
    },
  },
  mutations: {
    setURL (state, url) {
      state.url = url
    },
    setUser (state, user) {
      state.user = user
    }
  },
  getters: {
    url: state => state.url,
    user: state => state.user
  },
  actions: {
  },
  modules: {
  }
})
