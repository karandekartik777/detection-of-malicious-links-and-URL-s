<template>
  <div class="result-card website-info">

    <div class="title">Content Analysis</div>


    <div class="details">

      
      <i v-if="status == 'fetching'" class="loader fa fa-spinner fa-spin"></i>
      
      <canvas ref="pieChart" id="pieChart"></canvas>

      <div v-if="status != 'fetching'" style="word-break: break-all;">

        <div class="db-info">

          <!-- {{ content }}
          <br>
          mal tags
          <br>
          {{ malicious_tags }} -->

          <div v-if="content && (content.length == 0 || malicious_tags.length == 0)" class="msg safe-msg">
            All of the links in the content were found to be safe by our analyzers!
          </div>

          <div class="msg unsafe-msg" v-if="content && malicious_tags.length > 0">
            {{ malicious_tags.length }}/{{ content.length }} links were found to be malicious!
          </div>

          <div style="margin: 12px 0;">
            <div v-for="e in malicious_tags" :key="e.tag + Math.random()" class="data-field">
              <h5>{{ e.tag.src }} - &lt;{{ e.tag.tag }}&gt; </h5>

              <div class="content-detection">
              
                <div class="det-field payload" v-if="e.detection.payload == true">
                  <h5 >Payload</h5>
                  <div class="small-unsafe">{{ e.tag.src }}</div>
                </div>
                <div class="det-field ml-filter" v-for="(result, ml) in e.detection.ml" :key="JSON.stringify(ml) + Math.random()">
                  <h5>{{ getFullName(ml) }}</h5>
                  <div :class="'small-' + (result ? 'safe' : 'unsafe')">{{ result ? 'Safe' : 'Unsafe' }}</div>
                </div>

              </div>
            </div>
          </div>

        </div>

      </div>
    </div>
  
  </div>
</template>
<script>
import Chart from 'chart.js'

export default {
  name: 'ContentCard',
  props: ['title', 'status', 'content'],
  data: () => ({
    chart: '',
    content_test: [
      {
        tag: {
          tag: 'script',
          text: '',
          src: 'https://malicious.com'
        },
        detection: {
          payload: false,
          external: true,
          ml: {
            pagerank: true,
            lex: true,
            spam: true,
          },
          state: 'safe'
        }
      },
      {
        tag: {
          tag: 'script',
          text: '',
          src: 'https://malicious.com'
        },
        detection: {
          payload: false,
          external: true,
          ml: {
            pagerank: false,
            lex: true,
            spam: false,
          },
          state: 'unsafe'
        }
      },
      {
        tag: {
          tag: 'script',
          text: '',
          src: '#payload goes here!'
        },
        detection: {
          payload: true,
          external: true,
          ml: {
            pagerank: true,
            lex: true,
            spam: true,
          },
          state: 'risky'
        }
      },
    ],
    malicious_tags: [],
  }),
  watch: {
    content () {
      console.log('content changed')
      console.log(this.content)
      this.visualize()
    }
  },
  mounted () {
    this.visualize()
  },
  methods: {
    getFullName (s) {
      if (s == 'lex')
        return 'Lexical Analysis'
      else if (s == 'pagerank')
        return 'Pagerank'
      else if (s == 'spam')
        return 'Spam Analysis'
      else
        return 'Database'
    },
    visualize () {

      this.$refs.pieChart.style.display = "none"

      const tags = this.content

      if (!tags || Object.keys(tags).length == 1) {
        this.drawChart(0)
        return false
      }

      this.malicious_tags = []

      for (let e of tags) {
        if (e.detection.state == 'unsafe' || e.detection.state == 'risky') {
          this.malicious_tags.push(e)
        }
      }

      let perc = this.malicious_tags.length / tags.length * 100

      this.drawChart(perc)

    },
    drawChart (percentage) {

      this.$refs.pieChart.style.display = "block"

      let unsafe_bg = 'rgba(255, 99, 132, 0.2)'
      let unsafe_color = 'rgba(255, 99, 132, 1)'
      
      unsafe_bg = 'rgba(255, 60, 100, 0.2)'
      unsafe_color = 'rgba(255, 60, 100, 1)'

      let safe_bg = 'rgba(15, 146, 26, 0.2)'
      let safe_color = 'rgba(15, 146, 26, 1)'
      
      safe_bg = 'rgba(15, 180, 26, 0.2)'
      safe_color = 'rgba(15, 180, 26, 1)'
      
      let data = {
        labels: ['Safe', 'Unsafe'],
        datasets: [{
          data: [100 - percentage, percentage],
          backgroundColor: [safe_bg, unsafe_bg],
          borderColor: [safe_color, unsafe_color],
          borderWidth: 1
        }],
      }

      if (this.chart == '')
        this.chart = new Chart('pieChart', {
          type: 'doughnut',
          data: data
        });
      else {
        this.chart.data = data
        this.chart.update()
      }

    }
  }
}
</script>
<style lang="scss" scoped>

.det-field {
  margin: 12px 0;
  .small-safe, .small-unsafe {
    font-weight: bold;
    font-size: 22px;
    text-transform: uppercase;
    margin-top: 12px;
  }
  .small-safe {
    color: #0f921a;
  }
  .small-unsafe {
    color: #bc3d40;
  }
}

h5 {
  font-size: 18px;
  margin-bottom: 6px;
}

.content-detection {
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  margin: 12px 0;

  > div {
    flex: 0 50%;
    text-align: center;
  }
}

.msg {
  display: block;
  text-align: center;
  margin: 26px 0;
  color: #dae4f0; 
}

#pieChart {
  margin: 24px 0;
}

#map-ctr {
  margin-top: 40px;
  border-top: 2px solid #356295;
  padding-top: 20px;
  #map {
    height: 180px;
  }
}

.database-unsafe {
  flex: 1;
}

.db-info {
  border-top: 2px solid #356295;
  margin-top: 18px;
  padding: 12px 24px;
  padding-top: 32px;

  display: flex;
  flex-direction: column;
  width: 100%;
  text-align: left;
  font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
  .data-field {
    margin-bottom: 22px;

    > h5 {
      font-size: 18px;
      color: #92b3d8;
      font-weight: 800;
      margin-bottom: 12px;
    }
    > div {
      font-size: 18px;
      color: #dae4f0;
    }
  }
}

.result-card {
  background: #263444;
  color: #3286e6;
  display: flex;
  flex-direction: column;
  padding: 24px 0 16px;
  margin-bottom: 12px;
  border-radius: 12px;

  .details {
    text-align: center;
  }

  .loader {
    font-size: 72px;
    color: #c7c7c7;
    text-align: center;
    margin: 36px 0 16px 0;
  }
  
  .title {
    font-weight: 700;
    text-transform: uppercase;
    text-align: center;
  }


  .result {
    text-align: center;
    padding: 24px 0 18px 0;
    font-size: 32px;
    text-transform: uppercase;
    font-weight: 900;
    color: #0f921a;
  }
  .result.unsafe {
    color: #bc3d40;
  }
  .result.risky {
    color: #d9760d;
  }
}
</style>