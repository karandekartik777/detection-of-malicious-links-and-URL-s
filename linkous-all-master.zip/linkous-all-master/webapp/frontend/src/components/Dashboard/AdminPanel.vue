<template>
  <div id="admin-panel">

    <div class="reports-center">
    
      <h3><center>Reports</center></h3>
      
      <center class="info">
        <span>10</span> reports per page &bull; <span>{{ reports.report_count }}</span> reports total
      </center>
      
      <button @click="fetchReports" class="load-more">
        <svg :class="fetchStatus == 'fetching' ? 'spin' : ''" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M14.657 15.657A8 8 0 1117 10h-2a6 6 0 10-1.757 4.243l1.414 1.414zM12 10h8l-4 4-4-4z" fill="currentColor" fill-rule="evenodd"/></svg>
        <span>Load more</span>
      </button>

      <div class="reports">

        <Report v-for="report in reports.reports" :key="report.url + report.date" :report="report"/>

        <div class="no-reports" v-if="reports.reports && reports.reports.length == 0">
          <center>
            There are no unverified reports at the moment.
          </center>
        </div>
      
      </div>

    </div>

    <div class="user-creator">
    
      <CreateUser/>

    </div>
    
    

  </div>
</template>
<script>
import Report from '@/components/Dashboard/Report.vue'
import CreateUser from '@/components/Dashboard/CreateUser.vue'

export default {
  name: 'AdminPanel',
  components: {
    Report,
    CreateUser
  },
  computed: {
    user: {
      get() {
        return this.$store.state.user;
      },
      set(value) {
        this.$store.commit("setUser", value);
      }
    }
  },
  data: () => {
    return {
      fetchStatus: 'idle',
      reports: {},
      reports_stub: [
        {
          url: 'admin.xyz',
          user: {
            name: 'Chandler Bing',
            email: 'misschanandler@hotmail.com'
          },
          date: '2020-05-13',
          brief: 'I get spam TV guides at my apartment!'
        },
        {
          url: 'admin.xyz',
          user: {
            name: 'Chandler Bing',
            email: 'misschanandler@hotmail.com'
          },
          date: '2020-05-13',
          brief: 'I get spam TV guides at my apartment!'
        },
        {
          url: 'admin.xyz',
          user: {
            name: 'Chandler Bing',
            email: 'misschanandler@hotmail.com'
          },
          date: '2020-05-13',
          brief: 'I get spam TV guides at my apartment!'
        },
      ]
    }
  },
  async created() {
    let res = await fetch(this.getURL('/api/fetch_reports'), {
      credentials: "include"
    }).then((res) => res.json())
    console.log(res)
    this.reports = res
  },
  methods: {
    async fetchReports() {
      let res = await fetch(this.getURL('/api/fetch_reports'), {
        credentials: "include"
      }).then((res) => res.json())
      console.log(res)
      this.reports = res
    }
  }
}
</script>
<style lang="scss" scoped>

@media (max-width: 540px) {
  #admin-panel {
    flex-direction: column;
  }
}

#admin-panel {
  display: flex;
  min-height: 540px;
  div {
    flex: 1;
    display: block;
  }
}

.no-reports {
  font-style: italic;
  color: #888;
  margin: 24px 0;
}

#admin-panel {
  margin-top: 32px;
  h3 {
    font-size: 42px;
    margin: 16px 0;
  }
  .info {
    font-family: Roboto, Arial, Helvetica;
    margin: 12px 0 18px 0;
    font-size: 14px;
  }
  button.load-more {
    background: none;
    border: none;
    display: flex;
    color: #fff;
    cursor: pointer;
    margin: 12px auto;

    svg {
      height: 16px;
      margin-right: 8px;
    }

  }
}

svg.spin {
  animation-duration: 1s;
  animation-name: spin; 
  animation-iteration-count: infinite;
}

@keyframes spin {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}

.reports {
  display: flex;
  flex-wrap: wrap;
  flex-direction: column;
  
  .break {
    flex-basis: 100%;
    height: 0;
  }
}
</style>