<template>
  <div class="flex">
        <div class="login">
          <form @submit="logIn">
            <h2>Log In</h2>
            <input type="email" v-model="forms.logIn.email" placeholder="E-Mail address"/>
            <input type="password" v-model="forms.logIn.password" placeholder="Password"/>
            <button>Log In</button>
          </form>
        </div>
        <div class="register">
          <form @submit="register">
            <h2>Register</h2>
            <input type="text" v-model="forms.register.name" placeholder="Name"/>
            <input type="email" v-model="forms.register.email" placeholder="E-Mail address"/>
            <input type="password" v-model="forms.register.password" placeholder="Password"/>
            <button>Register</button>
          </form>
        </div>
  </div>
</template>
<script>
export default {
  name: 'Greeter',
  computed: {
    user: {
      get() {
        return this.$store.state.user;
      },
      set(value) {
        this.$store.commit("setUser", value);
      }
    }
  },
  data: () => {
    return {
      forms: {
        logIn: {
          email: '',
          password: '',
        },
        register: {
          name: '',
          email: '',
          password: ''
        },
      }
    }
  },
  methods: {
    async register(e) {
      
      let data = this.forms.register;

      if (data.email.length == 0 || data.password.length == 0 || data.name.length == 0) {
        alert("Please do not leave any of the fields blank. \nTry again.")
        return false
      }

      let form = new FormData();

      for (let field in data)
        form.append(field, data[field]);
      
      let res = await fetch(this.getURL('/api/register'), {
        method: 'POST',
        body: form,
        credentials: "include"
      }).then(res => res.json());

      if (res.status == 'success') {
        alert("You are registered!\nLog in to continue!")
      }

      e.preventDefault();
      return false;
    },
    async logIn(e) {
      let data = this.forms.logIn;

      if (data.email.length == 0 || data.password.length == 0) {
        alert("Please do not leave any of the fields blank. \nTry again.")
        return false
      }

      let form = new FormData();

      for (let field in data)
        form.append(field, data[field]);
      
      let res = await fetch(this.getURL('/api/sign-in'), {
        method: 'POST',
        body: form,
        credentials: "include"
      }).then(res => res.json());

      console.log('login', res);

      if (res.state == 'valid') {
        this.user = res
        this.user.state = 'valid'
      } else {
        alert("Invalid details");
        this.user.state = 'invalid';
        this.forms.logIn.email = '';
        this.forms.logIn.password = '';
      }
      console.log(this.user)
      e.preventDefault();
      return false;
    }
  }
}
</script>
<style lang="scss" scoped>
.flex {
  display: flex;
  width: 100%;
  > div {
    flex: 1;
  }
}

form {

  display: table;
  width: 95%;
  max-width: 400px;
  margin: 40px auto;

  h2 {
    margin-bottom: 40px;
  }

  input, textarea, select {
    width: 100%;
    display: block;
    margin: 12px 0;
    border-radius: 4px;
    padding-left: 8px;
    border: 0;
    background: #dfdfdf;
    font-family: 'Open Sans', Roboto, Helvetica, sans-serif;
  }
  input, select {
    height: 36px;
  }
  textarea {
    padding: 8px;
    resize: vertical;
    height: 60px;
    max-height: 120px;
  }
  button {
    display: block;
    background: #5077fc;
    color: #fff;
    text-transform: uppercase;
    padding: 8px 16px;
    font-weight: bold;
    border-radius: 6px;
    border: 0;
    cursor: pointer;
    float: right;
  }
}


@media (max-width: 540px) {
  #user-info {
    flex-direction: column;
    justify-content: space-between;
    padding: 20px 0;
    .name {
      margin-bottom: 16px;
    }
  }
  .flex {
    flex-direction: column;
  }
}

</style>