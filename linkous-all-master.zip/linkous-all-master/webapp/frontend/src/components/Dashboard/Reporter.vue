<template>
  <div class="report-link">
    <form @submit="report">
      <h2>Report a Link</h2>
      <input type="text" v-model="forms.report.url" placeholder="example.com" />
      <textarea v-model="forms.report.brief" placeholder="Mention why it is not a safe link" />
      <button>Report</button>
    </form>
  </div>
</template>
<script>
export default {
  name: "Reporter",
  data: () => {
    return {
      forms: {
        report: {
          url: "",
          brief: ""
        }
      }
    };
  },
  methods: {
    async report(e) {
      let data = this.forms.report;
      console.log(data);

      if (data.url.length == 0 || data.brief.length == 0) {
        alert("Please do not leave any of the fields blank. \nTry again.")
        return false
      }

      let form = new FormData();

      for (let field in data) {
        form.append(field, data[field]);
      }

      let res = await fetch(this.getURL("/api/report"), {
        method: "POST",
        body: form,
        credentials: "include"
      }).then(res => res.json());

      console.log(res);
      
      if (res.status == 'success')
        alert("The url was reported!\nThank you for making the web a safer place!")
      else
        if (res.message == 'report-exists')
          alert("You have already reported this link!")
          

      e.preventDefault();
      return false;
    }
  }
};
</script>
<style lang="scss" scoped>
form {

  display: table;
  width: 95%;
  max-width: 400px;
  margin: 40px auto;

  h2 {
    margin-bottom: 40px;
  }

  input, textarea, select {
    width: 100%;
    display: block;
    margin: 12px 0;
    border-radius: 4px;
    padding-left: 8px;
    border: 0;
    background: #dfdfdf;
    font-family: 'Open Sans', Roboto, Helvetica, sans-serif;
  }
  input, select {
    height: 36px;
  }
  textarea {
    padding: 8px;
    resize: vertical;
    height: 60px;
    max-height: 120px;
  }
  button {
    display: block;
    background: #5077fc;
    color: #fff;
    text-transform: uppercase;
    padding: 8px 16px;
    font-weight: bold;
    border-radius: 6px;
    border: 0;
    cursor: pointer;
    float: right;
  }
}
</style>