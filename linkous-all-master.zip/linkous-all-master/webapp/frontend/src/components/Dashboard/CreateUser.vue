<template>
  <form @submit="createUser" id="create-user">

    <h1><center>Create User</center></h1>

    <div style="margin: 36px 0">

      <input v-model="user.name" type="text" placeholder="Name"/>
      <input v-model="user.email" type="text" placeholder="Email Address"/>
      <input v-model="user.password" type="password" placeholder="Password"/>

      <select v-model="user.role">
        <option value="">SELECT ROLE</option>
        <option value="user">User</option>
        <option value="org">Organisation</option>
        <option value="admin">Admin</option>
      </select>

      <button>CREATE</button>

    </div>
    
  </form>
</template>
<script>
export default {
  name: 'CreateUser',
  data: () => {
    return {
      user: {
        name: '',
        email: '',
        password: '',
        role: ''
      }
    }
  },
  methods: {
    async createUser(e) {
      
      let user = this.user

      let form = new FormData();

      for (let field in user) {
        if (user[field].length == 0) {
          alert("You cannot leave any field empty...\nTry again.")
          return false
        }
        form.append(field, user[field]);
      }

      let res = await fetch(this.getURL("/api/create_user"), {
        method: "POST",
        body: form,
        credentials: "include"
      }).then(res => res.json());

      console.log(res)

      if (res.status == 'success')
        alert('User was registered!')
      else if (res.message == 'email-exists')
        alert('A user with that email exists!')
      else
        alert('An unexpected error has occurred')

      e.preventDefault()
      return false
    }
  }
}
</script>
<style lang="scss" scoped>

form {

  display: table;
  width: 95%;
  max-width: 400px;
  margin: 40px auto;

  h2 {
    margin-bottom: 40px;
  }

  input, textarea, select {
    width: 100%;
    display: block;
    margin: 12px 0;
    border-radius: 4px;
    padding-left: 8px;
    border: 0;
    background: #dfdfdf;
    font-family: 'Open Sans', Roboto, Helvetica, sans-serif;
  }
  input, select {
    height: 36px;
  }
  textarea {
    padding: 8px;
    resize: vertical;
    height: 60px;
    max-height: 120px;
  }
  button {
    display: block;
    background: #5077fc;
    color: #fff;
    text-transform: uppercase;
    padding: 8px 16px;
    font-weight: bold;
    border-radius: 6px;
    border: 0;
    cursor: pointer;
    float: right;
  }
}
</style>