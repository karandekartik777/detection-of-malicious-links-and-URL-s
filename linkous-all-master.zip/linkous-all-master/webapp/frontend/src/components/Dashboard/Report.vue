<template>
  <transition name="slide-fade">
    <div class="report" v-if="visible">
      <div class="title" @click="toggle = !toggle">
        <span class="domain">{{ report.url }}</span>
        <svg
          :class="toggle ? 'down' : 'up'"
          viewBox="0 0 20 20"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            fill="#9EC5F2"
            d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"
            fill-rule="evenodd"
          />
        </svg>
      </div>

      <transition name="slide-fade">
        <div class="details" :class="state" v-if="toggle">
          <transition name="slide-fade">
            <div class="msg-card" v-if="state == 'approved'">
              <svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                <path d="M0 11l2-2 5 5L18 3l2 2L7 18z" fill="currentColor" fill-rule="evenodd" />
              </svg>
              <span>APPROVED</span>
            </div>

            <div class="msg-card" v-if="state == 'rejected'">
              <svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M11.414 10l2.829-2.828-1.415-1.415L10 8.586 7.172 5.757 5.757 7.172 8.586 10l-2.829 2.828 1.415 1.415L10 11.414l2.828 2.829 1.415-1.415L11.414 10zM2.93 17.071c3.905 3.905 10.237 3.905 14.142 0 3.905-3.905 3.905-10.237 0-14.142-3.905-3.905-10.237-3.905-14.142 0-3.905 3.905-3.905 10.237 0 14.142zm1.414-1.414A8 8 0 1015.657 4.343 8 8 0 004.343 15.657z"
                  fill="currentColor"
                  fill-rule="evenodd"
                />
              </svg>
              <span>REJECTED</span>
            </div>
          </transition>

          <div v-if="state == 'loaded'">
            <div class="detail">
              <label>URL</label>
              <span class="data">{{ report.url }}</span>
              <!-- <span class="data">https://maliciou.xyz/phishing-page.html</span> -->
            </div>
            <div class="detail">
              <label>Reported By</label>
              <span class="data">{{ report.user.name }}</span>
            </div>
            <div class="detail normal-font">
              <label>Report Date</label>
              <span class="data">{{ new Date(report.date).toLocaleString() }}</span>
            </div>
            <div class="detail">
              <label>Brief Info</label>
              <span class="data">{{ report.brief }}</span>
            </div>

            <div class="actions">
              <button @click="approve()" class="action approve" type="button">
                <svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                  <path d="M0 11l2-2 5 5L18 3l2 2L7 18z" fill="currentColor" fill-rule="evenodd" />
                </svg>
                <span>APPROVE</span>
              </button>

              <button @click="reject()" class="action" type="button">
                <svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                  <path
                    d="M11.414 10l2.829-2.828-1.415-1.415L10 8.586 7.172 5.757 5.757 7.172 8.586 10l-2.829 2.828 1.415 1.415L10 11.414l2.828 2.829 1.415-1.415L11.414 10zM2.93 17.071c3.905 3.905 10.237 3.905 14.142 0 3.905-3.905 3.905-10.237 0-14.142-3.905-3.905-10.237-3.905-14.142 0-3.905 3.905-3.905 10.237 0 14.142zm1.414-1.414A8 8 0 1015.657 4.343 8 8 0 004.343 15.657z"
                    fill="currentColor"
                    fill-rule="evenodd"
                  />
                </svg>
                <span>REJECT</span>
              </button>
            </div>
          </div>
        </div>
      </transition>
    </div>
  </transition>
</template>
<script>
export default {
  name: "Report",
  props: ["report"],
  data: () => {
    return {
      toggle: false,
      state: "loaded",
      visible: true
    };
  },
  computed: {
    user: {
      get() {
        return this.$store.state.user;
      },
      set(value) {
        this.$store.commit("setUser", value);
      }
    }
  },
  created() {
    console.log(this.report);
  },
  methods: {
    async approve() {
      let form = new FormData();

      form.append("url", this.report.url);
      form.append("email", this.report.user.email);

      let res = await fetch(this.getURL("/api/report/approve"), {
        method: "POST",
        body: form,
        credentials: "include"
      }).then(res => res.json());
      console.log(res);
      if (res.status == "approved") {
        const self = this;
        this.state = res.status;
        setTimeout(() => {
          self.visible = false;
        }, 1500);
      } else {
        alert("An unexpected error occurred.\nTry again later...");
      }
    },
    async reject() {
      let form = new FormData();

      form.append("url", this.report.url);
      form.append("email", this.report.user.email);

      let res = await fetch(this.getURL("/api/report/reject"), {
        method: "POST",
        body: form,
        credentials: "include"
      }).then(res => res.json());
      console.log(res);
      if (res.status == "rejected") {
        const self = this;
        this.state = res.status;
        setTimeout(() => {
          self.visible = false;
        }, 1500);
      } else {
        alert("An unexpected error occurred.\nTry again later...");
      }
    }
  }
};
</script>
<style lang="scss" scoped>
/* Enter and leave animations can use different */
/* durations and timing functions.              */
.slide-fade-enter-active {
  transition: all 0.3s ease;
}
.slide-fade-leave-active {
  transition: all .2s ease-in-out;
}
.slide-fade-enter,
.slide-fade-leave-to {
  transform: translateX(10px);
  opacity: 0;
}

.details.approved {
  background: rgba(15, 118, 63, 0.4196078431372549);
  color: #0fd7b0;
}

.details.rejected {
  background: rgba(96, 24, 26, 0.36);
  color: #bc3d40;
}

.msg-card {
  display: flex;
  width: 100%;
  padding: 16px 0;
  align-items: center;
  justify-content: center;
  font-weight: 600;
  svg {
    height: 22px;
    margin-right: 6px;
  }
}

.normal-font {
  font-family: Helvetica;
}
.report {
  display: block;
  width: 100%;

  max-width: 720px;
  margin: 10px auto;

  background: #263444;
  color: #3286e6;
  border-radius: 12px;

  .title {
    display: flex;
    justify-content: space-between;
    height: 50px;
    align-items: center;
    padding: 0 16px;

    .domain {
      font-weight: 600;
    }

    svg {
      width: 24px;
      cursor: pointer;
      transition: 0.4s;
    }

    svg.down {
      transform: rotate(180deg);
    }
  }

  .details {
    display: flex;
    flex-direction: column;
    padding: 16px;
    border-top: 1px solid #3286e6;
    .detail {
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      label {
        flex: 1;
        color: #479dff;
        font-family: Arial, Helvetica, sans-serif;
      }
      .data {
        flex: 1;
        color: #9ec5f2;
      }
    }
    .actions {
      display: flex;
      flex-direction: row-reverse;
      margin-top: 18px;
      width: 100%;
      justify-content: space-between;
      width: auto;
      margin: 18px 0 0 auto;

      .action {
        display: flex;
        align-items: center;
        text-align: center;
        font-family: Arial, Helvetica, sans-serif;
        padding: 8px 12px;
        height: 32px;
        font-weight: bold;
        border: 0;
        background: rgba(96, 24, 26, 0.36);
        color: #bc3d40;
        cursor: pointer;
        margin-left: 6px;
        transition: 0.4s;
        border: 2px solid transparent;

        svg {
          width: 12px;
          margin-right: 6px;
        }

        span {
          display: inline-block;
          width: auto;
          text-align: center;
        }
      }

      .action:hover,
      .action:focus {
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        border: 2px solid rgba(0, 0, 0, 0.4);
      }

      button.approve {
        color: #0f921a;
        background: #3379004f;
      }
    }
  }
}

@media only screen and (max-width: 540px) {
  .actions {
    width: 100% !important;
    margin: 12px auto 0 auto !important;
    .action {
      margin: 0 !important;
    }
  }
}
</style>