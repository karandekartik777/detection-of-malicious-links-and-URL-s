<template>
  <div class="result-card" :class="title.toLowerCase() + '-' + result">

    <div class="title">{{ title }}</div>

    <div class="details">

      <i v-if="result == 'fetching'" class="loader fa fa-spinner fa-spin"></i>

      <div v-if="result != 'fetching'">

        <div class="result" :class="result">
          {{ result }}
        </div>

      </div>
      <canvas id="overallChart" class="chart"></canvas>
    </div>
  
  </div>
</template>
<script>
import Chart from 'chart.js';

export default {
  name: 'OverallCard',
  props: ['title', 'result', 'data'],
  data: () => ({
    chart: ''
  }),
  watch: {
    result () {
      if (this.result == 'safe' || this.result == 'risky' || this.result == 'unsafe') {
        this.drawChart()
      }
    }
  },
  methods: {
    drawChart () {

      const ov = this.data

      console.log(ov)

      let unsafe_bg = 'rgba(255, 99, 132, 0.2)'
      let unsafe_color = 'rgba(255, 99, 132, 1)'
      let safe_bg = 'rgba(15, 146, 26, 0.2)'
      let safe_color = 'rgba(15, 146, 26, 1)'

      let labels = ['Overall', 'Database', 'Pagerank']
      let bgColors = [safe_bg]
      let colors = [safe_color]

      const res = [
        0,
        ov.database.count == 0 ? 100 : 0,
        ov.pagerank * 10
      ]

      if (ov.database.count == 0) {
        bgColors.push(safe_bg)
        colors.push(safe_color)
      } else {
        bgColors.push(unsafe_bg)
        colors.push(unsafe_color)
      }

      if (ov.pagerank < 3) {
        bgColors.push(unsafe_bg)
        colors.push(unsafe_color)
      } else {
        bgColors.push(safe_bg)
        colors.push(safe_color)
      }

      if (ov.pagerank < 5) {
        if (ov.lexical && ov.lexical != 'fetched') {
          labels.push('Lexical')
          res.push(ov.lexical)
          if (ov.lexical > 50) {
            bgColors.push(safe_bg)
            colors.push(safe_color)
          } else if (ov.lexical < 50) {
            bgColors.push(unsafe_bg)
            colors.push(unsafe_color)
          }
        }
  
        if (ov.spam && ov.spam != 'fetched') {
          labels.push('Spam')
          res.push(ov.spam)
          if (ov.spam > 50) {
            bgColors.push(safe_bg)
            colors.push(safe_color)
          } else if (ov.spam < 50) {
            bgColors.push(unsafe_bg)
            colors.push(unsafe_color)
          }
        }
      }

      let data = {
        labels: labels,
        datasets: [
          {
            data: res,
            backgroundColor: bgColors,
            borderColor: colors,
            borderWidth: 3
          },
        ],
      }

      if (this.chart == '') {
        this.chart = new Chart('overallChart', {
          type: 'radar',
          data: data,
        });
      } else {
        this.chart.data = data
        this.chart.update()
      }
    }
  }
}
</script>
<style lang="scss" scoped>

.database-unsafe {
  flex: 1;
}

.db-info {
  border-top: 2px solid #356295;
  margin-top: 18px;
  padding: 12px 24px;
  padding-top: 32px;

  display: flex;
  flex-direction: column;
  width: 100%;
  text-align: left;
  font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
  & > div {
    margin-bottom: 22px;
    h5 {
      font-size: 14px;
      color: #92b3d8;
      font-weight: 800;
    }
    div {
      font-size: 18px;
      color: #dae4f0;
      margin-top: 10px;
    }
  }
}

.result-card {
  background: #263444;
  color: #3286e6;
  display: flex;
  flex-direction: column;
  padding: 24px 0 16px;
  margin-bottom: 12px;
  border-radius: 12px;

  .details {
    text-align: center;
  }

  .loader {
    font-size: 72px;
    color: #c7c7c7;
    text-align: center;
    margin: 36px 0 16px 0;
  }
  
  .title {
    font-weight: 700;
    text-transform: uppercase;
    text-align: center;
  }


  .result {
    text-align: center;
    padding: 24px 0 18px 0;
    font-size: 32px;
    text-transform: uppercase;
    font-weight: 900;
    color: #0f921a;
  }
  .result.unsafe {
    color: #bc3d40;
  }
  .result.risky {
    color: #d9760d;
  }
}
</style>