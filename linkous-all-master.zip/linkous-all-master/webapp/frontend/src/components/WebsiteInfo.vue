<template>
  <div class="result-card website-info">

    <div class="title">Website Info</div>


    <div class="details">

      <i v-if="status == 'fetching'" class="loader fa fa-spinner fa-spin"></i>

      <div id="map-ctr" ref="map_ctr">
        <div id="map"></div>
      </div>

      <div v-if="status == 'fetched'">

        <div class="db-info">


          <div class="data-field" v-if="info.regionName != '' || info.region != ''">
            <h5>Region</h5>
            <div>
              {{ info.regionName }} ({{ info.region }})
            </div>
          </div>

          <div class="data-field" v-if="info.country != '' || info.countryCode != ''">
            <h5>Country</h5>
            <div>
              {{ info.country }} ({{ info.countryCode }})
            </div>
          </div>

          <div class="data-field" v-if="info.continent != '' || info.continentCode != ''">
            <h5>Continent</h5>
            <div>
              {{ info.continent }} ({{ info.continentCode }})
            </div>
          </div>

          <div class="data-field" v-if="info.query != ''">
            <h5>IP Address</h5>
            <div>
              {{ info.query }}
            </div>
          </div>

          <div v-if="role != 'user'">

            <div class="data-field">
              <h5>Lattitute, Longitute</h5>
              <div>
                {{ info.lat }}, {{ info.lon }}
              </div>
            </div>

            <div class="data-field">
              <h5>ASN</h5>
              <div>
                {{ info.as }} ({{ info.asname }})
              </div>
            </div>

            <div class="data-field">
              <h5>Organization</h5>
              <div>
                {{ info.org }}
              </div>
            </div>

            <div class="data-field">
              <h5>ISP</h5>
              <div>
                {{ info.isp }}
              </div>
            </div>

            <div class="data-field">
              <h5>Hosting</h5>
              <div>
                {{ (info.hosting) ? 'Yes' : 'No' }}
              </div>
            </div>

            <div class="data-field">
              <h5>Mobile</h5>
              <div>
                {{ (info.mobile) ? 'Yes' : 'No' }}
              </div>
            </div>

            <div class="data-field">
              <h5>Proxy</h5>
              <div>
                {{ (info.proxy) ? 'Yes' : 'No' }}
              </div>
            </div>

          </div>


        </div>

      </div>
    </div>
  
  </div>
</template>
<script>
import leaflet from "leaflet"

export default {
  name: 'WebsiteInfo',
  props: ['url', 'trigger'],
  data: () => ({
    status: 'idle',
    info: {},
    map: '',
    role: 'user'
  }),
  watch: {
    async trigger () {
      this.status = 'fetching'
      let data = await this.fetchFromURL('/api/website_info')
      this.status = 'fetched'
      this.info = data
      this.setMap()
    }
  },
  async created() {
    this.status = 'fetching'
    let data = await this.fetchFromURL('/api/website_info')
    this.status = 'fetched'
    this.info = data
    this.setMap()
  },
  methods: {
    setMap () {

      const lat = this.info.lat
      const lon = this.info.lon

      if (!(lat || lon)) {
        this.role = 'user'
        this.$refs.map_ctr.style.display = "none"
        return false;
      } else {
        this.role = 'org'
        this.$refs.map_ctr.style.display = "block"
      }

      const zoom = 7
      

      if (this.map == '')
        this.map = leaflet.map('map').setView([lat, lon], zoom)
      else
        this.map.setView([lat, lon], zoom)
      

      leaflet.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw', {
        maxZoom: 18,
        attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, ' +
          '<a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, ' +
          'Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
        id: 'mapbox/streets-v11',
        tileSize: 512,
        zoomOffset: -1
        
      }).addTo(this.map);

      leaflet.marker([lat, lon]).addTo(this.map);
      
    },
    getInvalidURL: url => {
      // removes https?://www from the url
      if (url && url.length > 0)
      return url
        .replace(/^(?:https?:\/\/)?(?:www\.)?/i, "")
        .split("/")[0];
      return url;
    },
    fetchFromURL: async function(path) {
      let form = new FormData();
      let url = this.getInvalidURL(this.url)
      form.append("url", url);
      let data = await fetch(this.getURL(path), {
        method: "POST",
        body: form,
        credentials: "include"
      }).then(res => {
        return res.json()
      })
      return data;
    },
  }
}
</script>
<style lang="scss" scoped>

#map-ctr {
  margin-top: 40px;
  border-top: 2px solid #356295;
  padding-top: 20px;
  #map {
    height: 180px;
  }
}

.database-unsafe {
  flex: 1;
}

.db-info {
  border-top: 2px solid #356295;
  margin-top: 18px;
  padding: 12px 24px;
  padding-top: 32px;

  display: flex;
  flex-direction: column;
  width: 100%;
  text-align: left;
  font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
  .data-field {
    margin-bottom: 22px;

    h5 {
      font-size: 14px;
      color: #92b3d8;
      font-weight: 800;
    }
    div {
      font-size: 18px;
      color: #dae4f0;
    }
  }
}

.result-card {
  background: #263444;
  color: #3286e6;
  display: flex;
  flex-direction: column;
  padding: 24px 0 16px;
  margin-bottom: 12px;
  border-radius: 12px;

  .details {
    text-align: center;
  }

  .loader {
    font-size: 72px;
    color: #c7c7c7;
    text-align: center;
    margin: 36px 0 16px 0;
  }
  
  .title {
    font-weight: 700;
    text-transform: uppercase;
    text-align: center;
  }


  .result {
    text-align: center;
    padding: 24px 0 18px 0;
    font-size: 32px;
    text-transform: uppercase;
    font-weight: 900;
    color: #0f921a;
  }
  .result.unsafe {
    color: #bc3d40;
  }
  .result.risky {
    color: #d9760d;
  }
}
</style>