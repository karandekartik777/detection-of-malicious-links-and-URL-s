<template>
  <div class="result-card" :class="title.toLowerCase() + '-' + result">

    <div class="title">{{ title }}</div>

    <div class="details">

      <i v-if="result == 'fetching'" class="loader fa fa-spinner fa-spin"></i>

      <div v-if="result != 'fetching'">

        <div class="result" :class="result">
          {{ result }}
        </div>

        <div class="db-info" v-if="db && db.count > 0">

          <div>
            <h5>Total Reports</h5>
            <div>
              {{ db.count }}
            </div>
          </div>

          <div>
            <h5>First Reporter</h5>
            <div>
              {{ db.first_report }}
            </div>
          </div>

          <div>
            <h5>Validated Reports</h5>
            <div>
              {{ db.valid_count }}
            </div>
          </div>

          <div>
            <h5>First reported</h5>
            <div>
              {{ db.report_date }}
            </div>
          </div>

        </div>


      </div>
        <div class="chart" v-if="title != 'Database'">

          <canvas ref="chart" :id="'chart' + title"></canvas>
          
        </div>
    </div>
  
  </div>
</template>
<script>
import Chart from "chart.js"

export default {
  name: 'ResultCard',
  props: {
    title: String,
    result: String,
    db: Object,
    percentage: {
      type: Number,
      default: -1
    }
  },
  data: () => ({
    chart: ''
  }),
  watch: {
    percentage() {
      this.$nextTick(() => {
        this.drawChart()
      })
    }
  },
  mounted () {
    this.$nextTick(() => {
      try {
        this.drawChart()
      } catch (e) {
        // console.log(e)
      }
    })
  },
  methods: {
    drawChart () {

      const self = this
      let percentage = self.percentage

      if (isNaN(self.percentage)) {
        percentage = 50
      }

      let bgColor = 'rgba(255, 99, 132, 0.2)'
      let color = 'rgba(255, 99, 132, 1)'

      if (self.percentage > 50) {
        bgColor = 'rgba(15, 146, 26, 0.2)'
        color = 'rgba(15, 146, 26, 1)'
      }

      // yellow
      if (self.percentage == 50 || self.result == 'risky') {
        bgColor = 'rgba(217, 118, 13, 0.2)'
        color = 'rgba(217, 118, 13, 1)'
      }
      
      // green
      if (self.result == 'safe') {

        bgColor = 'rgba(15, 146, 26, 0.2)'
        color = 'rgba(15, 146, 26, 1)'
      }

      if (self.chart == '') {

        self.chart = new Chart(self.$refs.chart, {
          labels: [self.title],
          type: 'bar',
          data: {
            labels: [self.title],
            datasets: [{
              label: self.title,
              data: [percentage],
              backgroundColor: [
                bgColor,
              ],
              borderColor: [
                color,
              ],
              borderWidth: 1
            }],
          },
          options: {
            scales: {
                yAxes: [{
                    ticks: {
                      suggestedMin: 0,
                        suggestedMax: 100
                        }
                    }]
                }
            }
        });
      } else {

        let bgColor = 'rgba(255, 99, 132, 0.2)'
        let color = 'rgba(255, 99, 132, 1)'

        if (self.percentage > 50) {
          bgColor = 'rgba(15, 146, 26, 0.2)'
          color = 'rgba(15, 146, 26, 1)'
        }

        if (self.percentage == 50 || self.result == 'risky') {
          bgColor = 'rgba(217, 118, 13, 0.2)'
          color = 'rgba(217, 118, 13, 1)'
        }

        // green
        if (self.result == 'safe') {

          bgColor = 'rgba(15, 146, 26, 0.2)'
          color = 'rgba(15, 146, 26, 1)'
        }

        self.chart.data.datasets[0].data = [percentage]
        self.chart.data.datasets[0].backgroundColor = [bgColor]
        self.chart.data.datasets[0].borderColor = [color]
        self.chart.update()
      }
          
    }
  }
}
</script>
<style lang="scss" scoped>

.database-unsafe {
  flex: 1;
}

.db-info {
  border-top: 2px solid #356295;
  margin-top: 18px;
  padding: 12px 24px;
  padding-top: 32px;

  display: flex;
  flex-direction: column;
  width: 100%;
  text-align: left;
  font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
  & > div {
    margin-bottom: 22px;
    h5 {
      font-size: 14px;
      color: #92b3d8;
      font-weight: 800;
    }
    div {
      font-size: 18px;
      color: #dae4f0;
      margin-top: 10px;
    }
  }
}

.result-card {
  background: #263444;
  color: #3286e6;
  display: flex;
  flex-direction: column;
  padding: 24px 0 16px;
  margin-bottom: 12px;
  border-radius: 12px;

  .details {
    text-align: center;
  }

  .loader {
    font-size: 72px;
    color: #c7c7c7;
    text-align: center;
    margin: 36px 0 16px 0;
  }
  
  .title {
    font-weight: 700;
    text-transform: uppercase;
    text-align: center;
  }


  .result {
    text-align: center;
    padding: 24px 0 18px 0;
    font-size: 32px;
    text-transform: uppercase;
    font-weight: 900;
    color: #0f921a;
  }
  .result.unsafe {
    color: #bc3d40;
  }
  .result.risky {
    color: #d9760d;
  }
}
</style>