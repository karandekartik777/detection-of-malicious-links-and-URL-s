<template>
  <div class="search">
    <div class="content">

      <div id="search-bar">
        <form @submit="search">
          <div id="search-angle" @click="clear">
            <i v-if="!hasFavicon" class="fa fa-angle-right"></i>
            <img @error="hasFavicon = false" v-if="hasFavicon" v-bind:src="faviconURL" />
          </div>
          <input v-model="url" class="dark-input" type="text" placeholder="example.com" />
          <button @click="search" type="button">
            <i class="fa fa-search"></i>
          </button>
        </form>
      </div>

      <div v-if="status == 'fetch'" id="search-results" class="pad-content">
        <div>
          <h3 id="results-h3">Results</h3>


          <div class="flex">
            <div style="flex: 1">

              <OverallCard title="Overall" :result="states.overall" :data="res"/>
              
              <div class="flex">
                <ResultCard title="Database" :result="states.database" :db="res.database"/>
                <ResultCard v-show="states.database == 'safe'" title="PageRank" :result="states.pagerank" :percentage="Number(res.pagerank) * 10"/>
              </div>

              <div class="flex" v-if="showAll">
                <ResultCard v-show="states.database == 'safe'" title="Lexical Analysis" :result="states.lexical" :percentage="Number(res.lexical)"/>
                <ResultCard v-show="states.database == 'safe'" title="Spam Analysis" :result="states.spam" :percentage="Number(res.spam)"/>
              </div>

              <ContentCard title="Content Analysis" :status="states.content" :content="res.content"/>

            </div>
            <div style="width: 360px; margin-left: 20px;">
                <WebsiteInfo :url="url" :trigger="websiteTrigger"/>
            </div>
          </div>


        </div>
      </div>

      <div v-if="status == 'empty'" id="search-404" class="pad-content">
        <div>
          <h2>Oops, you haven't entered a URL yet...</h2>
        </div>
      </div>

      <div v-if="status == 'mounted'" id="search-404" class="pad-content">
        <div>
          <h2>Welcome to Linkous</h2>
          <p>Start by searching for a link!</p>
        </div>
      </div>

    </div>
  </div>
</template>

<script>
import ResultCard from '@/components/ResultCard.vue'
import WebsiteInfo from '@/components/WebsiteInfo.vue'

import ContentCard from '@/components/ContentCard.vue'
import OverallCard from '@/components/OverallCard.vue'

export default {
  name: "Search",
  components: {
    ResultCard,
    WebsiteInfo,
    ContentCard,
    OverallCard,
  },
  data: function() {
    return {
      status: "mounted",
      hasFavicon: false,
      faviconURL: "",
      states: {
        overall: "fetching",
        database: "fetching",
        pagerank: "fetching",
        lexical: "fetching",
        spam: "fetching",
        content: "fetching",
        showAll: false
      },
      websiteTrigger: true,
      res: {
        database: {}
      }
    };
  },
  mounted() {
    if (this.url.length == 0) this.status = "mounted";
    else this.search();
  },
  methods: {
    extractHostName: url => new URL(url).hostname,

    clear: function() {
      this.url = "";
      this.hasFavicon = false;
      this.faviconURL = "";
      this.status = "mounted";
      for (let key in this.states) {
        if (key != 'showAll')
          this.states[key] = "fetching";
      }
    },

    validURL (url) {
      var pattern = new RegExp('^(https?:\\/\\/)?'+ // protocol
        '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|'+ // domain name
        '((\\d{1,3}\\.){3}\\d{1,3}))'+ // OR ip (v4) address
        '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*'+ // port and path
        '(\\?[;&a-z\\d%_.~+=-]*)?'+ // query string
        '(\\#[-a-z\\d_]*)?$','i'); // fragment locator
      return !!pattern.test(url);
    },

    setIcon: async function() {
      if (this.url.length == 0) {
        this.hasFavicon = false;
        return false;
      }
      let newURL = "http://" + this.extractHostName(this.getValidURL(this.url));
      this.faviconURL = newURL + "/favicon.ico";
      this.hasFavicon = true;
    },

    getValidURL: (url = "") => {
      // returns valid url with https? prefix if not present
      let newURL = window.decodeURIComponent(url);
      newURL = newURL.trim().replace(/\s/g, "");

      if (/^(:\/\/)/.test(newURL)) {
        return `http${newURL}`;
      }
      if (!/^(f|ht)tps?:\/\//i.test(newURL)) {
        return `http://${newURL}`;
      }

      return newURL;
    },

    getInvalidURL: url => {
      // removes https?://www from the url
      let newURL = url
        .replace(/^(?:https?:\/\/)?(?:www\.)?/i, "")
        .split("/")[0];
      return newURL;
    },
    toInt: n => {
      let num = Number(n)
      if (! isNaN(num) || n == '')
        return 0
      else
        return num
    },

    search: async function(e) {
      if (e) e.preventDefault();

      if (!this.validURL(this.url)) {
        alert("Please enter a valid URL")
        return false
      }

      // this.showAll = true

      let self = this;

      this.websiteTrigger = !this.websiteTrigger

      this.setIcon();

      for (let state in this.states) {
        if (state !='showAll')
          this.states[state] = "fetching"
      }

      if (this.url.length == 0) {
        this.status = "Invalid URL";
        return false;
      }

      this.status = "fetch";

      // fetching starts here

      let promises = {
        pagerank: this.fetchPageRank(),
        db: this.fetchDB(),
        content: this.fetchContent(),
      };


      this.showAll = false

      await Promise.all(Object.values(promises)).then(function () {
        // checks only db, pagerank first
        if (self.states.database == 'unsafe') {
          self.states.overall = 'unsafe'
          self.showAll = false
          self.res.overall = self.res.pagerank
          return false
        }
        if (self.states.pagerank == 'risky' || self.states.database == 'safe') {
          self.states.overall = 'safe'
          if (self.res.pagerank < 2) {
            self.showAll = true
          } else {
            self.states.overall = 'safe'
            self.showAll = false
          }
        } else {
          self.showAll = true
        }
      })

      if (!this.showAll) {
        if (self.states.pagerank == "safe" && self.states.database == "safe")
          self.states.overall = "safe"

        this.states.lexical = "fetched"
        this.states.spam = "fetched"

        let res = self.res
        self.res = res

        return false;
      }

      promises['lex'] = this.fetchLex()
      promises['spam'] = this.fetchSpam()

      await Promise.all(Object.values(promises)).then(function() {

        // init
        self.res.lexical = self.res.lexical * 100
        self.res.spam = self.res.spam * 100

        // calculate overall
        const data = self.res
        
        if (isNaN(data.spam)) {
          data.spam = 50
        }

        self.res.overall = ((2 * data.pagerank * 10) + data.lexical + data.spam) / 4

        let states = [
          self.states.pagerank,
          self.states.lexical,
          self.states.spam,
          self.states.content,
        ];

        let unsafe_count = 0;
        for (let state of states) {
          if (state == "unsafe" || state == "risky") unsafe_count++;
        }

        if (unsafe_count == 0)
          self.states.overall = 'safe'
        else if (unsafe_count < 3)
          self.states.overall = 'risky'
        else
          self.states.overall = 'unsafe'

        if (self.states.pagerank == 'unsafe') {
          self.states.overall = 'unsafe'
        }

      }).catch((e) => {
        self.states.overall = "error"
        console.log(e)
      });

      return;
    },

    fetchFromURL: async function(path) {
      let form = new FormData();
      form.append("url", this.url);
      let data = await fetch(this.getURL(path), {
        method: "POST",
        body: form
      }).then(function(response) {
        return response.json();
      });
      return data;
    },

    fetchContent: async function() {
      let self = this;
      return await this.fetchFromURL("/api/content-scan").then(function(res) {
        console.log(res)
        self.states.content = 'safe'
        let percentage = 0
        if (res && Object.keys(res).length > 0) {
          let count = 0
          for (let tag of res) {
            if (tag.detection.state == 'unsafe' || tag.detection.state == 'risky') {
              count++
              self.states.content = 'unsafe'
            }   
          }
          percentage = count / res.length
        }
        res.percentage = percentage
        self.res.content = res
        return res;
      });
    },

    fetchPageRank: async function() {
      let self = this;
      return await this.fetchFromURL("/api/pagerank").then(function(res) {
        /**
         * res {
         *  domain,
         *  result,
         *  rank
         * }
         */
        self.states.pagerank = res.result;
        self.res.pagerank = res.rank
        if (res.result == 'safe') {
          self.states.lexical = 'safe'
          self.states.spam = 'safe'
          self.states.content = 'safe'
        }
        return res;
      });
    },

    fetchLex: async function() {
      let self = this;
      return await this.fetchFromURL("/api/lex-scan").then(function(res) {
        self.states.lexical = res.result.result;
        self.res.lexical = 1 - res.result.probability
        if (res.result.probability == 0.5) {
          self.states.lexical = 'risky'
        }
        return res;
      });
    },
    fetchSpam: async function() {
      let self = this;
      return await this.fetchFromURL("/api/spam-scan").then(function(res) {
        self.states.spam = res.result;
        self.res.spam = 1 - res.probability
        return res;
      });
    },

    fetchDB: async function() {
      let self = this;
      return await this.fetchFromURL("/api/search").then(function(res) {
        let date = new Date(res.report_date)
        self.res.database = res;
        self.res.database['report_date'] = date.toDateString();

        if (res.count == 0)
          self.states.database = "safe";
        else if (res.valid_count == 0)
          self.states.database = "safe";
        else
          self.states.database = "unsafe";

        return res;
      });
    },
  },
  computed: {
    url: {
      get() {
        return this.$store.state.url;
      },
      set(value) {
        this.$store.commit("setURL", value);
      }
    }
  }
};
</script>
<style lang="scss" scoped>
$light-dark: #1b1b1b;

.flex {
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  > div {
    width: calc(50% - 6px);
  }
}

#search-angle {
  position: absolute;
  display: flex;
  align-items: center;
  left: 0;
  top: 0;
  line-height: 46px;
  width: 46px;
  height: 46px;
  color: #555;
  border: 0;
  cursor: pointer;
  text-align: center;
  font-weight: bold;
  font-size: 28px;

  img,
  i {
    height: 20px;
    width: 20px;
    display: block;
    margin: 0 auto;
    line-height: 20px;
  }
}

#results-h3 {
  margin: 20px 0;
}

#search-results {
  overflow-y: auto;
}

.loader {
  font-size: 60px;
  color: #fff;
}

#search-bar {
  padding: 24px 16px;
  background: #2a284b;
}

header {
  border-bottom: none;
}

.search {
  display: flex;
  flex: 1;
  flex-direction: column;
}

form {
  display: flex;
  margin-bottom: 50px;
  width: 100%;
  max-width: 1200px;
  margin: 0 auto;
  background: transparent;
  border-radius: 4px;
  overflow: hidden;
  position: relative;

  input[type="text"] {
    padding: 0;
    flex: 1;
    height: 46px;
    font-size: 18px;
    text-align: center;
    width: 100%;
    padding: 0 46px;
  }
  button {
    position: absolute;
    right: 0;
    top: 0;
    width: 46px;
    height: 46px;
    background: $light-dark;
    color: #555;
    font-size: 22px;
    border: 0;
    cursor: pointer;
  }
}

#search-404 {
  display: flex;
  flex: 1;
  align-items: center;
  div {
    text-align: center;
  }
}

@media only screen and (min-width: 800px) {
  #home-search {
    padding: 24px;
  }
}


@media only screen and (max-width: 540px) {
.flex {
  flex-direction: column;
  > div {
    width: 100%;
  }
  > div:first-child {
    border: 0;
  }
}
}

</style>
