<template>
  <div class="pad-content">
    <div>

      <h1 style="margin: 20px 0"><center>Dashboard</center></h1>

      <p class="italic">
        Help make the World Wide Web a safer place!
      </p>
      
      <div id="responsive-ctr">

        <div id="user-info" v-if="user.state == 'valid'">
          
          <div class="name">
            {{ user.email }}, {{ user.role }}
          </div>
          <div class="aside">
            <button class="icon-btn" @click="logout">
              <svg fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" stroke="currentColor"><path d="M3 10h10a8 8 0 018 8v2M3 10l6 6m-6-6l6-6"/></svg>
              <span>Log Out</span>
            </button>
          </div>

        </div>
        


        <Greeter v-if="user.state == 'invalid'"/>
        
        <AdminPanel v-if="user.role == 'admin'"/>

        <div class="flex">
          
          <Reporter v-if="user.state == 'valid'"/>

          <div id="org-panel" v-if="user.role == 'org'">

            <h2>Organization Panel</h2>
            
            <div class="content">
              
              <a class="a-btn" href="./api/reports.json" target="_blank">
                <svg fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" stroke="currentColor"><path d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"/></svg>
                <span>All Reports in JSON</span>
              </a>

              <!-- <a class="a-btn" href="#">
                <svg fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" stroke="currentColor"><path d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"/></svg>
                <span>All Reports in CSV</span>
              </a> -->

            </div>

          </div>
        
        </div>

      
      </div>



    </div>
  </div>
</template>

<script>
import Greeter from "@/components/Dashboard/Greeter.vue";
import Reporter from "@/components/Dashboard/Reporter.vue";
import AdminPanel from "@/components/Dashboard/AdminPanel.vue";

export default {
  name: "Dashboard",
  components: {
    AdminPanel,
    Greeter,
    Reporter
  },
  data: () => {
    return {
    }
  },
  computed: {
    user: {
      get() {
        return this.$store.state.user;
      },
      set(value) {
        this.$store.commit("setUser", value);
      }
    }
  },
  async created() {

    let res = await fetch(this.getURL('/api/user-auth'), {
        credentials: "include"
    }).then((res) => res.json())
    console.log(res)
    this.user = res
  },
  methods: {
    async logout(e) {
      let res = await fetch(this.getURL('/api/logout'), {
        credentials: "include"
      }).then(res => res.json());
      console.log(res);
      this.user = {
        state: 'invalid'
      }
      e.preventDefault()
      return false;
    },

  },
}
</script>

<style lang="scss" scoped>

.flex {
  display: flex;
  width: 100%;
  > div {
    flex: 1;
  }
}

#org-panel {
  display: table;
  width: 95%;
  max-width: 400px;
  margin: 40px auto;
  .content {
    margin-top: 32px;
  }
  .a-btn {
    display: flex;
    width: 100%;
    color: #3286e6;
    background: #263444;
    padding: 12px 0;
    text-align: center;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    font-weight: 600;
    margin: 12px 0;
    border-radius: 12px;
    svg {
      height: 18px;
      margin-right: 6px;
    }
  }
}

#responsive-ctr {
  display: flex;
  width: 100%;
  flex-direction: column;
  #user-info {
    flex: 1;
  }
}

#user-info {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 20px;
  background: #263444;
  color: #3286e6;
  border-radius: 18px;
}

hr.sep {
  border: 0;
  background-color: #888;
  width: 100%;
  height: 1 px;
}

.icon-btn {
  display: flex;
  align-items: center;
  height: 36px;
  color: #3286e6;
  background: none;
  border: none;
  cursor: pointer;
  font-size: 16px;
  border: 1.5px solid #3286e6;
  border-radius: 6px;
  padding: 12px 12px;

  svg {
    height: 16px;
    margin-right: 8px;
  }
}


@media (max-width: 540px) {
  #user-info {
    flex-direction: column;
    justify-content: space-between;
    padding: 20px 0;
    .name {
      margin-bottom: 16px;
    }
  }
  .flex {
    flex-direction: column;
  }
}


</style>
