<!-- Loading assets
<img alt="Vue logo" src="../assets/logo.png">
-->
<template>
  <div class="home pad-mobile">
    <div>
      <h1 class="logo">Linkous</h1>
      <form class="dark-row-form" @submit="homeSearch">
        <input class="dark-input" v-model="url" type="text" placeholder="example.com" />
        <button @click="homeSearch" type="button">
          <i class="fa fa-search"></i>
        </button>
      </form>
    </div>
  </div>
</template>

<script>
export default {
  name: "Home",
  computed: {
    url: {
      get() {
        return this.$store.state.url;
      },
      set(value) {
        this.$store.commit("setURL", value);
      }
    }
  },
  methods: {
    homeSearch: function(e) {
      if (e) e.preventDefault()

      if (this.url.length > 0) {
        this.$router.push("search")
      }

      return false;
    }
  }
};
</script>


<style lang="scss" scoped>

$light-dark: #1b1b1b;

.home {
  display: flex;
  flex: 1;
  align-items: center;

  > div {
    display: block;
    width: 100%;
    max-width: 800px;
    margin: 0 auto;
    flex: 1;
    text-align: center;
    margin-top: -52px;
    .logo {
      font-size: 58px;
      margin-bottom: 30px;
    }

    form {
      display: flex;
      margin-bottom: 50px;
      width: 100%;
      max-width: 500px;
      margin: 0 auto;
      background: transparent;
      border-radius: 4px;
      position: relative;

      input[type="text"] {
        padding: 0;
        flex: 1;
        height: 46px;
        font-size: 18px;
        text-align: center;
        width: 100%;
        max-width: 500px;
        padding: 0 46px;
      }
      button {
        position: absolute;
        right: 0;
        top: 0;
        width: 46px;
        height: 46px;
        background: $light-dark;
        color: #555;
        font-size: 22px;
        border: 0;
        cursor: pointer;
      }
    }
  }
}
</style>
