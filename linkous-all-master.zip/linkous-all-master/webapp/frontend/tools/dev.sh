mv vue.config.js vue.config.js.prod
npm run serve